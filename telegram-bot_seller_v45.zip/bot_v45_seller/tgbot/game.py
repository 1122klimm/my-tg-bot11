"""Состояния всех мини-игр в чатах."""
import asyncio
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional

MSK = timezone(timedelta(hours=3))


def _cancel(task: Optional[asyncio.Task]) -> None:
    if task and not task.done():
        task.cancel()


# ----------- Перебив -----------
@dataclass
class PerebivState:
    chat_id: int
    message_thread_id: Optional[int] = None
    duration: int = 0
    prize: str = ""
    last_user_id: int = 0
    last_username: str = ""
    last_message_id: int = 0
    deadline: Optional[datetime] = None
    bot_status_message_id: int = 0
    task: Optional[asyncio.Task] = None
    running: bool = False
    # для отсчёта-уведомлений (для очень длинных раундов)
    notified_marks: set = field(default_factory=set)
    # --- v19 ---
    started_at: Optional[datetime] = None       # время старта (для статистики длительности)
    perebivs_count: int = 0                     # сколько раз перебивали
    stars_spent: int = 0                        # v25: накопительная сумма звёзд по факту (с учётом смены цены)
    ton_spent: float = 0.0                      # v25: накопительная сумма TON по факту
    gift_stars: int = 0                         # цена подарка в ⭐
    gift_ton: float = 0.0                       # цена подарка в TON
    last_username_handle: str = ""              # «@nick» если есть, иначе full name (для тегов)
    last_user_is_winner_announced: bool = False # был ли уже объявлен победитель (для «перебив на 0»)
    _lock: Optional[asyncio.Lock] = None        # асинхронный лок per-chat
    # v25: участники для пост-игрового отчёта. uid -> {"name": str, "messages": int, "stars": int}
    participants: dict = field(default_factory=dict)

    def deadline_msk_str(self) -> str:
        if not self.deadline:
            return "—"
        return self.deadline.astimezone(MSK).strftime("%H:%M:%S")

    def lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock


# ----------- Кубик / Казик -----------
@dataclass
class DiceGameState:
    chat_id: int
    game_type: str
    emoji: str
    title: str
    duration: int = 0
    prize: str = ""
    prizes_total: int = 1
    prizes_left: int = 1
    mode: str = ""
    bets: dict = field(default_factory=dict)
    deadline: Optional[datetime] = None
    task: Optional[asyncio.Task] = None
    running: bool = False
    notified_marks: set = field(default_factory=set)
    # v25: статистика для пост-игрового отчёта
    started_at: Optional[datetime] = None
    participants: dict = field(default_factory=dict)  # uid -> {name, messages, stars}
    winners_log: list = field(default_factory=list)   # [(uid, name)]

    def deadline_msk_str(self) -> str:
        if not self.deadline:
            return "—"
        return self.deadline.astimezone(MSK).strftime("%H:%M:%S")


# ----------- Викторина -----------
@dataclass
class QuizQuestion:
    text: str
    options: list
    correct_index: int


@dataclass
class QuizState:
    chat_id: int
    total_questions: int
    option_count: int
    prize: str = ""
    questions: list = field(default_factory=list)
    current_index: int = 0
    scores: dict = field(default_factory=dict)
    answered_user_ids: set = field(default_factory=set)
    task: Optional[asyncio.Task] = None
    running: bool = False
    difficulty: int = 2
    seconds_per_question: int = 20
    fast_next: bool = False
    first_answered: bool = False
    # v19: режим «пока не отгадают правильный ответ — следующего вопроса нет»
    until_correct: bool = False


# ----------- Медведь / NFT -----------
@dataclass
class RouletteState:
    chat_id: int
    kind: str
    emoji: str
    title: str
    chance_percent: float
    prizes_left: int
    prize: str = ""
    duration: int = 0
    deadline: Optional[datetime] = None
    task: Optional[asyncio.Task] = None
    running: bool = False
    notified_marks: set = field(default_factory=set)
    # v25: статистика
    started_at: Optional[datetime] = None
    participants: dict = field(default_factory=dict)
    winners_log: list = field(default_factory=list)
    # v33: учёт потраченных звёзд за ивент
    stars_spent: int = 0
    messages_total: int = 0

    def deadline_msk_str(self) -> str:
        if not self.deadline:
            return "—"
        return self.deadline.astimezone(MSK).strftime("%H:%M:%S")


# ----------- Угадай число -----------
@dataclass
class NumberState:
    chat_id: int
    secret: int
    range_from: int
    range_to: int
    prize: str = ""
    duration: int = 0
    deadline: Optional[datetime] = None
    task: Optional[asyncio.Task] = None
    running: bool = False
    winners_count: int = 1
    # uid -> (username, guess) — последняя догадка каждого
    guesses: dict = field(default_factory=dict)
    # v24: список точно угадавших (uid, username) — для multi-winner режима
    exact_winners: list = field(default_factory=list)
    notified_marks: set = field(default_factory=set)
    # v19: подсказки
    hints_count: int = 0                        # сколько подсказок выдать за раунд
    hints_sent: int = 0
    hints_task: Optional[asyncio.Task] = None
    # текущие границы «известного» диапазона (сужаются подсказками)
    hint_low: int = 0
    hint_high: int = 0
    # v25: статистика
    started_at: Optional[datetime] = None
    participants: dict = field(default_factory=dict)

    def deadline_msk_str(self) -> str:
        if not self.deadline:
            return "—"
        return self.deadline.astimezone(MSK).strftime("%H:%M:%S")


# ----------- Цель сообщениями -----------
@dataclass
class GoalState:
    chat_id: int
    target: int
    current: int = 0
    winners_count: int = 1
    prize: str = ""
    duration: int = 0
    deadline: Optional[datetime] = None
    # v27: uid -> {"name": str, "messages": int}.
    # Старый формат uid -> str всё ещё поддерживается на чтение в _finish().
    participants: dict = field(default_factory=dict)
    pinned_message_id: int = 0
    last_progress_msg_id: int = 0
    last_announced: int = 0
    task: Optional[asyncio.Task] = None
    running: bool = False
    notified_marks: set = field(default_factory=set)

    def deadline_msk_str(self) -> str:
        if not self.deadline:
            return "—"
        return self.deadline.astimezone(MSK).strftime("%H:%M:%S")


# ----------- Лотерея -----------
@dataclass
class LotteryState:
    chat_id: int
    duration: int
    deadline: Optional[datetime] = None
    prize: str = ""
    prizes_count: int = 1
    # uid -> {"username": str, "tickets": [int, int, ...]}
    participants: dict = field(default_factory=dict)
    next_ticket_no: int = 1
    # отслеживание "стоимости сообщения" — сообщения за последний час
    message_times: list = field(default_factory=list)  # список timestamps
    ticket_price_stars: int = 1  # текущая цена билета в звёздах
    announce_message_id: int = 0
    task: Optional[asyncio.Task] = None
    running: bool = False
    notified_marks: set = field(default_factory=set)
    # v33: общая статистика для пост-игрового отчёта
    started_at: Optional[datetime] = None
    stars_spent: int = 0
    messages_total: int = 0

    def deadline_msk_str(self) -> str:
        if not self.deadline:
            return "—"
        return self.deadline.astimezone(MSK).strftime("%H:%M:%S")

    @property
    def total_tickets(self) -> int:
        return sum(len(p["tickets"]) for p in self.participants.values())


_perebiv: dict = {}
_dice: dict = {}
_quiz: dict = {}
_roulettes: dict = {}
_number: dict = {}
_goal: dict = {}
_lottery: dict = {}


def get_state(cid): return _perebiv.get(cid)
def set_state(s): _perebiv[s.chat_id] = s
def drop_state(cid):
    s = _perebiv.pop(cid, None)
    if s: _cancel(s.task)


def get_dice_state(cid): return _dice.get(cid)
def set_dice_state(s): _dice[s.chat_id] = s
def drop_dice_state(cid):
    s = _dice.pop(cid, None)
    if s: _cancel(s.task)


def get_quiz_state(cid): return _quiz.get(cid)
def set_quiz_state(s): _quiz[s.chat_id] = s
def drop_quiz_state(cid):
    s = _quiz.pop(cid, None)
    if s: _cancel(s.task)


def get_roulette(cid, kind): return _roulettes.get(cid, {}).get(kind)
def set_roulette(s):
    _roulettes.setdefault(s.chat_id, {})[s.kind] = s
def drop_roulette(cid, kind):
    bucket = _roulettes.get(cid)
    if not bucket:
        return
    s = bucket.pop(kind, None)
    if s: _cancel(s.task)
    if not bucket:
        _roulettes.pop(cid, None)
def get_all_roulettes(cid):
    return dict(_roulettes.get(cid, {}))


def get_number(cid): return _number.get(cid)
def set_number(s): _number[s.chat_id] = s
def drop_number(cid):
    s = _number.pop(cid, None)
    if s: _cancel(s.task)


def get_goal(cid): return _goal.get(cid)
def set_goal(s): _goal[s.chat_id] = s
def drop_goal(cid):
    s = _goal.pop(cid, None)
    if s: _cancel(s.task)


def get_lottery(cid): return _lottery.get(cid)
def set_lottery(s): _lottery[s.chat_id] = s
def drop_lottery(cid):
    s = _lottery.pop(cid, None)
    if s: _cancel(s.task)


def drop_all_games(chat_id: int) -> None:
    drop_state(chat_id)
    drop_dice_state(chat_id)
    drop_quiz_state(chat_id)
    drop_number(chat_id)
    drop_goal(chat_id)
    drop_lottery(chat_id)
    for kind in list(_roulettes.get(chat_id, {}).keys()):
        drop_roulette(chat_id, kind)
    # sports live in handlers.sports to avoid circular imports at module load.
    try:
        from handlers.sports import drop_sport
        drop_sport(chat_id)
    except Exception:
        pass
    try:
        from handlers.randommedved import drop_rm
        drop_rm(chat_id)
    except Exception:
        pass


# ============================================================
# Уведомления о приближении конца ивента (общий хелпер)
# ============================================================
# Метки в секундах: 30мин, 15мин, 5мин, 1мин, 30с, 15с, 14..1
LONG_NOTIFY_MARKS = (30 * 60, 15 * 60, 5 * 60, 60, 30, 15)
TICK_MARKS = tuple(range(14, 0, -1))


def _format_left(seconds: int) -> str:
    if seconds >= 60:
        m = seconds // 60
        return f"{m} мин"
    return f"{seconds} сек"


async def deadline_notifier(bot, chat_id: int, get_state_fn, title: str):
    """
    Универсальный таск-нотификатор. Дёргает get_state_fn(chat_id) — должен
    вернуть объект с .deadline, .running, .notified_marks (set).
    Шлёт уведомления о приближении конца. Сам не закрывает ивент.
    """
    import asyncio as _aio
    try:
        while True:
            st = get_state_fn(chat_id)
            if not st or not getattr(st, "running", False) or not getattr(st, "deadline", None):
                return
            remaining = (st.deadline - datetime.now(timezone.utc)).total_seconds()
            if remaining <= 0:
                return
            r = int(remaining)
            for mark in LONG_NOTIFY_MARKS:
                if r == mark and mark not in st.notified_marks:
                    st.notified_marks.add(mark)
                    try:
                        await bot.send_message(
                            chat_id,
                            f"⏳ <b>До конца «{title}» осталось {_format_left(mark)}!</b>"
                        )
                    except Exception:
                        pass
            if r in TICK_MARKS and r not in st.notified_marks:
                st.notified_marks.add(r)
                try:
                    await bot.send_message(chat_id, f"⏱ <b>{r}…</b>")
                except Exception:
                    pass
            await _aio.sleep(1)
    except _aio.CancelledError:
        return
    except Exception:
        return
