"""Спорт-игры на нативных эмодзи Telegram: 🏀 🏈 🎳 🎯
Механика «попал/не попал»:
  — игрок кидает соответствующий эмодзи в чат
  — каждое значение dice.value либо «гол» либо «промах»
  — за гол даём приз; «прошлые промахи» не возвращаются
  — у игры есть время и максимум попыток на игрока (по умолчанию 1)
  — призов несколько: каждое попадание забирает один приз, пока есть.

Поддерживается:
  /basketball [time] [x<призов>] [tries=N] [приз]   — 🏀  попал=4 или 5
  /football   [time] [x<призов>] [tries=N] [приз]   — 🏈  гол=3,4,5
  /bowling    [time] [x<призов>] [tries=N] [приз]   — 🎳  страйк=6
  /darts      [time] [x<призов>] [tries=N] [приз]   — 🎯  яблочко=6
"""
import asyncio
from datetime import datetime, timezone, timedelta
from dataclasses import dataclass, field
from typing import Optional
from html import escape

from aiogram import Router, F, Bot
from aiogram.enums import ChatType
from aiogram.filters import Command, Filter
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from access import is_admin, username_of, remember_username, remember_win, notify_win, is_ignored
from utils import storage
from utils import stats_push
from utils.report import send_post_game_report
from utils.win_photo import send_win_photo, send_start_photo
from utils.chat_admins import is_chat_admin
from utils.duration import parse_duration, format_duration
from game import drop_all_games, MSK
from help_texts import NO_ACCESS, EVENT_FOOTER

router = Router(name="sports")

# value -> «попал»
SPORTS = {
    "basketball": {"emoji": "🏀", "title": "Баскетбол", "wins": {4, 5},
                   "win_text": "🏀 ЗАБИЛ!", "miss_text": "❌ Мимо.",
                   "rules": "🏀 Кидай мяч. Попал в кольцо — приз твой."},
    "football":   {"emoji": "⚽", "title": "Футбол",   "wins": {3, 4, 5},
                   "win_text": "⚽ ГОЛ!",  "miss_text": "❌ Не забил.",
                   "rules": "⚽ Бей по воротам. Попал — приз твой."},
    "bowling":    {"emoji": "🎳", "title": "Боулинг",  "wins": {6},
                   "win_text": "🎳 СТРАЙК!", "miss_text": "❌ Не страйк.",
                   "rules": "🎳 Кидай шар. Только страйк — это победа."},
    "darts":      {"emoji": "🎯", "title": "Дартс",    "wins": {6},
                   "win_text": "🎯 ЯБЛОЧКО!", "miss_text": "❌ Мимо центра.",
                   "rules": "🎯 Кидай дротик. Только в яблочко — победа."},
}

# Алиасы команд
ALIASES = {
    "basketball": ["basketball", "basket", "баскет"],
    "football":   ["football", "soccer", "футбол", "goal_football"],
    "bowling":    ["bowling", "боулинг"],
    "darts":      ["darts", "дартс"],
}


@dataclass
class SportState:
    chat_id: int
    kind: str                  # basketball/football/bowling/darts
    duration: int = 0
    prize: str = ""
    prizes_total: int = 1
    prizes_left: int = 1
    tries_per_user: int = 1    # сколько попыток у каждого игрока
    deadline: Optional[datetime] = None
    task: Optional[asyncio.Task] = None
    running: bool = False
    notified_marks: set = field(default_factory=set)
    # uid -> сколько уже бросал
    attempts: dict = field(default_factory=dict)
    # uid -> сколько уже выиграл (для статы)
    winners: dict = field(default_factory=dict)
    # v25: статистика
    started_at: Optional[datetime] = None
    participants: dict = field(default_factory=dict)  # uid -> {name, messages, stars}

    def deadline_msk_str(self) -> str:
        if not self.deadline:
            return "—"
        return self.deadline.astimezone(MSK).strftime("%H:%M:%S")


_states: dict[int, SportState] = {}


def get_sport(cid: int) -> Optional[SportState]:
    return _states.get(cid)


def set_sport(s: SportState) -> None:
    _states[s.chat_id] = s


def drop_sport(cid: int) -> None:
    s = _states.pop(cid, None)
    if s and s.task and not s.task.done():
        s.task.cancel()


def _stop_kb(kind: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="⛔ Остановить игру", callback_data=f"stop:{kind}")
    ]])


def _parse_args(rest: str) -> tuple[int, int, int, str]:
    """Возвращает (secs, prizes, tries, prize_text)."""
    secs, prizes, tries = 0, 1, 1
    prize_tokens: list[str] = []
    for tok in (rest or "").split():
        low = tok.lower()
        if low.startswith("x") and low[1:].isdigit():
            prizes = max(1, int(low[1:]))
            continue
        if low.startswith("tries=") and low[6:].isdigit():
            tries = max(1, min(20, int(low[6:])))
            continue
        # время вида 30s / 5m / 1h / 1m30s
        if not secs:
            d = parse_duration(low)
            if d:
                secs = d
                continue
        prize_tokens.append(tok)
    return secs, prizes, tries, " ".join(prize_tokens).strip()


# =============== Универсальный обработчик старта ===============
async def _start(message: Message, bot: Bot, kind: str) -> None:
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await message.reply("Запускать игру можно только в групповом чате.")
        return
    if not is_admin(message.from_user.id):
        await message.reply(NO_ACCESS)
        return
    parts = (message.text or "").split(maxsplit=1)
    rest = parts[1] if len(parts) > 1 else ""
    secs, prizes, tries, prize = _parse_args(rest)
    if not prize:
        prize = storage.get().get("prize_url", "")

    cfg = SPORTS[kind]
    drop_all_games(message.chat.id)
    drop_sport(message.chat.id)
    deadline = datetime.now(timezone.utc) + timedelta(seconds=secs) if secs else None
    st = SportState(
        chat_id=message.chat.id, kind=kind, duration=secs, prize=prize,
        prizes_total=prizes, prizes_left=prizes, tries_per_user=tries,
        deadline=deadline, running=True,
        started_at=datetime.now(timezone.utc),
    )
    set_sport(st)
    if secs:
        st.task = asyncio.create_task(_finish_loop(bot, message.chat.id))

    prize_line = f"\n🎁 <b>Приз:</b> {prize}" if prize else "\n🎁 <b>Приз:</b> <i>не задан</i>"
    if secs:
        time_line = (f"⏱ <b>Время:</b> {format_duration(secs)}\n"
                     f"🎯 <b>Финиш:</b> {st.deadline_msk_str()} по МСК")
    else:
        time_line = "⏱ <b>Время:</b> до <code>/stop</code>"
    tries_line = f"\n🎯 <b>Попыток на игрока:</b> <b>{tries}</b>" if tries > 1 else ""
    await send_start_photo(
        bot, message.chat.id, kind,
        f"{cfg['emoji']} <b>{cfg['title']} — игра запущена!</b>\n"
        f"{time_line}\n"
        f"🏆 <b>Призов:</b> <b>{prizes}</b>{tries_line}{prize_line}\n\n"
        f"{cfg['rules']}\nКидай {cfg['emoji']} в чат!"
        f"{EVENT_FOOTER}",
        reply_markup=_stop_kb(kind),
    )


# Регистрация команд для каждого спорта
@router.message(Command(commands=ALIASES["basketball"]))
async def cmd_basketball(message: Message, bot: Bot):
    stats_push.report_start(message, "basketball")
    await _start(message, bot, "basketball")


@router.message(Command(commands=ALIASES["football"]))
async def cmd_football(message: Message, bot: Bot):
    stats_push.report_start(message, "football")
    await _start(message, bot, "football")


@router.message(Command(commands=ALIASES["bowling"]))
async def cmd_bowling(message: Message, bot: Bot):
    stats_push.report_start(message, "bowling")
    await _start(message, bot, "bowling")


@router.message(Command(commands=ALIASES["darts"]))
async def cmd_darts(message: Message, bot: Bot):
    stats_push.report_start(message, "darts")
    await _start(message, bot, "darts")


# =============== Обработка бросков ===============
class ActiveSportFilter(Filter):
    async def __call__(self, message: Message) -> bool:
        if not message.dice:
            return False
        st = get_sport(message.chat.id)
        if not st or not st.running:
            return False
        cfg = SPORTS.get(st.kind)
        return bool(cfg and message.dice.emoji == cfg["emoji"])


_throw_lock: dict[int, asyncio.Lock] = {}


def _lock(cid: int) -> asyncio.Lock:
    if cid not in _throw_lock:
        _throw_lock[cid] = asyncio.Lock()
    return _throw_lock[cid]


@router.message(F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}), ActiveSportFilter())
async def on_sport_throw(message: Message, bot: Bot):
    if not message.from_user or message.from_user.is_bot:
        return
    cid = message.chat.id
    uid = message.from_user.id
    remember_username(message)
    # v27: админы чата не учитываются
    try:
        if await is_chat_admin(bot, cid, uid):
            return
    except Exception:
        pass
    async with _lock(cid):
        st = get_sport(cid)
        if not st or not st.running:
            return
        cfg = SPORTS[st.kind]
        if is_ignored(uid, st.kind):
            return
        if st.attempts.get(uid, 0) >= st.tries_per_user:
            try:
                await message.reply(f"⛔ У тебя уже {st.tries_per_user} попыт(ок).")
            except Exception:
                pass
            return
        st.attempts[uid] = st.attempts.get(uid, 0) + 1
        value = message.dice.value
        username = username_of(message)
        # v25: накапливаем участника
        info = st.participants.setdefault(uid, {"name": username, "messages": 0, "stars": 0})
        info["name"] = username
        info["messages"] = int(info.get("messages", 0)) + 1

        if value in cfg["wins"]:
            st.prizes_left -= 1
            st.winners[uid] = st.winners.get(uid, 0) + 1
            prize = st.prize or storage.get().get("prize_url", "")
            remember_win(uid, username, prize, st.kind)
            prize_line = f"\n🎁 <b>Приз:</b> {prize}" if prize else ""
            left_line = f"\n🏆 <b>Призов осталось:</b> {st.prizes_left}" if st.prizes_total > 1 else ""
            try:
                chat = await bot.get_chat(cid)
                chat_title = chat.title
            except Exception:
                chat_title = None
            stats_push.push_event(
                chat_id=cid, chat_title=chat_title,
                user_id=uid, username=username.lstrip("@") if username.startswith("@") else None,
                full_name=username, avatar_url=None,
                game_type=st.kind, event_type="won", prize=prize,
                stars_value=0, ton_value=0,
                meta={"value": value},
            )
            await send_win_photo(
                bot, cid, st.kind,
                caption=f"<b>{cfg['win_text']}</b>\n{username} — победитель!{prize_line}{left_line}",
            )
            try:
                await notify_win(bot, chat_title or "", username, prize, st.kind)
            except Exception:
                pass
            if st.prizes_left <= 0:
                st.running = False
                # v25: пост-игровой отчёт админам
                try:
                    await send_post_game_report(
                        bot,
                        chat_id=cid,
                        chat_title=chat_title,
                        game_type=st.kind,
                        game_label=f"{cfg['emoji']} {cfg['title']}",
                        started_at=st.started_at,
                        duration_planned=st.duration,
                        participants=st.participants,
                        winners=[(u, st.participants.get(u, {}).get("name", f"id{u}")) for u in st.winners],
                        prize=prize,
                    )
                except Exception:
                    pass
                drop_sport(cid)
                await message.answer("✅ Все призы разыграны. Игра завершена.")
        else:
            left = max(0, st.tries_per_user - st.attempts[uid])
            tries_left_line = f" Попыток осталось: <b>{left}</b>" if st.tries_per_user > 1 else ""
            try:
                await message.reply(f"{cfg['miss_text']}{tries_left_line}")
            except Exception:
                pass


# =============== Таймер завершения ===============
async def _finish_loop(bot: Bot, chat_id: int) -> None:
    try:
        st = get_sport(chat_id)
        if not st or not st.deadline:
            return
        # подождём до дедлайна
        await asyncio.sleep(max(0, (st.deadline - datetime.now(timezone.utc)).total_seconds()))
        st = get_sport(chat_id)
        if not st or not st.running:
            return
        cfg = SPORTS.get(st.kind, {})
        winners = sorted(st.winners.items(), key=lambda x: x[1], reverse=True)
        if not winners:
            await bot.send_message(
                chat_id,
                f"⏰ <b>Время вышло.</b> {cfg.get('title','Игра')} закрыта — никто не выиграл."
            )
        else:
            head = f"⏰ <b>Время вышло — {cfg.get('title','Игра')} закрыта!</b>\n\n"
            lines = [head + "🏆 <b>Победители:</b>"]
            for uid, count in winners[:10]:
                lines.append(f"   • <code>{uid}</code> — {count} приз(ов)")
            await bot.send_message(chat_id, "\n".join(lines))
        # v25: пост-игровой отчёт админам
        try:
            chat = await bot.get_chat(chat_id)
            chat_title = chat.title
        except Exception:
            chat_title = None
        try:
            await send_post_game_report(
                bot,
                chat_id=chat_id,
                chat_title=chat_title,
                game_type=st.kind,
                game_label=f"{cfg.get('emoji','')} {cfg.get('title', st.kind)}",
                started_at=st.started_at,
                duration_planned=st.duration,
                participants=st.participants,
                winners=[(u, st.participants.get(u, {}).get("name", f"id{u}")) for u, _c in winners],
                prize=st.prize,
            )
        except Exception:
            pass
        drop_sport(chat_id)
    except asyncio.CancelledError:
        return
    except Exception:
        pass


# Чтобы /edit и /stop могли видеть sports — экспорт.
def get_all_sport_states() -> dict[int, SportState]:
    return dict(_states)
