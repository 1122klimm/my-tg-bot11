"""v34: /randommedved — раздаёт мишек случайным АКТИВНЫМ людям в чате.

Алгоритм скоринга (за последние ~60 минут):
  + сообщения (баллы пропорционально количеству, но с насыщением)
  + длинные осмысленные сообщения (>20 символов, >3 разных слов)
  − спам: повторяющиеся сообщения, флуд (много сообщений за короткое время),
    очень короткие («ку», «+», стикеры/эмодзи без текста), сильно повторяющиеся слова.

Призы выпадают РЕДКО: бот раз в N минут (по таймеру) проверяет топ активных
и с низкой вероятностью даёт приз одному из них (или нескольким при x<N>).
"""
from __future__ import annotations
import asyncio
import random
import re
import time as _t
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional

from aiogram import Router, F, Bot
from aiogram.enums import ChatType
from aiogram.filters import Command, Filter
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from access import is_admin, username_of, remember_username, remember_win, notify_win, is_ignored
from utils import storage, stats_push
from utils.chat_admins import is_chat_admin
from utils.duration import parse_duration, format_duration
from utils.report import send_post_game_report
from utils.win_photo import send_win_photo, send_start_photo
from game import drop_all_games, MSK
from help_texts import NO_ACCESS, EVENT_FOOTER

router = Router(name="randommedved")

ACTIVITY_WINDOW_SEC = 3600  # анализ активности за последний час


class ActiveRandomMedvedFilter(Filter):
    async def __call__(self, message: Message) -> bool:
        st = get_rm(message.chat.id)
        return bool(st and st.running)


@dataclass
class _UserActivity:
    name: str = ""
    # деки (timestamp, text) за последний час
    msgs: deque = field(default_factory=deque)
    # для определения «именно общается»: уникальные слова за час
    unique_words: set = field(default_factory=set)
    # счётчик повторов одного и того же сообщения
    last_text_norm: str = ""
    repeat_streak: int = 0
    won_this_event: int = 0

    def prune(self, now: float):
        cutoff = now - ACTIVITY_WINDOW_SEC
        while self.msgs and self.msgs[0][0] < cutoff:
            self.msgs.popleft()

    def score(self, now: float) -> float:
        self.prune(now)
        if not self.msgs:
            return 0.0
        n = len(self.msgs)
        # 1) количество — насыщение: log-подобно
        score_count = min(8.0, n ** 0.6)
        # 2) осмысленные сообщения
        meaningful = 0
        total_chars = 0
        repeats = 0
        all_words: list[str] = []
        prev_norm = ""
        for _ts, text in self.msgs:
            t = (text or "").strip()
            if not t:
                continue
            total_chars += len(t)
            words = re.findall(r"\w+", t.lower())
            all_words.extend(words)
            uniq_in_msg = set(words)
            if len(t) >= 20 and len(uniq_in_msg) >= 4:
                meaningful += 1
            norm = re.sub(r"\s+", " ", t.lower())
            if norm and norm == prev_norm:
                repeats += 1
            prev_norm = norm
        score_meaningful = min(6.0, meaningful * 1.2)
        # 3) разнообразие лексики
        unique_ratio = (len(set(all_words)) / max(1, len(all_words)))
        score_diversity = unique_ratio * 4.0
        # 4) штрафы
        # флуд: больше 30 сообщений/час -> штраф
        flood_penalty = max(0.0, (n - 30) * 0.15)
        # повторы
        repeat_penalty = repeats * 1.5
        # короткие/мусорные
        avg_len = total_chars / max(1, n)
        short_penalty = 3.0 if avg_len < 4 else (1.5 if avg_len < 8 else 0.0)
        score = score_count + score_meaningful + score_diversity - flood_penalty - repeat_penalty - short_penalty
        return max(0.0, score)


@dataclass
class RandomMedvedState:
    chat_id: int
    duration: int = 0
    deadline: Optional[datetime] = None
    prizes_left: int = 1
    prizes_total: int = 1
    prize: str = ""
    running: bool = False
    started_at: Optional[datetime] = None
    # uid -> _UserActivity
    users: dict = field(default_factory=dict)
    # лог победителей
    winners_log: list = field(default_factory=list)
    task: Optional[asyncio.Task] = None
    drop_task: Optional[asyncio.Task] = None
    # минимальный балл, чтобы попасть в кандидаты
    min_score: float = 4.0
    # участники для отчёта
    participants: dict = field(default_factory=dict)
    # v37: интервал между попытками выдать приз (секунды)
    every_sec: int = 3600
    # v37: шанс выдачи на каждом тике (0..1)
    drop_chance: float = 0.25

    def deadline_msk_str(self) -> str:
        if not self.deadline:
            return "—"
        return self.deadline.astimezone(MSK).strftime("%H:%M:%S")


_states: dict[int, RandomMedvedState] = {}


def get_rm(cid: int) -> Optional[RandomMedvedState]:
    return _states.get(cid)


def drop_rm(cid: int) -> None:
    s = _states.pop(cid, None)
    if s:
        for t in (s.task, s.drop_task):
            if t and not t.done():
                t.cancel()


def _stop_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="⛔ Остановить", callback_data="stop:randommedved")
    ]])


@router.message(Command(commands=["randommedved", "rmedved", "rm"]))
async def cmd_randommedved(message: Message, bot: Bot):
    stats_push.report_start(message, "randommedved")
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await message.reply("Запускать можно только в групповом чате.")
        return
    if not is_admin(message.from_user.id):
        await message.reply(NO_ACCESS)
        return

    parts = (message.text or "").split()
    count = 1
    secs = 0
    prize_tokens: list[str] = []
    every_sec = 3600
    drop_chance = 0.25
    for tok in parts[1:]:
        low = tok.lower()
        if low.startswith("x") and low[1:].isdigit():
            count = max(1, int(low[1:]))
            continue
        if low.startswith("every="):
            d = parse_duration(low.split("=", 1)[1])
            if d:
                every_sec = max(30, d)
            continue
        if low.startswith("chance="):
            try:
                v = float(low.split("=", 1)[1].rstrip("%").replace(",", "."))
                drop_chance = max(0.01, min(1.0, v / 100.0 if v > 1 else v))
            except Exception:
                pass
            continue
        if not secs:
            d = parse_duration(low)
            if d:
                secs = d
                continue
        prize_tokens.append(tok)
    prize = " ".join(prize_tokens).strip() or storage.get().get("prize_url", "") or "🐻 Мишка"

    drop_all_games(message.chat.id)
    drop_rm(message.chat.id)
    deadline = datetime.now(timezone.utc) + timedelta(seconds=secs) if secs else None
    st = RandomMedvedState(
        chat_id=message.chat.id, duration=secs, deadline=deadline,
        prizes_left=count, prizes_total=count, prize=prize,
        running=True, started_at=datetime.now(timezone.utc),
        every_sec=every_sec, drop_chance=drop_chance,
    )
    _states[message.chat.id] = st
    st.drop_task = asyncio.create_task(_drop_loop(bot, message.chat.id))
    if secs:
        st.task = asyncio.create_task(_finish_loop(bot, message.chat.id))

    time_line = (f"⏱ <b>Время:</b> {format_duration(secs)}\n"
                 f"🎯 <b>Финиш:</b> {st.deadline_msk_str()} по МСК") if secs \
                else "⏱ <b>Время:</b> до <code>/stop</code>"
    await send_start_photo(
        bot, message.chat.id, "randommedved",
        "🎁 <b>Случайные мишки запущены!</b>\n"
        f"{time_line}\n"
        f"🏆 <b>Призов:</b> <b>{count}</b>\n"
        f"🕒 <b>Проверка каждые:</b> {format_duration(every_sec)} (шанс {int(drop_chance*100)}%)\n"
        f"🎁 <b>Приз:</b> {prize}\n\n"
        "Мишки падают <b>редко</b> и достаются только <b>активным</b> участникам.\n"
        "Просто общайтесь в чате — бот сам выберет, кому повезёт."
        f"{EVENT_FOOTER}",
        reply_markup=_stop_kb(),
    )


# ===== учёт сообщений =====
SERVICE_ATTRS = (
    "boost_added", "new_chat_members", "left_chat_member", "pinned_message",
    "new_chat_title", "new_chat_photo", "delete_chat_photo",
    "group_chat_created", "supergroup_chat_created", "channel_chat_created",
    "message_auto_delete_timer_changed", "video_chat_started", "video_chat_ended",
    "video_chat_participants_invited", "video_chat_scheduled",
    "forum_topic_created", "forum_topic_edited", "forum_topic_closed", "forum_topic_reopened",
    "users_shared", "chat_shared",
    "giveaway", "giveaway_created", "giveaway_winners", "giveaway_completed",
)


@router.message(F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}), ActiveRandomMedvedFilter())
async def on_chat_message(message: Message, bot: Bot):
    if any(getattr(message, a, None) for a in SERVICE_ATTRS):
        return
    if not message.from_user or message.from_user.is_bot:
        return
    if message.text and message.text.startswith("/"):
        return
    st = get_rm(message.chat.id)
    if not st or not st.running:
        return
    uid = message.from_user.id
    if is_ignored(uid, "randommedved"):
        return
    try:
        if await is_chat_admin(bot, message.chat.id, uid):
            return
    except Exception:
        pass
    remember_username(message)
    text = message.text or message.caption or ""
    name = username_of(message)
    now = _t.time()
    ua = st.users.setdefault(uid, _UserActivity(name=name))
    ua.name = name
    ua.msgs.append((now, text))
    ua.prune(now)
    info = st.participants.setdefault(uid, {"name": name, "messages": 0, "stars": 0})
    info["name"] = name
    info["messages"] += 1


# ===== раздача призов =====
async def _drop_loop(bot: Bot, chat_id: int):
    """Раз в every_sec пытается выдать приз."""
    try:
        while True:
            st = get_rm(chat_id)
            if not st or not st.running or st.prizes_left <= 0:
                return
            # стартовая/между-тиками пауза
            base = max(30, st.every_sec)
            jitter = random.randint(-base // 10, base // 10)
            await asyncio.sleep(max(15, base + jitter))
            st = get_rm(chat_id)
            if not st or not st.running or st.prizes_left <= 0:
                return
            await _try_drop(bot, chat_id)
    except asyncio.CancelledError:
        return
    except Exception:
        return


async def _try_drop(bot: Bot, chat_id: int):
    st = get_rm(chat_id)
    if not st or not st.running:
        return
    now = _t.time()
    ranked: list[tuple[int, _UserActivity, float]] = []
    for uid, ua in st.users.items():
        s = ua.score(now)
        if s >= st.min_score:
            ranked.append((uid, ua, s))
    if not ranked:
        return
    # шанс выпадения приза за этот тик
    if random.random() > float(st.drop_chance or 0.25):
        return
    # взвешенный рандом по очкам
    weights = [r[2] ** 2 for r in ranked]
    pick = random.choices(ranked, weights=weights, k=1)[0]
    uid, ua, _score = pick
    st.prizes_left -= 1
    ua.won_this_event += 1
    st.winners_log.append((uid, ua.name))
    prize = st.prize or storage.get().get("prize_url", "") or "🐻 Мишка"
    remember_win(uid, ua.name, prize, "randommedved")

    caption = (
        f"🎁 <b>{ua.name} получил {prize} от бота за активность в чате!</b> 🐻\n\n"
        "✅ Подарок уже в пути!\n\n"
        "❗️ Пиши больше сообщений в чате — и лутай подарочки чаще!"
    )
    try:
        await send_win_photo(bot, chat_id, "randommedved", caption)
    except Exception:
        pass
    try:
        chat = await bot.get_chat(chat_id)
        await notify_win(bot, chat.title or "", ua.name, prize, "randommedved")
    except Exception:
        pass
    stats_push.push_event(
        chat_id=chat_id, chat_title=None,
        user_id=uid, username=None, full_name=ua.name, avatar_url=None,
        game_type="randommedved", event_type="won", prize=prize,
        stars_value=0, ton_value=0, meta={"score": round(_score, 2)},
    )
    if st.prizes_left <= 0:
        st.running = False
        try:
            chat = await bot.get_chat(chat_id)
            chat_title = chat.title
        except Exception:
            chat_title = None
        try:
            await send_post_game_report(
                bot, chat_id=chat_id, chat_title=chat_title,
                game_type="randommedved", game_label="🎁 Случайные мишки",
                started_at=st.started_at, duration_planned=st.duration,
                participants=st.participants,
                winners=list(st.winners_log), prize=st.prize,
            )
        except Exception:
            pass
        try:
            await bot.send_message(chat_id, "✅ Все мишки разданы. Ивент завершён.")
        except Exception:
            pass
        drop_rm(chat_id)


async def _finish_loop(bot: Bot, chat_id: int):
    try:
        st = get_rm(chat_id)
        if not st or not st.deadline:
            return
        await asyncio.sleep(max(0, (st.deadline - datetime.now(timezone.utc)).total_seconds()))
        st = get_rm(chat_id)
        if not st or not st.running:
            return
        st.running = False
        try:
            await bot.send_message(chat_id, "⏰ <b>Время вышло!</b> Раздача мишек завершена.")
        except Exception:
            pass
        try:
            chat = await bot.get_chat(chat_id)
            chat_title = chat.title
        except Exception:
            chat_title = None
        try:
            await send_post_game_report(
                bot, chat_id=chat_id, chat_title=chat_title,
                game_type="randommedved", game_label="🎁 Случайные мишки",
                started_at=st.started_at, duration_planned=st.duration,
                participants=st.participants,
                winners=list(st.winners_log), prize=st.prize,
            )
        except Exception:
            pass
        drop_rm(chat_id)
    except asyncio.CancelledError:
        return
    except Exception:
        return