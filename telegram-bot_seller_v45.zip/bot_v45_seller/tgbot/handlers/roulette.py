"""Рулетки (медведь 🐻 / NFT 💎) и игра «Угадай число» 🔢."""
import asyncio
import random
from datetime import datetime, timezone, timedelta

from aiogram import Router, F, Bot
from aiogram.enums import ChatType
from aiogram.filters import Command, Filter
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from access import is_admin, username_of, remember_username, remember_win, notify_win, is_ignored
from utils import storage
from utils import stats_push
from utils import secret_mode
from utils.report import send_post_game_report
from utils.ai import chat_completion
from utils.win_photo import send_win_photo, send_start_photo
from utils.duration import parse_duration, format_duration
from game import (
    RouletteState, NumberState,
    get_roulette, set_roulette, drop_roulette, get_all_roulettes,
    get_number, set_number, drop_number,
    drop_all_games, deadline_notifier,
)
from help_texts import NO_ACCESS, EVENT_FOOTER

router = Router(name="roulette")
DURATION_TOKEN = ("s", "m", "h", "d")


class HasRouletteOrNumberFilter(Filter):
    async def __call__(self, message: Message) -> bool:
        cid = message.chat.id
        if get_number(cid):
            return True
        if get_all_roulettes(cid):
            return True
        return False


def _split_time(tokens: list):
    time_parts = []
    i = 0
    for tok in tokens:
        t = tok.lower()
        if t.isdigit() or (len(t) >= 2 and t[-1] in DURATION_TOKEN and t[:-1].isdigit()):
            time_parts.append(tok); i += 1
        else:
            break
    if not time_parts:
        return 0, tokens
    secs = parse_duration(" ".join(time_parts)) or 0
    return secs, tokens[i:]


def _extract_hints(tokens: list):
    """Парсит h<N> — количество AI-подсказок."""
    count = 0
    rest = []
    for tok in tokens:
        low = tok.lower()
        if low.startswith("h") and low[1:].isdigit():
            count = max(0, min(20, int(low[1:])))
        else:
            rest.append(tok)
    return count, rest


def _extract_count(tokens: list):
    count = 0
    rest = []
    for tok in tokens:
        low = tok.lower()
        if low.startswith("x") and low[1:].isdigit():
            count = max(1, int(low[1:]))
        else:
            rest.append(tok)
    return count, rest


def _stop_kb(kind: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="⛔ Остановить игру", callback_data=f"stop:{kind}")
    ]])


# ============================================================
# /medved и /nft
# ============================================================
async def _start_roulette(message: Message, bot: Bot, kind: str, emoji: str, title: str):
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await message.reply("Запускать можно только в групповом чате.")
        return
    if not is_admin(message.from_user.id):
        await message.reply(NO_ACCESS)
        return

    parts = (message.text or "").split()
    if len(parts) < 2:
        await message.reply(
            f"Использование: <code>/{kind} &lt;шанс%&gt; [x&lt;кол-во&gt;] [время] [приз]</code>\n"
            f"Пример: <code>/{kind} 5 x10 1h nft</code>"
        )
        return

    try:
        chance = float(parts[1].replace(",", "."))
    except ValueError:
        await message.reply("Шанс должен быть числом.")
        return
    if not (0 < chance <= 100):
        await message.reply("Шанс — число от 0 до 100.")
        return

    rest_tokens = parts[2:]
    count, rest_tokens = _extract_count(rest_tokens)
    secs, rest_tokens = _split_time(rest_tokens)
    prize = " ".join(rest_tokens).strip() or storage.get().get("prize_url", "")

    deadline = datetime.now(timezone.utc) + timedelta(seconds=secs) if secs else None
    st = RouletteState(
        chat_id=message.chat.id, kind=kind, emoji=emoji, title=title,
        chance_percent=chance, prizes_left=count, prize=prize, duration=secs,
        deadline=deadline, running=True,
        started_at=datetime.now(timezone.utc),
    )
    drop_roulette(message.chat.id, kind)
    set_roulette(st)
    if secs:
        _schedule_roulette(bot, st, title)

    count_line = f"\n🏆 <b>Призов:</b> <b>{count}</b>" if count else "\n🏆 <b>Призов:</b> <b>∞</b> (до <code>/stop</code>)"
    time_line = (f"\n⏱ <b>Время:</b> {format_duration(secs)}\n"
                 f"🎯 <b>Финиш:</b> {st.deadline_msk_str()} по МСК") if secs else \
                "\n⏱ <b>Время:</b> до <code>/stop</code>"
    prize_line = f"\n🎁 <b>Приз:</b> {prize}" if prize else "\n🎁 <b>Приз:</b> <i>не задан</i>"
    await send_start_photo(
        bot, message.chat.id, kind,
        f"{emoji} <b>Ивент «{title}» запущен!</b>\n"
        f"🎲 <b>Шанс:</b> {chance}% на каждое сообщение"
        f"{count_line}{time_line}{prize_line}\n\n"
        f"Просто пишите в чат — у каждого сообщения есть шанс выиграть!"
        f"{EVENT_FOOTER}",
        reply_markup=_stop_kb(kind),
    )


@router.message(Command(commands=["medved", "bear"]))
async def cmd_medved(message: Message, bot: Bot):
    stats_push.report_start(message, "medved")
    await _start_roulette(message, bot, "medved", "🐻", "Медведь")


@router.message(Command(commands=["nft"]))
async def cmd_nft(message: Message, bot: Bot):
    stats_push.report_start(message, "nft")
    await _start_roulette(message, bot, "nft", "💎", "NFT")


async def _finish_roulette(bot: Bot, chat_id: int, kind: str, title: str):
    notifier = asyncio.create_task(
        deadline_notifier(bot, chat_id, lambda c, k=kind: get_roulette(c, k), title)
    )
    try:
        st = get_roulette(chat_id, kind)
        if not st or not st.deadline:
            return
        await asyncio.sleep(max(0, (st.deadline - datetime.now(timezone.utc)).total_seconds()))
        st = get_roulette(chat_id, kind)
        if not st or not st.running:
            return
        await bot.send_message(chat_id, f"⏰ <b>Время вышло!</b> Ивент «{st.title}» завершён.")
        # v33: пост-игровой отчёт админам в ЛС
        try:
            chat = await bot.get_chat(chat_id)
            chat_title = chat.title
        except Exception:
            chat_title = None
        try:
            await send_post_game_report(
                bot,
                chat_id=chat_id,
                chat_title=chat_title,
                game_type=kind,
                game_label=f"{st.emoji} {st.title}",
                started_at=st.started_at,
                duration_planned=st.duration,
                participants=st.participants,
                messages_total=st.messages_total,
                stars_spent=int(st.stars_spent or 0),
                ton_spent=0.0,
                winners=list(st.winners_log),
                prize=st.prize or "",
            )
        except Exception:
            pass
        drop_roulette(chat_id, kind)
    except asyncio.CancelledError:
        return
    except Exception:
        pass
    finally:
        if not notifier.done():
            notifier.cancel()


def _schedule_roulette(bot: Bot, st: RouletteState, title: str):
    if st.task and not st.task.done():
        st.task.cancel()
    st.task = asyncio.create_task(_finish_roulette(bot, st.chat_id, st.kind, title))


# ============================================================
# /number — угадай число (с x<N> победителей)
# ============================================================
@router.message(Command(commands=["number", "guess"]))
async def cmd_number(message: Message, bot: Bot):
    stats_push.report_start(message, "number")
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await message.reply("Запускать можно только в групповом чате.")
        return
    if not is_admin(message.from_user.id):
        await message.reply(NO_ACCESS)
        return

    parts = (message.text or "").split()
    if len(parts) < 2:
        await message.reply(
            "Использование: <code>/number [время] &lt;от&gt;-&lt;до&gt; [x&lt;победителей&gt;] [приз]</code>\n"
            "Пример: <code>/number 5m 1-1000 x3 nft</code>"
        )
        return

    tokens = parts[1:]
    secs, tokens = _split_time(tokens)
    if not tokens:
        await message.reply("Нужно указать диапазон, например <code>1-1000</code>.")
        return
    range_token = tokens[0]
    if "-" not in range_token:
        await message.reply("Диапазон в формате <code>от-до</code>.")
        return
    try:
        a, b = range_token.split("-", 1)
        rfrom = int(a); rto = int(b)
    except ValueError:
        await message.reply("Диапазон должен состоять из чисел.")
        return
    if rfrom >= rto:
        await message.reply("«От» должно быть меньше «до».")
        return

    rest = tokens[1:]
    winners, rest = _extract_count(rest)
    hints_count, rest = _extract_hints(rest)
    if winners == 0:
        winners = 1
    prize = " ".join(rest).strip() or storage.get().get("prize_url", "")
    secret = random.randint(rfrom, rto)

    deadline = datetime.now(timezone.utc) + timedelta(seconds=secs) if secs else None
    st = NumberState(
        chat_id=message.chat.id, secret=secret, range_from=rfrom, range_to=rto,
        prize=prize, duration=secs, deadline=deadline, running=True,
        winners_count=winners,
        hints_count=hints_count,
        hint_low=rfrom, hint_high=rto,
    )
    drop_number(message.chat.id)
    set_number(st)
    if secs:
        _schedule_number(bot, st)
    if hints_count > 0 and secs:
        st.hints_task = asyncio.create_task(_hints_loop(bot, st.chat_id))

    time_line = (f"\n⏱ <b>Время:</b> {format_duration(secs)}\n"
                 f"🎯 <b>Финиш:</b> {st.deadline_msk_str()} по МСК") if secs else \
                "\n⏱ <b>Время:</b> до <code>/stop</code>"
    prize_line = f"\n🎁 <b>Приз:</b> {prize}" if prize else "\n🎁 <b>Приз:</b> <i>не задан</i>"
    winners_line = f"\n🏆 <b>Победителей:</b> <b>{winners}</b>" + \
                   (" <i>(топ ближайших к загаданному, если никто не угадает точно)</i>" if winners > 1 else "")
    await send_start_photo(
        bot, message.chat.id, "number",
        f"🔢 <b>Угадай число!</b>\n"
        f"📏 <b>Диапазон:</b> от <b>{rfrom}</b> до <b>{rto}</b>"
        f"{winners_line}{time_line}{prize_line}\n\n"
        f"Я загадал число и отправил его всем админам в ЛС. "
        f"Назовите своё число — кто угадает точно или окажется ближе всех, тот и победил!"
        f"{EVENT_FOOTER}",
        reply_markup=_stop_kb("number"),
    )

    chat_title = message.chat.title or str(message.chat.id)
    secret_text = (
        f"🔢 <b>Загадано число:</b> <code>{secret}</code>\n"
        f"💬 <b>Чат:</b> {chat_title}\n"
        f"📏 Диапазон: {rfrom}-{rto}\n"
        f"🏆 Победителей: {winners}"
    )
    for uid in storage.get().get("admins", []):
        try:
            await bot.send_message(uid, secret_text)
        except Exception:
            pass


async def _finish_number(bot: Bot, chat_id: int):
    notifier = asyncio.create_task(deadline_notifier(bot, chat_id, get_number, "Угадай число"))
    try:
        st = get_number(chat_id)
        if not st or not st.deadline:
            return
        await asyncio.sleep(max(0, (st.deadline - datetime.now(timezone.utc)).total_seconds()))
        st = get_number(chat_id)
        if not st or not st.running:
            return

        # v24: победители = сначала точно угадавшие, затем добор по близости
        prize = st.prize or storage.get().get("prize_url", "")
        already_uids = {u for u, _ in st.exact_winners}
        winners_list: list[tuple[int, str, int | None]] = []
        for uid, uname in st.exact_winners:
            winners_list.append((uid, uname, None))  # None = точно угадал
        if len(winners_list) < st.winners_count and st.guesses:
            ranked = sorted(
                ((u, n, g) for u, (n, g) in st.guesses.items() if u not in already_uids),
                key=lambda x: (abs(x[2] - st.secret), x[0])
            )
            need = st.winners_count - len(winners_list)
            for uid, uname, guess in ranked[:need]:
                winners_list.append((uid, uname, guess))
        if winners_list:
            lines = [f"⏰ <b>Время вышло!</b> Загаданное число — <b>{st.secret}</b>.",
                     f"🏆 <b>Победител{'ь' if len(winners_list) == 1 else 'и'}:</b>"]
            for uid, uname, guess in winners_list:
                if guess is None:
                    lines.append(f"   • {uname} — <b>угадал точно</b> 🎯")
                else:
                    diff = abs(guess - st.secret)
                    lines.append(f"   • {uname} — назвал <b>{guess}</b> (промах <b>{diff}</b>)")
                # remember_win уже был вызван для exact_winners при попадании; не дублируем
                if guess is not None:
                    remember_win(uid, uname, prize, "number")
                    stats_push.push_event(
                        chat_id=chat_id, chat_title=None,
                        user_id=uid, username=None, full_name=uname, avatar_url=None,
                        game_type="number", event_type="won",
                        prize=prize, stars_value=0, ton_value=0,
                        meta={"guess": guess, "secret": st.secret, "diff": diff},
                    )
            if prize:
                lines.append(f"\n🎁 <b>Приз:</b> {prize}")
            await send_win_photo(bot, chat_id, "number", caption="\n".join(lines))
            try:
                chat = await bot.get_chat(chat_id)
                for uid, uname, _g in winners_list:
                    await notify_win(bot, chat.title or "", uname, prize, "number")
            except Exception:
                pass
        else:
            await bot.send_message(
                chat_id,
                f"⏰ <b>Время вышло!</b> Никто не назвал число. Загаданное было <b>{st.secret}</b>."
            )
        drop_number(chat_id)
    except asyncio.CancelledError:
        return
    except Exception:
        pass
    finally:
        if not notifier.done():
            notifier.cancel()


def _schedule_number(bot: Bot, st: NumberState):
    if st.task and not st.task.done():
        st.task.cancel()
    st.task = asyncio.create_task(_finish_number(bot, st.chat_id))


SERVICE_ATTRS = (
    "boost_added", "new_chat_members", "left_chat_member", "pinned_message",
    "new_chat_title", "new_chat_photo", "delete_chat_photo",
    "group_chat_created", "supergroup_chat_created", "channel_chat_created",
    "message_auto_delete_timer_changed", "video_chat_started", "video_chat_ended",
    "video_chat_participants_invited", "video_chat_scheduled",
    "forum_topic_created", "forum_topic_edited", "forum_topic_closed", "forum_topic_reopened",
    "users_shared", "chat_shared",
    "giveaway", "giveaway_created", "giveaway_winners", "giveaway_completed",
)


@router.message(F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}), HasRouletteOrNumberFilter())
async def on_chat_msg(message: Message, bot: Bot):
    if any(getattr(message, a, None) for a in SERVICE_ATTRS):
        return
    if not message.from_user or message.from_user.is_bot:
        return
    if message.text and message.text.startswith("/"):
        return
    remember_username(message)
    cid = message.chat.id

    # 1) Угадай число
    nst = get_number(cid)
    if nst and nst.running and message.text and not is_ignored(message.from_user.id, "number"):
        text = message.text.strip()
        if text.lstrip("-").isdigit():
            try:
                guess = int(text)
                username = username_of(message)
                # запоминаем последнюю догадку для финала по близости
                if nst.range_from <= guess <= nst.range_to:
                    nst.guesses[message.from_user.id] = (username, guess)
                if guess == nst.secret:
                    prize = nst.prize or storage.get().get("prize_url", "")
                    # если победителей > 1, не закрываем сразу — ждём времени
                    if nst.winners_count == 1:
                        remember_win(message.from_user.id, username, prize, "number")
                        stats_push.push_event(
                            chat_id=cid, chat_title=message.chat.title,
                            user_id=message.from_user.id,
                            username=message.from_user.username,
                            full_name=message.from_user.full_name, avatar_url=None,
                            game_type="number", event_type="won",
                            prize=prize, stars_value=0, ton_value=0,
                            meta={"secret": nst.secret, "exact": True},
                        )
                        nst.running = False
                        drop_number(cid)
                        prize_line = f"\n🎁 <b>Приз:</b> {prize}" if prize else ""
                        await send_win_photo(
                            bot, cid, "number",
                            caption=f"🏆 <b>УГАДАЛ!</b> {username} назвал число <b>{nst.secret}</b>!{prize_line}",
                        )
                        try:
                            chat = await bot.get_chat(cid)
                            await notify_win(bot, chat.title or "", username, prize, "number")
                        except Exception:
                            pass
                        return
                    else:
                        # v24: режим нескольких победителей.
                        # Если этот юзер уже угадывал — игнор.
                        already = any(uid == message.from_user.id for uid, _ in nst.exact_winners)
                        if already:
                            try:
                                await message.delete()
                            except Exception:
                                pass
                            return
                        nst.exact_winners.append((message.from_user.id, username))
                        prize = nst.prize or storage.get().get("prize_url", "")
                        remember_win(message.from_user.id, username, prize, "number")
                        stats_push.push_event(
                            chat_id=cid, chat_title=message.chat.title,
                            user_id=message.from_user.id,
                            username=message.from_user.username,
                            full_name=message.from_user.full_name, avatar_url=None,
                            game_type="number", event_type="won",
                            prize=prize, stars_value=0, ton_value=0,
                            meta={"secret": nst.secret, "exact": True},
                        )
                        # удаляем сообщение с числом, чтобы остальные не подглядели
                        try:
                            await message.delete()
                        except Exception:
                            pass
                        left = nst.winners_count - len(nst.exact_winners)
                        if left > 0:
                            await bot.send_message(
                                cid,
                                f"🎯 <b>{username} угадал число!</b> Осталось <b>{left}</b> призов — продолжайте угадывать!"
                            )
                            try:
                                chat = await bot.get_chat(cid)
                                await notify_win(bot, chat.title or "", username, prize, "number")
                            except Exception:
                                pass
                            return
                        # все слоты заняты — завершаем игру сразу
                        nst.running = False
                        drop_number(cid)
                        prize_line = f"\n🎁 <b>Приз:</b> {prize}" if prize else ""
                        winners_lines = "\n".join(
                            f"   • {un}" for _u, un in nst.exact_winners
                        )
                        await send_win_photo(
                            bot, cid, "number",
                            caption=(
                                f"🏆 <b>Все призы разыграны!</b> Загаданное число — <b>{nst.secret}</b>.\n"
                                f"Победители ({len(nst.exact_winners)}):\n{winners_lines}{prize_line}"
                            ),
                        )
                        try:
                            chat = await bot.get_chat(cid)
                            await notify_win(bot, chat.title or "", username, prize, "number")
                        except Exception:
                            pass
                        return
            except ValueError:
                pass

    # 2) Рулетки
    for kind, st in get_all_roulettes(cid).items():
        if not st.running:
            continue
        if is_ignored(message.from_user.id, kind):
            continue
        # v33: накапливаем статистику за ивент (сообщения / звёзды / участники).
        msg_stars = int(getattr(message, "paid_star_count", 0) or 0)
        st.messages_total += 1
        if msg_stars:
            st.stars_spent += msg_stars
        uid = message.from_user.id
        uname = username_of(message)
        info = st.participants.setdefault(uid, {"name": uname, "messages": 0, "stars": 0})
        info["name"] = uname
        info["messages"] = int(info.get("messages", 0)) + 1
        if msg_stars:
            info["stars"] = int(info.get("stars", 0)) + msg_stars
        # v27: реальный шанс с учётом /secret. В чате показывали declared,
        # но раздаём призы по effective.
        # v33: учитываем личный win-шанс конкретного пользователя.
        eff_chance = secret_mode.effective_chance(
            cid, kind, st.chance_percent,
            user_id=message.from_user.id,
            username=(message.from_user.username or None),
        )
        if random.random() * 100 < eff_chance:
            username = uname
            prize = st.prize or storage.get().get("prize_url", "")
            remember_win(message.from_user.id, username, prize, kind)
            st.winners_log.append((message.from_user.id, username))
            prize_line = f"\n🎁 <b>Приз:</b> {prize}" if prize else ""
            left_decrement = ""
            if st.prizes_left:
                st.prizes_left -= 1
                left_decrement = f"\n🎯 <b>Осталось:</b> {st.prizes_left}"
            await send_win_photo(
                bot, cid, kind,
                caption=f"{st.emoji} <b>{username} выбил {st.title}!</b>{prize_line}{left_decrement}",
                reply_to_message_id=message.message_id,
            )
            try:
                chat = await bot.get_chat(cid)
                await notify_win(bot, chat.title or "", username, prize, kind)
            except Exception:
                pass
            if st.prizes_left == 0 and left_decrement:
                await message.answer(f"✅ Все призы «{st.title}» разыграны.")
                # v33: пост-игровой отчёт админам
                try:
                    chat = await bot.get_chat(cid)
                    chat_title = chat.title
                except Exception:
                    chat_title = None
                try:
                    await send_post_game_report(
                        bot,
                        chat_id=cid,
                        chat_title=chat_title,
                        game_type=kind,
                        game_label=f"{st.emoji} {st.title}",
                        started_at=st.started_at,
                        duration_planned=st.duration,
                        participants=st.participants,
                        messages_total=st.messages_total,
                        stars_spent=int(st.stars_spent or 0),
                        ton_spent=0.0,
                        winners=list(st.winners_log),
                        prize=st.prize or "",
                    )
                except Exception:
                    pass
                drop_roulette(cid, kind)
            return


# v20: AI-подсказки для /number — постепенно сужают диапазон
async def _hints_loop(bot: Bot, chat_id: int):
    """Раздаёт hints_count подсказок равномерно по времени раунда.

    Логика подсказок (от слабых к сильным):
      1-2: слабое сужение диапазона (~70% исходного)
      3-4: сужение до ~40%
      5+: близкие границы / "в середине" / словесные подсказки от AI
    """
    try:
        st = get_number(chat_id)
        if not st or not st.running or not st.duration or st.hints_count <= 0:
            return
        total_secs = st.duration
        n = st.hints_count
        # Раздаём подсказки между 20% и 90% таймера
        gap = total_secs * 0.7 / max(1, n)
        offset = total_secs * 0.2
        for i in range(n):
            await asyncio.sleep(gap if i > 0 else offset)
            st = get_number(chat_id)
            if not st or not st.running:
                return
            secret = st.secret
            full_range = st.range_to - st.range_from
            # Постепенное сужение: процент от исходного диапазона
            shrink_ratio = max(0.05, 0.7 - (i * 0.6 / n))
            half = max(1, int(full_range * shrink_ratio / 2))
            low = max(st.range_from, secret - half)
            high = min(st.range_to, secret + half)
            st.hint_low = low
            st.hint_high = high
            st.hints_sent = i + 1

            # Сильные подсказки (последние 1-2) — словесные через AI
            ai_hint = None
            if i >= n - 2 and n >= 3:
                ai_hint = await chat_completion(
                    system="Ты ведущий игры «угадай число». Дай одну короткую (1 предложение) подсказку про загаданное число, не называя его прямо. Можно говорить: чётное/нечётное, делится ли на что-то, цифровая сумма, ассоциация. Без эмодзи в начале.",
                    user=f"Загадано число {secret} в диапазоне {st.range_from}–{st.range_to}. Это подсказка #{i+1} из {n}. Дай тонкий намёк.",
                    max_tokens=80, temperature=0.8,
                )
            try:
                if ai_hint:
                    text = f"💡 <b>Подсказка #{i+1}/{n}:</b> {ai_hint.strip()}"
                else:
                    text = f"💡 <b>Подсказка #{i+1}/{n}:</b> число между <b>{low}</b> и <b>{high}</b>"
                await bot.send_message(chat_id, text)
            except Exception:
                pass
    except asyncio.CancelledError:
        return
    except Exception:
        return
