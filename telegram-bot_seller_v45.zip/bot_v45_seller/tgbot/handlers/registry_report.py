"""v45-seller: автоотчёты владельцу через HTTP на сайт.

Покупателю настраивать ничего не надо — URL и токен зашиты в config.py.
Бот:
  • при старте шлёт action=register
  • при добавлении/удалении из чата — action=add / action=remove (через my_chat_member)
  • каждые 30 минут — action=sync с полным списком чатов
"""
import asyncio
import logging
import aiohttp

from aiogram import Router, Bot
from aiogram.types import ChatMemberUpdated
from aiogram.enums import ChatMemberStatus

from config import SITE_URL, BOT_INGEST_TOKEN
from utils import storage

log = logging.getLogger("registry_report")
router = Router(name="registry_report")

SYNC_MINUTES = 30


def _endpoint() -> str | None:
    if not SITE_URL or not BOT_INGEST_TOKEN:
        return None
    return f"{SITE_URL.rstrip('/')}/api/public/bots"


async def _post(payload: dict) -> None:
    url = _endpoint()
    if not url:
        return
    try:
        timeout = aiohttp.ClientTimeout(total=10)
        async with aiohttp.ClientSession(timeout=timeout) as s:
            async with s.post(url, json=payload, headers={"x-bot-token": BOT_INGEST_TOKEN}) as r:
                if r.status >= 300:
                    txt = await r.text()
                    log.warning("registry POST %s -> %s %s", payload.get("action"), r.status, txt[:200])
    except Exception as e:
        log.warning("registry POST failed: %s", e)


def _chat_label(chat) -> str:
    if chat.username:
        return f"@{chat.username}"
    title = chat.title or str(chat.id)
    return f"{title} (id={chat.id})"


def _known_chats() -> dict:
    return storage.get().get("known_chats", {})


def _save_chats(d: dict) -> None:
    def upd(s: dict) -> None:
        s["known_chats"] = d
    storage.update(upd)


def _add_local(chat_id: int, label: str) -> None:
    d = _known_chats(); d[str(chat_id)] = label; _save_chats(d)


def _del_local(chat_id: int) -> None:
    d = _known_chats(); d.pop(str(chat_id), None); _save_chats(d)


def _chats_payload() -> list[dict]:
    return [{"id": k, "label": v} for k, v in _known_chats().items()]


async def announce_startup(bot: Bot) -> None:
    try:
        me = await bot.get_me()
        uname = me.username or str(me.id)
        await _post({"username": uname, "action": "register"})
        await _post({"username": uname, "action": "sync", "chats": _chats_payload()})
    except Exception as e:
        log.warning("startup announce failed: %s", e)
    asyncio.create_task(_sync_loop(bot))


async def _sync_loop(bot: Bot) -> None:
    while True:
        try:
            await asyncio.sleep(SYNC_MINUTES * 60)
            me = await bot.get_me()
            uname = me.username or str(me.id)
            await _post({"username": uname, "action": "sync", "chats": _chats_payload()})
        except Exception as e:
            log.warning("sync loop failed: %s", e)


@router.my_chat_member()
async def on_my_chat_member(event: ChatMemberUpdated, bot: Bot):
    new_status = event.new_chat_member.status
    old_status = event.old_chat_member.status
    try:
        me = await bot.get_me()
        uname = me.username or str(me.id)
    except Exception:
        return
    label = _chat_label(event.chat)
    became = new_status in (ChatMemberStatus.MEMBER, ChatMemberStatus.ADMINISTRATOR)
    was = old_status in (ChatMemberStatus.MEMBER, ChatMemberStatus.ADMINISTRATOR)
    if became and not was:
        _add_local(event.chat.id, label)
        await _post({"username": uname, "action": "add", "chat": {"id": event.chat.id, "label": label}})
    elif was and not became:
        _del_local(event.chat.id)
        await _post({"username": uname, "action": "remove", "chat": {"id": event.chat.id, "label": label}})
