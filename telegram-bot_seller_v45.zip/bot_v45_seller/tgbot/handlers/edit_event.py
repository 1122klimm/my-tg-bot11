"""v19: Универсальная команда /edit с интерактивным меню.

— /edit                                открывает меню выбора активного ивента
— у каждого ивента — кнопки полей; жмёшь поле → бот ждёт твой следующий
  ответ в чате как новое значение (без /setval).
— /edit <event> <field> <value>        прямой режим (как раньше)
— /editcancel                          отменить ожидание ввода

Поддерживаемые поля:
  time, prize, prizes, winners, chance, target,
  gift / giftstars (⭐), ton (TON),
  hints (для number),
  mode (для викторины: untilcorrect / fast / wait)
"""
import asyncio
from datetime import datetime, timezone, timedelta

from aiogram import Router, F, Bot
from aiogram.enums import ChatType
from aiogram.filters import Command
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton,
)

from access import is_admin
from utils.duration import parse_duration, format_duration
from game import (
    get_state, get_dice_state, get_number, get_goal, get_lottery, get_all_roulettes,
    get_quiz_state,
)
from handlers.sports import get_all_sport_states, SPORTS as _SPORTS
from help_texts import NO_ACCESS

router = Router(name="edit_event")

# pending: chat_id -> {admin_id, event, field, prompt_msg_id}
_pending: dict = {}


def _collect(cid: int):
    """Собираем все активные ивенты в чате: (kind, label, state)."""
    items = []
    s = get_state(cid)
    if s and s.running:
        items.append(("perebiv", "🎮 Перебив", s))
    d = get_dice_state(cid)
    if d and d.running:
        title = "🎲 Кубик" if d.game_type == "kubik" else "🎰 Казино"
        items.append((d.game_type, title, d))
    n = get_number(cid)
    if n and n.running:
        items.append(("number", "🔢 Угадай число", n))
    g = get_goal(cid)
    if g and g.running:
        items.append(("goal", f"🎯 Цель ({g.current}/{g.target})", g))
    lot = get_lottery(cid)
    if lot and lot.running:
        items.append(("lottery", f"🎟 Лотерея ({lot.total_tickets} б.)", lot))
    q = get_quiz_state(cid)
    if q and q.running:
        items.append(("viktorina", f"🧠 Викторина ({q.current_index}/{q.total_questions})", q))
    for kind, st in get_all_roulettes(cid).items():
        title = "🐻 Медведь" if kind == "medved" else "💎 NFT"
        items.append((kind, title, st))
    for cid2, sst in get_all_sport_states().items():
        if cid2 == cid and sst.running:
            cfg = _SPORTS.get(sst.kind, {})
            items.append((sst.kind, f"{cfg.get('emoji','')} {cfg.get('title', sst.kind)}", sst))
    # v42: randommedved
    try:
        from handlers.randommedved import get_rm
        rm = get_rm(cid)
        if rm and rm.running:
            items.append(("randommedved",
                          f"🎁 Случайные мишки ({rm.prizes_left}/{rm.prizes_total})", rm))
    except Exception:
        pass
    return items


# Поля по типам
FIELDS = {
    "perebiv":   [("time","⏱ Время"), ("prize","🎁 Приз"),
                  ("gift","⭐ Цена в звёздах"), ("ton","🪙 Цена в TON")],
    "kubik":     [("time","⏱ Время"), ("prizes","🏆 Кол-во призов"), ("prize","🎁 Приз")],
    "kazik":     [("mode","🎰 Режим (bar/viv/lemon/777/all)"), ("time","⏱ Время"), ("prizes","🏆 Кол-во призов"), ("prize","🎁 Приз")],
    "number":    [("time","⏱ Время"), ("winners","👥 Победителей"),
                  ("hints","💡 Кол-во подсказок"), ("prize","🎁 Приз")],
    "goal":      [("time","⏱ Время"), ("target","🎯 Цель"),
                  ("winners","👥 Победителей"), ("prize","🎁 Приз")],
    "lottery":   [("time","⏱ Время"), ("prizes","🏆 Призов"), ("prize","🎁 Приз")],
    "viktorina": [("mode","⚙️ Режим (fast/wait/untilcorrect)"),
                  ("time","⏱ Сек на вопрос"), ("prize","🎁 Приз")],
    "medved":    [("time","⏱ Время"), ("prizes","🏆 Осталось призов"),
                  ("chance","🎲 Шанс %"), ("prize","🎁 Приз")],
    "nft":       [("time","⏱ Время"), ("prizes","🏆 Осталось призов"),
                  ("chance","🎲 Шанс %"), ("prize","🎁 Приз")],
}
# v21: спорт-игры
for _k in ("basketball", "football", "bowling", "darts"):
    FIELDS[_k] = [("time","⏱ Время"), ("prizes","🏆 Призов"), ("prize","🎁 Приз")]

# v42: случайные мишки
FIELDS["randommedved"] = [
    ("time", "⏱ Время"),
    ("prizes", "🏆 Кол-во призов"),
    ("prize", "🎁 Приз"),
    ("every", "🕒 Интервал проверки"),
    ("chance", "🎲 Шанс выдачи %"),
]


# ---------------- /edit ----------------
@router.message(Command(commands=["edit", "редактировать"]))
async def cmd_edit(message: Message, bot: Bot):
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await message.reply("Команда работает только в чате.")
        return
    if not is_admin(message.from_user.id):
        await message.reply(NO_ACCESS)
        return

    parts = (message.text or "").split(maxsplit=3)
    # Прямой режим: /edit <event> <field> <value>
    if len(parts) >= 4:
        event, field, value = parts[1].lower(), parts[2].lower(), parts[3]
        ok, msg = await _apply(message.chat.id, event, field, value, bot)
        await message.reply(msg)
        return

    items = _collect(message.chat.id)
    if not items:
        await message.reply("📭 В чате нет активных ивентов.")
        return
    rows = []
    for kind, label, _st in items:
        rows.append([InlineKeyboardButton(text=f"✏️ {label}", callback_data=f"edit:ev:{kind}")])
    if len(items) > 1:
        rows.append([InlineKeyboardButton(text="🛠 Изменить ВСЕ ивенты сразу",
                                          callback_data="edit:all")])
    rows.append([InlineKeyboardButton(text="✖ Закрыть", callback_data="edit:cancel")])
    await message.answer(
        f"🛠 <b>Что редактируем?</b> <i>(активных: {len(items)})</i>\nВыбери ивент:",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
    )


@router.message(Command(commands=["editcancel", "cancel"]))
async def cmd_cancel(message: Message):
    if not is_admin(message.from_user.id):
        return
    if _pending.pop(message.chat.id, None):
        await message.reply("✖ Редактирование отменено.")


@router.callback_query(F.data == "edit:cancel")
async def cb_cancel(cb: CallbackQuery):
    if cb.from_user and is_admin(cb.from_user.id):
        _pending.pop(cb.message.chat.id, None)
        try:
            await cb.message.edit_text("✖ Редактирование отменено.")
        except Exception:
            pass
    await cb.answer()


@router.callback_query(F.data == "edit:back")
async def cb_back(cb: CallbackQuery):
    if not cb.from_user or not is_admin(cb.from_user.id):
        await cb.answer()
        return
    items = _collect(cb.message.chat.id)
    if not items:
        try:
            await cb.message.edit_text("📭 Нет активных ивентов.")
        except Exception:
            pass
        await cb.answer()
        return
    rows = [[InlineKeyboardButton(text=f"✏️ {label}", callback_data=f"edit:ev:{kind}")]
            for kind, label, _ in items]
    if len(items) > 1:
        rows.append([InlineKeyboardButton(text="🛠 Изменить ВСЕ ивенты сразу",
                                          callback_data="edit:all")])
    rows.append([InlineKeyboardButton(text="✖ Закрыть", callback_data="edit:cancel")])
    try:
        await cb.message.edit_text("🛠 <b>Что редактируем?</b>",
                                   reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    except Exception:
        pass
    await cb.answer()


@router.callback_query(F.data.startswith("edit:ev:"))
async def cb_pick_event(cb: CallbackQuery):
    if not cb.from_user or not is_admin(cb.from_user.id):
        await cb.answer("🚫 Только для админов.", show_alert=True)
        return
    event = cb.data.split(":")[2]
    fields = FIELDS.get(event)
    if not fields:
        await cb.answer("Этот ивент не редактируется.", show_alert=True)
        return
    rows = [
        [InlineKeyboardButton(text=label, callback_data=f"edit:fd:{event}:{field}")]
        for field, label in fields
    ]
    rows.append([InlineKeyboardButton(text="« Назад", callback_data="edit:back")])
    rows.append([InlineKeyboardButton(text="✖ Отмена", callback_data="edit:cancel")])
    try:
        await cb.message.edit_text(
            f"🛠 <b>Что меняем?</b> Ивент: <code>{event}</code>",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
        )
    except Exception:
        pass
    await cb.answer()


@router.callback_query(F.data == "edit:all")
async def cb_pick_all(cb: CallbackQuery):
    """«Все ивенты сразу» — показываем общие поля (time, prize)."""
    if not cb.from_user or not is_admin(cb.from_user.id):
        await cb.answer("🚫 Только для админов.", show_alert=True)
        return
    rows = [
        [InlineKeyboardButton(text="⏱ Время — у всех", callback_data="edit:fd:_all_:time")],
        [InlineKeyboardButton(text="🎁 Приз — у всех", callback_data="edit:fd:_all_:prize")],
        [InlineKeyboardButton(text="« Назад", callback_data="edit:back")],
    ]
    try:
        await cb.message.edit_text(
            "🛠 <b>Меняем у ВСЕХ активных ивентов:</b>",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
        )
    except Exception:
        pass
    await cb.answer()


HINT_BY_FIELD = {
    "time":    "Введите новое время: <code>30s</code>, <code>5m</code>, <code>1h 30m</code>",
    "prize":   "Введите новый приз (текст/ссылка):",
    "prizes":  "Введите новое количество призов (число):",
    "winners": "Введите новое количество победителей (число):",
    "chance":  "Введите новый шанс в % (например <code>25</code>):",
    "target":  "Введите новую цель (число сообщений):",
    "gift":    "Введите цену подарка в ⭐ (число):",
    "ton":     "Введите цену подарка в TON (число, можно дробное):",
    "hints":   "Сколько подсказок выдать за раунд (1-10)?",
    "mode":    "<b>Викторина:</b> <code>untilcorrect</code> / <code>fast</code> / <code>wait</code>\n"
               "<b>Казино:</b> <code>bar</code> / <code>viv</code> / <code>lemon</code> / <code>777</code> / <code>all</code>",
    "every":   "Введите интервал между проверками: <code>10m</code>, <code>1h</code>",
}


@router.callback_query(F.data.startswith("edit:fd:"))
async def cb_pick_field(cb: CallbackQuery):
    if not cb.from_user or not is_admin(cb.from_user.id):
        await cb.answer("🚫 Только для админов.", show_alert=True)
        return
    _, _, event, field = cb.data.split(":", 3)
    _pending[cb.message.chat.id] = {
        "admin_id": cb.from_user.id,
        "event": event,
        "field": field,
        "prompt_msg_id": cb.message.message_id,
    }
    hint = HINT_BY_FIELD.get(field, "Введите новое значение:")
    try:
        await cb.message.edit_text(
            f"✏️ <b>Меняю «{field}»</b> для <code>{event}</code>\n\n{hint}\n\n"
            f"<i>Просто отправь следующее сообщение в чат — оно станет значением.</i>\n"
            f"Для отмены: <code>/editcancel</code>"
        )
    except Exception:
        pass
    await cb.answer()


# Перехват «следующего сообщения от админа» как значения.
# Используем фильтр, который пропускает сообщение мимо хендлера, если pending нет —
# так aiogram передаст сообщение следующим роутерам (perebiv/goal/lottery).
from aiogram.filters import Filter as _Filter


class _PendingFilter(_Filter):
    async def __call__(self, message: Message) -> bool:
        pend = _pending.get(message.chat.id)
        if not pend:
            return False
        if not message.from_user or message.from_user.id != pend["admin_id"]:
            return False
        if not message.text or message.text.startswith("/"):
            return False
        return True


@router.message(F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}), _PendingFilter())
async def on_edit_value(message: Message, bot: Bot):
    pend = _pending.pop(message.chat.id, None)
    if not pend:
        return
    text = (message.text or "").strip()
    ok, msg = await _apply(message.chat.id, pend["event"], pend["field"], text, bot)
    await message.reply(msg)


# ---------------- Применение изменения ----------------
async def _apply(cid: int, event: str, field: str, value: str, bot: Bot) -> tuple:
    # Спец-режим: меняем у всех
    if event == "_all_":
        items = _collect(cid)
        if not items:
            return False, "📭 Нет активных ивентов."
        oks, errs = [], []
        for kind, _label, _st in items:
            if field not in {f for f, _ in FIELDS.get(kind, [])}:
                continue
            ok, _msg = await _apply(cid, kind, field, value, bot)
            (oks if ok else errs).append(kind)
        return True, f"✅ Применено к: <b>{', '.join(oks) or '—'}</b>" + \
            (f"\n⚠️ Ошибки: {', '.join(errs)}" if errs else "")

    state = None
    items = _collect(cid)
    for kind, _label, st in items:
        if kind == event:
            state = st
            break
    if state is None:
        return False, f"⚠️ Ивент <b>{event}</b> не активен."

    field = field.lower()
    try:
        if field == "time":
            # для викторины — это секунд на вопрос
            if event == "viktorina":
                try:
                    n = int(value)
                except ValueError:
                    return False, "⚠️ Нужно число секунд."
                if not 3 <= n <= 600:
                    return False, "⚠️ От 3 до 600 секунд."
                state.seconds_per_question = n
                return True, f"✅ Время на вопрос: <b>{n} сек</b>"
            secs = parse_duration(value)
            if not secs:
                return False, "⚠️ Не понял время. Пример: <code>5m</code>, <code>1h30m</code>."
            state.duration = secs
            state.deadline = datetime.now(timezone.utc) + timedelta(seconds=secs)
            if hasattr(state, "notified_marks"):
                state.notified_marks = set()
            await _reschedule(event, cid, bot)
            return True, f"✅ Время обновлено: <b>{format_duration(secs)}</b>\n🎯 Финиш: {state.deadline_msk_str()} МСК"

        if field == "prize":
            state.prize = value
            return True, f"✅ Приз обновлён: <b>{value}</b>"

        if field == "gift":
            n = int(value)
            if n < 0:
                return False, "⚠️ >= 0."
            if hasattr(state, "gift_stars"):
                state.gift_stars = n
                return True, f"✅ Цена подарка: <b>{n}</b> ⭐"
            return False, "⚠️ В этом ивенте нет цены подарка."

        if field == "ton":
            v = float(value.replace(",", "."))
            if v < 0:
                return False, "⚠️ >= 0."
            if hasattr(state, "gift_ton"):
                state.gift_ton = v
                return True, f"✅ Цена подарка: <b>{v:g}</b> TON"
            return False, "⚠️ В этом ивенте нет цены TON."

        if field == "prizes":
            n = int(value)
            if n < 1:
                return False, "⚠️ >= 1."
            if hasattr(state, "prizes_total"):
                delta = n - state.prizes_total
                state.prizes_total = n
                state.prizes_left = max(0, state.prizes_left + delta)
            elif hasattr(state, "prizes_count"):
                state.prizes_count = n
            elif hasattr(state, "prizes_left"):
                state.prizes_left = n
            else:
                return False, "⚠️ В этом ивенте нет «призов»."
            return True, f"✅ Призов: <b>{n}</b>"

        if field == "winners":
            n = int(value)
            if n < 1:
                return False, "⚠️ >= 1."
            if hasattr(state, "winners_count"):
                state.winners_count = n
                return True, f"✅ Победителей: <b>{n}</b>"
            return False, "⚠️ Нет поля «победителей»."

        if field == "chance":
            v = float(value.replace(",", "."))
            if not (0 < v <= 100):
                return False, "⚠️ От 0.01 до 100."
            if hasattr(state, "chance_percent"):
                state.chance_percent = v
                return True, f"✅ Новый шанс: <b>{v}%</b>"
            if hasattr(state, "drop_chance"):
                state.drop_chance = max(0.0001, min(1.0, v / 100.0))
                return True, f"✅ Шанс выдачи: <b>{v}%</b>"
            return False, "⚠️ В этом ивенте нет шанса."

        if field == "target":
            n = int(value)
            if n < 1:
                return False, "⚠️ Цель должна быть >= 1."
            if hasattr(state, "target"):
                state.target = n
                return True, f"✅ Новая цель: <b>{n}</b> сообщений"
            return False, "⚠️ Поле недоступно."

        if field == "hints":
            n = int(value)
            if not 0 <= n <= 10:
                return False, "⚠️ От 0 до 10."
            if hasattr(state, "hints_count"):
                state.hints_count = n
                state.hints_sent = 0
                # перезапускаем таск подсказок
                from handlers.roulette import _start_hints_task
                _start_hints_task(bot, state)
                return True, f"✅ Подсказок за раунд: <b>{n}</b>"
            return False, "⚠️ Поле недоступно."

        if field == "every":
            secs = parse_duration(value)
            if not secs or secs < 30:
                return False, "⚠️ Минимум 30 секунд. Пример: <code>10m</code>."
            if hasattr(state, "every_sec"):
                state.every_sec = secs
                return True, f"✅ Интервал проверки: <b>{format_duration(secs)}</b>"
            return False, "⚠️ Поле недоступно."

        if field == "mode":
            v = value.lower().strip()
            if event == "kazik":
                mapping = {
                    "bar": "bar", "бар": "bar",
                    "viv": "viv", "виноград": "viv", "винограды": "viv", "grape": "viv", "grapes": "viv", "🍇": "viv",
                    "lemon": "lemon", "лимон": "lemon", "лимоны": "lemon",
                    "777": "777",
                    "all": "all", "все": "all", "любая": "all",
                }
                m = mapping.get(v)
                if not m:
                    return False, "⚠️ Используй: bar / viv / lemon / 777 / all."
                if hasattr(state, "mode"):
                    state.mode = m
                    return True, f"✅ Режим казино: <b>{m}</b>"
                return False, "⚠️ Этот ивент не поддерживает смену режима."
            if event == "viktorina":
                if v in {"untilcorrect", "until", "до", "доправильного"}:
                    state.until_correct = True
                    state.fast_next = False
                    return True, "✅ Режим: <b>пока не отгадают правильный ответ</b>"
                if v in {"fast", "первый"}:
                    state.until_correct = False
                    state.fast_next = True
                    return True, "✅ Режим: <b>fast</b> — кто первый"
                if v in {"wait", "ждать"}:
                    state.until_correct = False
                    state.fast_next = False
                    return True, "✅ Режим: <b>wait</b> — ждём всех"
                return False, "⚠️ Используй: untilcorrect / fast / wait."
            return False, "⚠️ Поле «mode» только для викторины."

        return False, f"⚠️ Неизвестное поле: <code>{field}</code>"
    except ValueError:
        return False, "⚠️ Нужно число."
    except Exception as e:
        return False, f"⚠️ Ошибка: {e}"


async def _reschedule(event: str, chat_id: int, bot: Bot):
    """После изменения времени — перезапускаем runner-таску ивента."""
    if event == "perebiv":
        from handlers.perebiv import _schedule
        st = get_state(chat_id)
        if st:
            _schedule(bot, st)
        return
    if event in ("kubik", "kazik"):
        st = get_dice_state(chat_id)
        if st and st.task and not st.task.done():
            st.task.cancel()
        if st and st.notified_marks is not None:
            st.notified_marks = set()
        try:
            from handlers.games import _finish_dice
            st.task = asyncio.create_task(_finish_dice(bot, chat_id))
        except Exception:
            pass
        return
    if event == "number":
        st = get_number(chat_id)
        if st and st.task and not st.task.done():
            st.task.cancel()
        try:
            from handlers.roulette import _finish_number, _start_hints_task
            st.task = asyncio.create_task(_finish_number(bot, chat_id))
            _start_hints_task(bot, st)
        except Exception:
            pass
        return
    if event == "goal":
        from handlers.goal import _runner as goal_runner
        st = get_goal(chat_id)
        if st and st.task and not st.task.done():
            st.task.cancel()
        st.task = asyncio.create_task(goal_runner(bot, chat_id))
        return
    if event == "lottery":
        from handlers.lottery import _runner as lot_runner
        st = get_lottery(chat_id)
        if st and st.task and not st.task.done():
            st.task.cancel()
        st.task = asyncio.create_task(lot_runner(bot, chat_id))
        return
    if event in ("medved", "nft"):
        st = None
        for kind, s in get_all_roulettes(chat_id).items():
            if kind == event:
                st = s
                break
        if st and st.task and not st.task.done():
            st.task.cancel()
        try:
            from handlers.roulette import _finish_roulette
            title = "Медведь" if event == "medved" else "NFT"
            st.task = asyncio.create_task(_finish_roulette(bot, chat_id, event, title))
        except Exception:
            pass
        return
    if event == "randommedved":
        try:
            from handlers.randommedved import get_rm, _finish_loop
            st = get_rm(chat_id)
            if st and st.task and not st.task.done():
                st.task.cancel()
            if st and st.deadline:
                st.task = asyncio.create_task(_finish_loop(bot, chat_id))
        except Exception:
            pass
        return
