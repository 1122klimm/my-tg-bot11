"""Кубик 🎲, Казино 🎰, Викторина."""
import asyncio
import random
from datetime import datetime, timezone, timedelta
from html import escape

from aiogram import Router, F, Bot
from aiogram.enums import ChatType
from aiogram.filters import Command, Filter
from aiogram.types import Message

from game import (
    DiceGameState, QuizQuestion, QuizState,
    drop_all_games, drop_dice_state, drop_quiz_state,
    get_dice_state, get_quiz_state, set_dice_state, set_quiz_state,
    deadline_notifier,
)
from utils import storage, stats_push
from utils.report import send_post_game_report
from utils.win_photo import send_start_photo
from utils.duration import format_duration, parse_duration
from access import is_admin, username_of, remember_username, remember_win, notify_win, is_ignored
from help_texts import NO_ACCESS, EVENT_FOOTER
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def _stop_kb(kind: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="⛔ Остановить игру", callback_data=f"stop:{kind}")
    ]])

router = Router(name="games")

DURATION_TOKEN = ("s", "m", "h", "d")
QUIZ_SECONDS_PER_QUESTION = 20
# v21: лок против гонок при множестве одновременных правильных ответов
_quiz_advance_locks: dict[int, asyncio.Lock] = {}


def _quiz_lock(cid: int) -> asyncio.Lock:
    if cid not in _quiz_advance_locks:
        _quiz_advance_locks[cid] = asyncio.Lock()
    return _quiz_advance_locks[cid]

DIFFICULTY_NAMES = {
    1: "🟢 Лёгкий",
    2: "🟡 Средний",
    3: "🔴 Сложный",
    4: "💀 Как это вообще?!",
}
DIFFICULTY_DEFAULT_TIME = {1: 25, 2: 20, 3: 15, 4: 12}

# Казино
KAZIK_WIN_NAMES = {"bar": "3 BAR", "viv": "3 винограда", "lemon": "3 лимона", "777": "777"}
KAZIK_VALUES = {"bar": 1, "viv": 22, "lemon": 43, "777": 64}
KAZIK_MODE_LABELS = {
    "bar": "🟫 3 BAR", "viv": "🍇 3 винограда", "lemon": "🍋 3 лимона", "777": "7️⃣ 777",
    "all": "🎰 любая выигрышная комбинация",
}


# ---------- фильтры ----------
class ActiveDiceFilter(Filter):
    async def __call__(self, message: Message) -> bool:
        if not message.dice:
            return False
        st = get_dice_state(message.chat.id)
        return bool(st and st.running and message.dice.emoji == st.emoji)


class ActiveKubikBetFilter(Filter):
    async def __call__(self, message: Message) -> bool:
        text = (message.text or "").strip()
        if text not in {"1", "2", "3", "4", "5", "6"}:
            return False
        st = get_dice_state(message.chat.id)
        return bool(st and st.running and st.game_type == "kubik")


class ActiveQuizAnswerFilter(Filter):
    async def __call__(self, message: Message) -> bool:
        text = (message.text or "").strip()
        # v21: до 9 вариантов
        if text not in {"1", "2", "3", "4", "5", "6", "7", "8", "9"}:
            return False
        ds = get_dice_state(message.chat.id)
        if ds and ds.running and ds.game_type == "kubik":
            return False
        st = get_quiz_state(message.chat.id)
        return bool(st and st.running and st.current_index < len(st.questions))


# ---------- утилиты ----------
def _split_time_and_prize(rest: str) -> tuple[str, str]:
    """Время идёт в начале (несколько токенов вида 1m, 30s, 2h)."""
    rest = (rest or "").strip()
    if not rest:
        return "", ""
    tokens = rest.split()
    time_parts = []
    i = 0
    for tok in tokens:
        t = tok.lower()
        if len(t) >= 2 and t[-1] in DURATION_TOKEN and t[:-1].isdigit():
            time_parts.append(tok)
            i += 1
        else:
            break
    return " ".join(time_parts), " ".join(tokens[i:]).strip()


def _extract_count(tokens: list[str]) -> tuple[int, list[str]]:
    """Ищем токен xN (например x10) — возвращаем (count, оставшиеся токены)."""
    count = 1
    rest = []
    for tok in tokens:
        low = tok.lower()
        if low.startswith("x") and low[1:].isdigit():
            count = max(1, int(low[1:]))
        else:
            rest.append(tok)
    return count, rest


# ============================================================
# КУБИК 🎲
# ============================================================
@router.message(Command(commands=["startgame_kubik", "startgame_cube"]))
async def cmd_kubik(message: Message, bot: Bot):
    stats_push.report_start(message, "kubik")
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await message.reply("Запускать игру можно только в групповом чате.")
        return
    if not is_admin(message.from_user.id):
        await message.reply(NO_ACCESS)
        return

    parts = (message.text or "").split(maxsplit=1)
    rest = parts[1] if len(parts) > 1 else ""
    time_str, after_time = _split_time_and_prize(rest)
    tokens = after_time.split() if after_time else []
    count, prize_tokens = _extract_count(tokens)
    prize = " ".join(prize_tokens).strip() or storage.get().get("prize_url", "")

    secs = 0
    if time_str:
        secs = parse_duration(time_str) or 0
        if not secs:
            await message.reply("Не понял время. Пример: <code>/startgame_kubik 1m x5 nft</code>")
            return

    drop_all_games(message.chat.id)
    deadline = datetime.now(timezone.utc) + timedelta(seconds=secs) if secs else None
    st = DiceGameState(
        chat_id=message.chat.id, game_type="kubik", emoji="🎲", title="Кубик",
        duration=secs, prize=prize, prizes_total=count, prizes_left=count,
        deadline=deadline, running=True, started_at=datetime.now(timezone.utc),
    )
    set_dice_state(st)
    if secs:
        _schedule_dice(bot, st)

    prize_line = f"\n🎁 <b>Приз:</b> {prize}" if prize else "\n🎁 <b>Приз:</b> <i>не задан</i>"
    time_line = (f"⏱ <b>Время:</b> {format_duration(secs)}\n"
                 f"🎯 <b>Финиш:</b> {st.deadline_msk_str()} по МСК") if secs else \
                "⏱ <b>Время:</b> до <code>/stop</code>"
    await send_start_photo(
        bot, message.chat.id, "kubik",
        f"🎲 <b>Кубик запущен!</b>\n{time_line}\n"
        f"🏆 <b>Призов:</b> <b>{count}</b>{prize_line}\n\n"
        f"<b>Как играть:</b>\n"
        f"1) Напишите в чат число от <b>1</b> до <b>6</b> — это ваша ставка.\n"
        f"2) Киньте 🎲 — если выпадет ваше число, забираете приз!\n"
        f"Ставку можно сменить, написав другое число."
        f"{EVENT_FOOTER}",
        reply_markup=_stop_kb("kubik"),
    )


@router.message(F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}), ActiveKubikBetFilter())
async def on_kubik_bet(message: Message):
    if not message.from_user or message.from_user.is_bot:
        return
    st = get_dice_state(message.chat.id)
    if not st or not st.running or st.game_type != "kubik":
        return
    remember_username(message)
    if is_ignored(message.from_user.id, "kubik"):
        return
    bet = int((message.text or "0").strip())
    st.bets[message.from_user.id] = bet
    try:
        await message.reply(f"🎯 Ставка принята: <b>{bet}</b>. Теперь киньте 🎲")
    except Exception:
        pass


# ============================================================
# КАЗИК 🎰
# ============================================================
@router.message(Command(commands=["startgame_kazik", "startgame_casino"]))
async def cmd_kazik(message: Message, bot: Bot):
    stats_push.report_start(message, "kazik")
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await message.reply("Запускать игру можно только в групповом чате.")
        return
    if not is_admin(message.from_user.id):
        await message.reply(NO_ACCESS)
        return

    parts = (message.text or "").split(maxsplit=1)
    rest = parts[1] if len(parts) > 1 else ""
    time_str, after_time = _split_time_and_prize(rest)
    tokens = after_time.split() if after_time else []

    # ищем режим
    mode = None
    leftover = []
    for tok in tokens:
        low = tok.lower()
        if low in {"bar", "lemon", "лимон", "лимоны", "777", "all", "все", "любая",
                   "viv", "виноград", "винограды", "grape", "grapes", "🍇"}:
            if low in {"лимон", "лимоны"}:
                mode = "lemon"
            elif low in {"все", "любая"}:
                mode = "all"
            elif low in {"виноград", "винограды", "grape", "grapes", "🍇"}:
                mode = "viv"
            else:
                mode = low
        else:
            leftover.append(tok)

    if mode is None:
        await message.reply(
            "Использование: <code>/startgame_kazik [время] &lt;режим&gt; [x&lt;кол-во&gt;] [приз]</code>\n\n"
            "<b>Режимы:</b> <code>bar</code> · <code>viv</code> · <code>lemon</code> · <code>777</code> · <code>all</code>\n"
            "Пример: <code>/startgame_kazik 2m 777 x3 https://t.me/nft/...</code>\n"
            "Без времени: <code>/startgame_kazik all x100 nft</code>"
        )
        return

    count, prize_tokens = _extract_count(leftover)
    prize = " ".join(prize_tokens).strip() or storage.get().get("prize_url", "")

    secs = 0
    if time_str:
        secs = parse_duration(time_str) or 0
        if not secs:
            await message.reply("Не понял время. Пример: <code>/startgame_kazik 1m 777 nft</code>")
            return

    drop_all_games(message.chat.id)
    deadline = datetime.now(timezone.utc) + timedelta(seconds=secs) if secs else None
    st = DiceGameState(
        chat_id=message.chat.id, game_type="kazik", emoji="🎰", title="Казино",
        duration=secs, prize=prize, prizes_total=count, prizes_left=count, mode=mode,
        deadline=deadline, running=True, started_at=datetime.now(timezone.utc),
    )
    set_dice_state(st)
    if secs:
        _schedule_dice(bot, st)

    prize_line = f"\n🎁 <b>Приз:</b> {prize}" if prize else "\n🎁 <b>Приз:</b> <i>не задан</i>"
    time_line = (f"⏱ <b>Время:</b> {format_duration(secs)}\n"
                 f"🏁 <b>Финиш:</b> {st.deadline_msk_str()} по МСК") if secs else \
                "⏱ <b>Время:</b> до <code>/stop</code>"
    await send_start_photo(
        bot, message.chat.id, "kazik",
        f"🎰 <b>Казино запущено!</b>\n"
        f"🎯 <b>Комбинация:</b> {KAZIK_MODE_LABELS[mode]}\n"
        f"🏆 <b>Призов:</b> <b>{count}</b>\n"
        f"{time_line}{prize_line}\n\n"
        f"Кидайте 🎰 в чат. Каждый, у кого выпадет нужная комбинация — забирает приз!"
        f"{EVENT_FOOTER}",
        reply_markup=_stop_kb("kazik"),
    )


# обработчик броска (общий)
@router.message(F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}), ActiveDiceFilter())
async def on_dice(message: Message, bot: Bot):
    if not message.from_user or message.from_user.is_bot:
        return
    st = get_dice_state(message.chat.id)
    if not st or not st.running or not message.dice or message.dice.emoji != st.emoji:
        return

    value = message.dice.value
    username = username_of(message)
    user_id = message.from_user.id
    remember_username(message)
    if is_ignored(user_id, st.game_type):
        return

    # КУБИК
    if st.game_type == "kubik":
        bet = st.bets.get(user_id)
        if not bet:
            await message.reply("⚠️ Сначала напишите вашу ставку — число от <b>1</b> до <b>6</b>.")
            return
        if value == bet:
            prize = st.prize or storage.get().get("prize_url", "")
            remember_win(user_id, username, prize, "kubik")
            st.prizes_left -= 1
            prize_line = f"\n🎁 <b>Приз:</b> {prize}" if prize else ""
            left_line = f"\n🎯 <b>Призов осталось:</b> {st.prizes_left}" if st.prizes_total > 1 else ""
            await message.answer(
                f"🏆 <b>ПОБЕДА!</b>\n"
                f"{username} поставил <b>{bet}</b> и выбил <b>{value}</b>!"
                f"{prize_line}{left_line}",
            )
            try:
                chat = await bot.get_chat(message.chat.id)
                await notify_win(bot, chat.title or "", username, prize, "kubik")
            except Exception:
                pass
            # сбрасываем ставку (играй снова или другие)
            st.bets.pop(user_id, None)
            if st.prizes_left <= 0:
                st.running = False
                drop_dice_state(message.chat.id)
                await message.answer("✅ Все призы разыграны. Игра завершена.")
        else:
            await message.reply(
                f"❌ Не угадал. Ставка: <b>{bet}</b>, выпало: <b>{value}</b>. Можно сменить ставку."
            )
        return

    # КАЗИК
    if st.game_type == "kazik":
        mode = st.mode or "all"
        if mode == "all":
            win_keys = [k for k, v in KAZIK_VALUES.items() if v == value]
        else:
            win_keys = [mode] if KAZIK_VALUES.get(mode) == value else []

        if win_keys:
            combo_name = KAZIK_WIN_NAMES[win_keys[0]]
            prize = st.prize or storage.get().get("prize_url", "")
            remember_win(user_id, username, prize, "kazik")
            st.prizes_left -= 1
            prize_line = f"\n🎁 <b>Приз:</b> {prize}" if prize else ""
            left_line = f"\n🎯 <b>Призов осталось:</b> {st.prizes_left}" if st.prizes_total > 1 else ""
            await message.answer(
                f"🏆 <b>JACKPOT!</b>\n"
                f"{username} выбил <b>{combo_name}</b> 🎰{prize_line}{left_line}",
            )
            try:
                chat = await bot.get_chat(message.chat.id)
                await notify_win(bot, chat.title or "", username, prize, "kazik")
            except Exception:
                pass
            if st.prizes_left <= 0:
                st.running = False
                drop_dice_state(message.chat.id)
                await message.answer("✅ Все призы разыграны. Игра завершена.")


async def _finish_dice(bot: Bot, chat_id: int):
    notifier = asyncio.create_task(
        deadline_notifier(bot, chat_id, get_dice_state, "Игра")
    )
    try:
        st = get_dice_state(chat_id)
        if not st or not st.deadline:
            return
        await asyncio.sleep(max(0, (st.deadline - datetime.now(timezone.utc)).total_seconds()))
        st = get_dice_state(chat_id)
        if not st or not st.running:
            return
        await bot.send_message(chat_id, f"⏰ <b>Время вышло!</b> {st.title} завершён.")
        drop_dice_state(chat_id)
    except asyncio.CancelledError:
        return
    except Exception:
        pass
    finally:
        if not notifier.done():
            notifier.cancel()


def _schedule_dice(bot: Bot, st: DiceGameState) -> None:
    if st.task and not st.task.done():
        st.task.cancel()
    st.task = asyncio.create_task(_finish_dice(bot, st.chat_id))


# ============================================================
# ВИКТОРИНА
# ============================================================
TRIVIA_POOLS = {
    # 1 — ЛЁГКИЙ
    1: [
        ("Сколько дней в неделе?", "7", ["5", "6", "8", "10"]),
        ("Какой цвет у спелого банана?", "Жёлтый", ["Красный", "Синий", "Зелёный", "Чёрный"]),
        ("Сколько ног у паука?", "8", ["6", "4", "10", "12"]),
        ("Какое животное лает?", "Собака", ["Кошка", "Корова", "Лошадь", "Свинья"]),
        ("Сколько месяцев в году?", "12", ["10", "11", "13", "14"]),
        ("Какой цвет неба днём?", "Голубой", ["Зелёный", "Красный", "Жёлтый", "Чёрный"]),
        ("Как называется спутник Земли?", "Луна", ["Марс", "Венера", "Солнце", "Фобос"]),
        ("Сколько сторон у квадрата?", "4", ["3", "5", "6", "8"]),
        ("Сколько секунд в минуте?", "60", ["30", "90", "100", "120"]),
        ("Какого цвета снег?", "Белый", ["Серый", "Чёрный", "Красный", "Синий"]),
        ("Сколько пальцев на одной руке?", "5", ["4", "6", "7", "10"]),
        ("Какое время года самое холодное?", "Зима", ["Лето", "Весна", "Осень", "Сентябрь"]),
    ],
    # 2 — СРЕДНИЙ
    2: [
        ("Сколько дней в високосном году?", "366", ["365", "364", "367", "360"]),
        ("Какая планета ближе всего к Солнцу?", "Меркурий", ["Венера", "Марс", "Земля", "Юпитер"]),
        ("Какой океан самый большой?", "Тихий", ["Атлантический", "Индийский", "Северный Ледовитый", "Южный"]),
        ("Сколько сторон у шестиугольника?", "6", ["5", "7", "8", "4"]),
        ("Столица Японии?", "Токио", ["Киото", "Осака", "Сеул", "Пекин"]),
        ("Какой газ нужен человеку для дыхания?", "Кислород", ["Азот", "Гелий", "Водород", "Углекислый газ"]),
        ("Сколько цветов обычно выделяют в радуге?", "7", ["5", "6", "8", "9"]),
        ("Самое быстрое наземное животное?", "Гепард", ["Лев", "Тигр", "Лошадь", "Волк"]),
        ("Какой металл обозначается Au?", "Золото", ["Серебро", "Медь", "Алюминий", "Железо"]),
        ("Сколько игроков в футбольной команде на поле?", "11", ["10", "9", "12", "7"]),
        ("Что измеряют в герцах?", "Частоту", ["Температуру", "Массу", "Длину", "Скорость"]),
        ("Столица Франции?", "Париж", ["Лион", "Марсель", "Берлин", "Мадрид"]),
        ("Какой цвет получится из красного и синего?", "Фиолетовый", ["Зелёный", "Оранжевый", "Жёлтый", "Белый"]),
    ],
    # 3 — СЛОЖНЫЙ
    3: [
        ("Какой химический элемент имеет символ Hg?", "Ртуть", ["Гелий", "Водород", "Магний", "Свинец"]),
        ("В каком году началась Вторая мировая война?", "1939", ["1941", "1914", "1945", "1936"]),
        ("Самая длинная река в мире?", "Амазонка", ["Нил", "Янцзы", "Миссисипи", "Волга"]),
        ("Кто написал «Войну и мир»?", "Толстой", ["Достоевский", "Чехов", "Пушкин", "Гоголь"]),
        ("Какой стране принадлежит остров Гренландия?", "Дания", ["Канада", "США", "Норвегия", "Исландия"]),
        ("Сколько костей в теле взрослого человека?", "206", ["180", "212", "256", "300"]),
        ("Какой язык программирования создал Гвидо ван Россум?", "Python", ["Ruby", "Go", "Perl", "Java"]),
        ("Самая высокая гора Африки?", "Килиманджаро", ["Кения", "Эверест", "Эльбрус", "Маккинли"]),
        ("В каком году человек впервые ступил на Луну?", "1969", ["1959", "1972", "1965", "1971"]),
        ("Какая валюта в Швеции?", "Крона", ["Евро", "Франк", "Фунт", "Марка"]),
        ("Кто открыл пенициллин?", "Флеминг", ["Эдисон", "Дарвин", "Пастер", "Менделеев"]),
        ("Столица Австралии?", "Канберра", ["Сидней", "Мельбурн", "Перт", "Брисбен"]),
    ],
    # 4 — КАК ЭТО ВООБЩЕ?!
    4: [
        ("Сколько у улитки зубов (примерно)?", "25000", ["32", "200", "1000", "100000"]),
        ("Какая температура поверхности Венеры (°C)?", "465", ["120", "300", "800", "1200"]),
        ("Сколько лет живёт гренландская акула?", "400", ["50", "150", "250", "1000"]),
        ("Сколько весит язык синего кита (кг)?", "2700", ["100", "500", "1500", "5000"]),
        ("В каком году была изобретена консервная банка?", "1810", ["1750", "1865", "1900", "1925"]),
        ("Скольким землетрясениям подвергается Япония в год?", "1500", ["50", "300", "700", "5000"]),
        ("Сколько сердец у осьминога?", "3", ["1", "2", "4", "8"]),
        ("Какая самая маленькая страна-член ООН по населению?", "Тувалу", ["Науру", "Монако", "Сан-Марино", "Палау"]),
        ("Сколько в среднем чихов человек делает за жизнь?", "50000", ["1000", "10000", "200000", "1000000"]),
        ("В какой стране родился алгоритм?", "Узбекистан", ["Иран", "Греция", "Египет", "Индия"]),
        ("Сколько примерно атомов в одной капле воды?", "5e21", ["1e10", "1e15", "1e18", "1e25"]),
        ("Сколько у пчёлы глаз?", "5", ["2", "3", "4", "8"]),
    ],
}



def _make_math_question(option_count: int, difficulty: int = 2) -> QuizQuestion:
    if difficulty == 1:
        a = random.randint(2, 15); b = random.randint(2, 10)
        op = random.choice(["+", "-"])
    elif difficulty == 2:
        a = random.randint(5, 35); b = random.randint(2, 20)
        op = random.choice(["+", "-", "×"])
    elif difficulty == 3:
        a = random.randint(15, 99); b = random.randint(5, 40)
        op = random.choice(["+", "-", "×"])
    else:  # 4 — как это вообще
        a = random.randint(50, 500); b = random.randint(20, 300)
        op = random.choice(["+", "-", "×"])
    if op == "+": correct = a + b
    elif op == "-":
        if b > a: a, b = b, a
        correct = a - b
    else:
        if difficulty == 4:
            a = random.randint(11, 99); b = random.randint(11, 99)
        elif difficulty == 3:
            a = random.randint(6, 25); b = random.randint(6, 25)
        else:
            a = random.randint(2, 12); b = random.randint(2, 12)
        correct = a * b
    spread = {1: [-3,-2,-1,1,2,3], 2: [-10,-5,-3,-2,-1,1,2,3,5,10],
              3: [-25,-15,-7,-3,3,7,15,25], 4: [-100,-50,-30,-10,10,30,50,100]}[difficulty]
    decoys = {correct + random.choice(spread) for _ in range(20)}
    decoys.discard(correct)
    options = [str(correct)] + [str(x) for x in list(decoys)[: option_count - 1]]
    random.shuffle(options)
    return QuizQuestion(f"Сколько будет {a} {op} {b}?", options, options.index(str(correct)))


def _make_trivia_question(option_count: int, difficulty: int = 2) -> QuizQuestion:
    pool = TRIVIA_POOLS.get(difficulty, TRIVIA_POOLS[2])
    text, correct, wrong = random.choice(pool)
    # v21: если нужно больше декойев, чем есть в пуле — добавляем «почти-варианты»
    needed = option_count - 1
    if needed <= len(wrong):
        decoys = random.sample(wrong, k=needed)
    else:
        decoys = list(wrong)
        # докидываем варианты из других пулов того же уровня
        extra_pool = [w for q in pool if q[0] != text for w in q[2]]
        random.shuffle(extra_pool)
        for w in extra_pool:
            if w not in decoys and w != correct:
                decoys.append(w)
            if len(decoys) >= needed:
                break
        # если всё равно не хватает — забиваем нумерованными плейсхолдерами
        i = 1
        while len(decoys) < needed:
            cand = f"вариант №{i}"
            i += 1
            if cand not in decoys:
                decoys.append(cand)
    options = [correct] + decoys
    random.shuffle(options)
    return QuizQuestion(text, options, options.index(correct))


def _build_questions(total: int, option_count: int, difficulty: int = 2) -> list[QuizQuestion]:
    qs: list[QuizQuestion] = []
    used: set[str] = set()
    pool = TRIVIA_POOLS.get(difficulty, TRIVIA_POOLS[2])
    # на лёгком уровне больше тривии, на сложном — больше математики
    math_chance = {1: 0.30, 2: 0.45, 3: 0.55, 4: 0.65}.get(difficulty, 0.45)
    # перетасуем пул, чтобы каждый раз другие вопросы
    shuffled_pool = list(pool)
    random.shuffle(shuffled_pool)
    pool_idx = 0
    attempts = 0
    max_attempts = max(total * 30, 2000)
    while len(qs) < total and attempts < max_attempts:
        attempts += 1
        if random.random() < math_chance:
            q = _make_math_question(option_count, difficulty)
        else:
            # сначала идём по перетасованному пулу — гарантирует уникальность
            if pool_idx < len(shuffled_pool):
                text, correct, wrong = shuffled_pool[pool_idx]
                pool_idx += 1
                if text in used:
                    continue
                # тот же декой-расширяющий код, что в _make_trivia_question
                needed = option_count - 1
                if needed <= len(wrong):
                    decoys = random.sample(wrong, k=needed)
                else:
                    decoys = list(wrong)
                    extra = [w for q2 in pool if q2[0] != text for w in q2[2]]
                    random.shuffle(extra)
                    for w in extra:
                        if w not in decoys and w != correct:
                            decoys.append(w)
                        if len(decoys) >= needed:
                            break
                    i = 1
                    while len(decoys) < needed:
                        cand = f"вариант №{i}"; i += 1
                        if cand not in decoys:
                            decoys.append(cand)
                opts = [correct] + decoys
                random.shuffle(opts)
                q = QuizQuestion(text, opts, opts.index(correct))
            else:
                q = _make_math_question(option_count, difficulty)
        if q.text in used:
            continue
        used.add(q.text)
        qs.append(q)
    # добиваем математикой, если не хватило
    while len(qs) < total:
        q = _make_math_question(option_count, difficulty)
        qs.append(q)
    return qs


@router.message(Command(commands=["startviktorina", "startgame_viktorina", "start_viktorina", "start_викторина"]))
async def cmd_viktorina(message: Message, bot: Bot):
    stats_push.report_start(message, "viktorina")
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await message.reply("Запускать викторину можно только в групповом чате.")
        return
    if not is_admin(message.from_user.id):
        await message.reply(NO_ACCESS)
        return

    parts = (message.text or "").split()
    if len(parts) < 3:
        await message.reply(
            "<b>Использование:</b>\n"
            "<code>/startviktorina &lt;вопросов&gt; &lt;вариантов&gt; [уровень] [t&lt;сек&gt;] [fast|wait] [приз]</code>\n\n"
            "<b>Уровни сложности:</b>\n"
            "• <b>1</b> — 🟢 Лёгкий\n"
            "• <b>2</b> — 🟡 Средний (по умолчанию)\n"
            "• <b>3</b> — 🔴 Сложный\n"
            "• <b>4</b> — 💀 Как это вообще?!\n\n"
            "<b>Режимы ответов:</b>\n"
            "• <code>fast</code> — следующий вопрос сразу после первого правильного ответа\n"
            "• <code>wait</code> — ждём всё время, отвечают все (по умолчанию)\n\n"
            "<b>Время на вопрос:</b> <code>t15</code> = 15 сек\n\n"
            "<b>Примеры:</b>\n"
            "<code>/startviktorina 5 4</code> — простой\n"
            "<code>/startviktorina 10 4 4 t10 fast nft</code> — невозможно, 10с, кто первый\n"
            "<code>/startviktorina 5 4 3 wait https://t.me/nft/...</code>"
        )
        return
    try:
        total_q = int(parts[1]); opt = int(parts[2])
    except ValueError:
        await message.reply("Количество вопросов и вариантов должно быть числами.")
        return
    if not 1 <= total_q <= 500:
        await message.reply("Количество вопросов: от 1 до 500.")
        return
    if not 2 <= opt <= 9:
        await message.reply("Количество вариантов ответа: от 2 до 9.")
        return

    # Парсим необязательные токены: уровень (1-4), t<sec>, fast/wait
    difficulty = 2
    seconds_per_q = None
    fast_next = False
    until_correct = False
    rest = parts[3:]
    leftover = []
    for tok in rest:
        low = tok.lower()
        if low in {"1", "2", "3", "4"}:
            difficulty = int(low)
        elif low in {"fast", "speed", "первый"}:
            fast_next = True
        elif low in {"wait", "ждать"}:
            fast_next = False
        elif low in {"untilcorrect", "until", "доправильного"}:
            until_correct = True
        elif low.startswith("t") and low[1:].isdigit():
            seconds_per_q = max(3, min(120, int(low[1:])))
        else:
            leftover.append(tok)

    if seconds_per_q is None:
        seconds_per_q = DIFFICULTY_DEFAULT_TIME[difficulty]

    prize = " ".join(leftover).strip() or storage.get().get("prize_url", "")
    drop_all_games(message.chat.id)
    st = QuizState(
        chat_id=message.chat.id, total_questions=total_q, option_count=opt,
        prize=prize, questions=_build_questions(total_q, opt, difficulty),
        running=True, difficulty=difficulty,
        seconds_per_question=seconds_per_q, fast_next=fast_next,
        until_correct=until_correct,
    )
    set_quiz_state(st)
    prize_line = f"\n🎁 <b>Приз:</b> {prize}" if prize else "\n🎁 <b>Приз:</b> <i>не задан</i>"
    if until_correct:
        mode_line = "♾ <b>Режим:</b> вопрос держится, пока кто-то не ответит правильно (без таймера)"
    elif fast_next:
        mode_line = "⚡ <b>Режим:</b> кто первый ответил — балл и сразу следующий"
    else:
        mode_line = "⏳ <b>Режим:</b> у каждого есть время ответить"
    await send_start_photo(
        bot, message.chat.id, "viktorina",
        f"🧠 <b>Викторина началась!</b>\n"
        f"💪 <b>Сложность:</b> {DIFFICULTY_NAMES[difficulty]}\n"
        f"📋 <b>Вопросов:</b> {total_q}\n"
        f"🔢 <b>Вариантов:</b> {opt}\n"
        f"⏱ <b>На вопрос:</b> {seconds_per_q} сек\n"
        f"{mode_line}"
        f"{prize_line}\n\nОтвечайте цифрой варианта в чат."
        f"{EVENT_FOOTER}",
        reply_markup=_stop_kb("viktorina"),
    )
    await _send_next_question(bot, message.chat.id)


async def _send_next_question(bot: Bot, chat_id: int) -> None:
    st = get_quiz_state(chat_id)
    if not st or not st.running:
        return
    if st.current_index >= st.total_questions:
        await _finish_quiz(bot, chat_id)
        return
    st.answered_user_ids = set()
    st.first_answered = False
    q = st.questions[st.current_index]
    lines = [f"🧠 <b>Вопрос {st.current_index + 1}/{st.total_questions}</b>",
             f"<i>{DIFFICULTY_NAMES[st.difficulty]} · {st.seconds_per_question}с</i>",
             "", escape(q.text), ""]
    for i, o in enumerate(q.options, 1):
        lines.append(f"<b>{i}</b>) {escape(o)}")
    if st.fast_next:
        lines.append(f"\n⚡ Кто первый ответит правильно — получит балл и пойдём дальше.")
    else:
        lines.append(f"\nОтвечайте цифрой 1-{len(q.options)}.")
    await bot.send_message(chat_id, "\n".join(lines))
    if st.task and not st.task.done():
        st.task.cancel()
    if not st.until_correct:
        st.task = asyncio.create_task(_quiz_timeout(bot, chat_id, st.current_index))


@router.message(F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}), ActiveQuizAnswerFilter())
async def on_quiz_answer(message: Message):
    if not message.from_user or message.from_user.is_bot:
        return
    cid = message.chat.id
    async with _quiz_lock(cid):
        st = get_quiz_state(cid)
        if not st or not st.running or st.current_index >= len(st.questions):
            return
        uid = message.from_user.id
        remember_username(message)
        if is_ignored(uid, "viktorina"):
            return
        if uid in st.answered_user_ids and not st.until_correct:
            return
        st.answered_user_ids.add(uid)
        try:
            selected = int((message.text or "0").strip()) - 1
        except ValueError:
            return
        q = st.questions[st.current_index]
        if not (0 <= selected < len(q.options)):
            return
        is_correct = (selected == q.correct_index)
        cur_index = st.current_index
        if is_correct:
            username = username_of(message)
            row = st.scores.setdefault(uid, {"username": username, "count": 0})
            row["username"] = username
            row["count"] += 1
            advance = (st.fast_next or st.until_correct) and not st.first_answered
            if advance:
                st.first_answered = True
                st.current_index += 1
                if st.task and not st.task.done():
                    st.task.cancel()
        else:
            advance = False
            if st.until_correct:
                st.answered_user_ids.discard(uid)
    # Сообщения шлём ВНЕ лока
    if is_correct:
        try:
            await message.answer(f"✅ {username_of(message)} <b>правильно!</b> +1")
        except Exception:
            pass
        if advance:
            try:
                await message.answer("⚡ Следующий вопрос…")
            except Exception:
                pass
            await _send_next_question(message.bot, cid)


async def _quiz_timeout(bot: Bot, chat_id: int, qi: int) -> None:
    try:
        st0 = get_quiz_state(chat_id)
        sleep_for = st0.seconds_per_question if st0 else QUIZ_SECONDS_PER_QUESTION
        await asyncio.sleep(sleep_for)
        st = get_quiz_state(chat_id)
        if not st or not st.running or st.current_index != qi:
            return
        q = st.questions[st.current_index]
        ans = q.options[q.correct_index]
        st.current_index += 1
        await bot.send_message(chat_id, f"⏭ <b>Правильный ответ:</b> {escape(ans)}")
        await _send_next_question(bot, chat_id)
    except asyncio.CancelledError:
        return


async def _finish_quiz(bot: Bot, chat_id: int) -> None:
    st = get_quiz_state(chat_id)
    if not st:
        return
    if not st.scores:
        await bot.send_message(chat_id, "🤷 Викторина завершена. Правильных ответов нет.")
        drop_quiz_state(chat_id)
        return
    winner_id, winner = max(st.scores.items(), key=lambda i: i[1]["count"])
    prize = st.prize or storage.get().get("prize_url", "")
    remember_win(winner_id, winner["username"], prize, "viktorina")
    lines = [
        "🏆 <b>Викторина завершена!</b>", "",
        f"👑 <b>Победитель:</b> {winner['username']} — <b>{winner['count']}</b>",
    ]
    if prize:
        lines.append(f"🎁 <b>Приз:</b> {prize}")
    top = sorted(st.scores.values(), key=lambda i: i["count"], reverse=True)[:10]
    lines.append("\n<b>Топ:</b>")
    for i, r in enumerate(top, 1):
        lines.append(f"{i}. {r['username']} — {r['count']}")
    await bot.send_message(chat_id, "\n".join(lines), disable_web_page_preview=False)
    try:
        chat = await bot.get_chat(chat_id)
        await notify_win(bot, chat.title or "", winner["username"], prize, "viktorina")
    except Exception:
        pass
    drop_quiz_state(chat_id)
