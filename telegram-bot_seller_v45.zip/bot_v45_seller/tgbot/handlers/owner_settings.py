"""v43-seller: настройки владельца бота через ЛС.

• /setpassword <новый>           — сменить пароль активации админ-панели
• /password                      — показать текущий пароль (только админ)
• /setimage <event> <start|win>  — далее присылаешь фото, оно станет картинкой ивента
• /resetimage <event> <start|win> — вернуть оригинальную картинку (если была)
• /images                        — список ивентов и какие картинки кастомные

Поддерживаемые event:
  perebiv, kazik, kubik, viktorina, medved, randommedved, nft, number,
  goal, lottery, basketball, football, bowling, darts
"""
import os
import shutil
from html import escape

from aiogram import Router, F, Bot
from aiogram.enums import ChatType
from aiogram.filters import Command
from aiogram.types import Message

from access import is_admin
from utils import storage
from help_texts import WELCOME_DM

router = Router(name="owner_settings")
router.message.filter(F.chat.type == ChatType.PRIVATE)

EVENTS = {
    "perebiv", "kazik", "kubik", "viktorina", "medved", "randommedved",
    "nft", "number", "goal", "lottery",
    "basketball", "football", "bowling", "darts",
}

_ASSETS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")
_START = os.path.join(_ASSETS, "start")
_WIN = os.path.join(_ASSETS, "win")
_BACKUP = os.path.join(_ASSETS, "_originals")
os.makedirs(_BACKUP + "/start", exist_ok=True)
os.makedirs(_BACKUP + "/win", exist_ok=True)

# pending: uid -> (event, kind)
_PENDING: dict[int, tuple[str, str]] = {}


def get_panel_password() -> str:
    """Текущий пароль админ-панели: storage > env."""
    from config import ADMIN_PANEL_CODE
    return storage.get().get("panel_password") or ADMIN_PANEL_CODE


def _set_panel_password(new: str) -> None:
    def upd(d: dict) -> None:
        d["panel_password"] = new
    storage.update(upd)


def _path_for(kind: str, event: str) -> str:
    base = _START if kind == "start" else _WIN
    return os.path.join(base, f"{event}.jpg")


@router.message(Command("setpassword"))
async def cmd_setpassword(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer(WELCOME_DM); return
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2 or not parts[1].strip():
        await message.answer(
            "Использование: <code>/setpassword &lt;новый_пароль&gt;</code>\n\n"
            f"Текущий: <code>{escape(get_panel_password())}</code>"
        )
        return
    new = parts[1].strip().split()[0]
    if len(new) < 4:
        await message.answer("Пароль слишком короткий (минимум 4 символа).")
        return
    _set_panel_password(new)
    await message.answer(
        f"🔑 Пароль админ-панели обновлён.\n"
        f"Новый пароль: <code>{escape(new)}</code>\n\n"
        f"Используй его при активации панели в ЛС нового админа."
    )


@router.message(Command("password"))
async def cmd_password(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer(WELCOME_DM); return
    await message.answer(
        f"🔑 Текущий пароль активации админ-панели:\n<code>{escape(get_panel_password())}</code>\n\n"
        f"Сменить: <code>/setpassword &lt;новый&gt;</code>"
    )


@router.message(Command("images"))
async def cmd_images(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer(WELCOME_DM); return
    lines = ["🖼 <b>Картинки ивентов</b>\n"]
    for ev in sorted(EVENTS):
        s_exists = os.path.exists(_path_for("start", ev))
        w_exists = os.path.exists(_path_for("win", ev))
        s_back = os.path.exists(os.path.join(_BACKUP, "start", f"{ev}.jpg"))
        w_back = os.path.exists(os.path.join(_BACKUP, "win", f"{ev}.jpg"))
        s_mark = "🔁" if s_back else ("✅" if s_exists else "—")
        w_mark = "🔁" if w_back else ("✅" if w_exists else "—")
        lines.append(f"• <code>{ev}</code>: старт {s_mark}  победа {w_mark}")
    lines.append(
        "\n🔁 = заменена тобой\n✅ = оригинальная\n— = нет файла\n\n"
        "Заменить: <code>/setimage &lt;event&gt; &lt;start|win&gt;</code> и пришли фото.\n"
        "Вернуть: <code>/resetimage &lt;event&gt; &lt;start|win&gt;</code>"
    )
    await message.answer("\n".join(lines))


@router.message(Command("setimage"))
async def cmd_setimage(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer(WELCOME_DM); return
    parts = (message.text or "").split()
    if len(parts) < 3:
        await message.answer(
            "Использование: <code>/setimage &lt;event&gt; &lt;start|win&gt;</code>\n\n"
            "Например: <code>/setimage perebiv start</code>\n"
            "Потом просто пришли мне фото следующим сообщением.\n\n"
            f"События: {', '.join(sorted(EVENTS))}"
        )
        return
    event = parts[1].lower()
    kind = parts[2].lower()
    if event not in EVENTS:
        await message.answer(f"Неизвестное событие. Поддерживаются: {', '.join(sorted(EVENTS))}")
        return
    if kind not in ("start", "win"):
        await message.answer("Тип должен быть <code>start</code> или <code>win</code>.")
        return
    _PENDING[message.from_user.id] = (event, kind)
    await message.answer(
        f"📷 Жду фото для <b>{event}</b> ({kind}).\n"
        f"Пришли картинку следующим сообщением (как фото, не как файл)."
    )


@router.message(Command("resetimage"))
async def cmd_resetimage(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer(WELCOME_DM); return
    parts = (message.text or "").split()
    if len(parts) < 3:
        await message.answer("Использование: <code>/resetimage &lt;event&gt; &lt;start|win&gt;</code>")
        return
    event = parts[1].lower(); kind = parts[2].lower()
    if event not in EVENTS or kind not in ("start", "win"):
        await message.answer("Проверь параметры.")
        return
    backup = os.path.join(_BACKUP, kind, f"{event}.jpg")
    target = _path_for(kind, event)
    if not os.path.exists(backup):
        await message.answer("Нет оригинала — эта картинка не заменялась.")
        return
    shutil.copy2(backup, target)
    os.remove(backup)
    await message.answer(f"↩️ Картинка <b>{event}</b> ({kind}) возвращена к оригиналу.")


@router.message(F.photo)
async def on_photo(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    pending = _PENDING.get(message.from_user.id)
    if not pending:
        await message.answer(
            "Сначала отправь команду <code>/setimage &lt;event&gt; &lt;start|win&gt;</code>."
        )
        return
    event, kind = pending
    target = _path_for(kind, event)
    backup = os.path.join(_BACKUP, kind, f"{event}.jpg")
    # бэкапим оригинал один раз
    if os.path.exists(target) and not os.path.exists(backup):
        try:
            shutil.copy2(target, backup)
        except Exception:
            pass
    photo = message.photo[-1]
    try:
        os.makedirs(os.path.dirname(target), exist_ok=True)
        await bot.download(photo, destination=target)
    except Exception as e:
        await message.answer(f"❌ Не удалось сохранить: {e}")
        return
    _PENDING.pop(message.from_user.id, None)
    await message.answer(
        f"✅ Картинка <b>{event}</b> ({kind}) обновлена.\n"
        f"Запусти ивент в чате — увидишь новую картинку."
    )
