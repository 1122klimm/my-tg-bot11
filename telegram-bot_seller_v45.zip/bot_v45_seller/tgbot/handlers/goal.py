"""Цель сообщениями (общий пул) — /goal <кол-во> [время] [x<победителей>] [приз].
v18: статусное сообщение редактируется после КАЖДОГО сообщения чата (с дебаунсом).
"""
import asyncio
import random
import time as _t
from datetime import datetime, timezone, timedelta

from aiogram import Router, F, Bot
from aiogram.enums import ChatType
from aiogram.filters import Command, Filter
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from access import is_admin, username_of, remember_username, remember_win, notify_win, is_ignored
from utils import storage
from utils import stats_push
from utils.win_photo import send_win_photo, send_start_photo
from utils.chat_admins import is_chat_admin
from utils.duration import parse_duration, format_duration
from game import GoalState, get_goal, set_goal, drop_goal, drop_all_games, deadline_notifier
from help_texts import NO_ACCESS, EVENT_FOOTER

router = Router(name="goal")
DURATION_TOKEN = ("s", "m", "h", "d")

# Минимальный интервал между правками сообщения — Telegram лимит ~1 edit/сек.
EDIT_DEBOUNCE = 1.2
# таймстемпы последних правок
_last_edit_ts: dict = {}
# pending-задачи отложенной правки
_pending_edit: dict = {}
# v21: лок на завершение, чтобы цель не выбрала победителей дважды
_finish_locks: dict[int, asyncio.Lock] = {}
_finished_chats: set[int] = set()


def _finish_lock(cid: int) -> asyncio.Lock:
    if cid not in _finish_locks:
        _finish_locks[cid] = asyncio.Lock()
    return _finish_locks[cid]


class HasGoalFilter(Filter):
    async def __call__(self, message: Message) -> bool:
        return get_goal(message.chat.id) is not None


def _stop_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="⛔ Остановить игру", callback_data="stop:goal")
    ]])


def _parse_args(rest: str):
    target = 0
    secs = 0
    winners = 1
    tokens = (rest or "").split()
    i = 0
    if tokens and tokens[0].isdigit():
        target = int(tokens[0])
        i = 1
    while i < len(tokens):
        tok = tokens[i]
        low = tok.lower()
        if low.isdigit() or (len(low) >= 2 and low[-1] in DURATION_TOKEN and low[:-1].isdigit()):
            s = parse_duration(low) or 0
            if s and not secs:
                secs = s
                i += 1
                continue
        if low.startswith("x") and low[1:].isdigit():
            winners = max(1, int(low[1:]))
            i += 1
            continue
        break
    prize = " ".join(tokens[i:]).strip()
    return target, secs, winners, prize


def _status_text(st: GoalState) -> str:
    left = max(0, st.target - st.current)
    bar_len = 20
    filled = int(bar_len * min(1.0, st.current / st.target)) if st.target else 0
    bar = "█" * filled + "░" * (bar_len - filled)
    time_line = ""
    if st.deadline:
        time_line = f"⏱ <b>Финиш:</b> {st.deadline_msk_str()} по МСК\n"
    prize_line = f"🎁 <b>Приз:</b> {st.prize}\n" if st.prize else "🎁 <b>Приз:</b> <i>не задан</i>\n"
    winners_line = f"🏆 <b>Победителей:</b> <b>{st.winners_count}</b>\n"
    return (
        f"🎯 <b>ЦЕЛЬ ЧАТА — {st.target} сообщений</b>\n"
        f"<code>{bar}</code>\n"
        f"💬 <b>Написано:</b> <b>{st.current}</b> / {st.target}\n"
        f"📝 <b>Осталось:</b> <b>{left}</b>\n"
        f"{winners_line}{time_line}{prize_line}\n"
        f"<i>Каждое сообщение приближает розыгрыш!</i>"
    )


@router.message(Command(commands=["goal", "цель"]))
async def cmd_goal(message: Message, bot: Bot):
    stats_push.report_start(message, "goal")
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await message.reply("Запускать игру можно только в групповом чате.")
        return
    if not is_admin(message.from_user.id):
        await message.reply(NO_ACCESS)
        return

    parts = (message.text or "").split(maxsplit=1)
    rest = parts[1] if len(parts) > 1 else ""
    target, secs, winners, prize = _parse_args(rest)

    if target <= 0:
        await message.reply(
            "Использование: <code>/goal &lt;кол-во&gt; [время] [x&lt;победителей&gt;] [приз]</code>\n\n"
            "• <code>/goal 1000 nft</code>\n"
            "• <code>/goal 500 1h x10 nft</code>"
        )
        return

    if not prize:
        prize = storage.get().get("prize_url", "")

    drop_all_games(message.chat.id)
    deadline = datetime.now(timezone.utc) + timedelta(seconds=secs) if secs else None
    st = GoalState(
        chat_id=message.chat.id,
        target=target,
        winners_count=winners,
        prize=prize,
        duration=secs,
        deadline=deadline,
        running=True,
    )
    set_goal(st)

    try:
        await send_start_photo(bot, message.chat.id, "goal", "🎯 <b>Ивент «Цель» стартует!</b>")
    except Exception:
        pass
    msg = await message.answer(_status_text(st) + EVENT_FOOTER, reply_markup=_stop_kb())
    st.pinned_message_id = msg.message_id
    st.last_progress_msg_id = msg.message_id
    try:
        await bot.pin_chat_message(message.chat.id, msg.message_id, disable_notification=True)
    except Exception:
        pass

    if secs:
        st.task = asyncio.create_task(_runner(bot, message.chat.id))


async def _runner(bot: Bot, chat_id: int):
    notifier = asyncio.create_task(deadline_notifier(bot, chat_id, get_goal, "Цель"))
    try:
        st = get_goal(chat_id)
        if not st or not st.deadline:
            return
        delay = (st.deadline - datetime.now(timezone.utc)).total_seconds()
        if delay > 0:
            try:
                await asyncio.sleep(delay)
            except asyncio.CancelledError:
                return
        st = get_goal(chat_id)
        if st and st.running:
            await _finish(bot, chat_id, by_time=True)
    finally:
        if not notifier.done():
            notifier.cancel()


async def _finish(bot: Bot, chat_id: int, by_time: bool = False):
    async with _finish_lock(chat_id):
        if chat_id in _finished_chats:
            return
        st = get_goal(chat_id)
        if not st or not st.running:
            return
        st.running = False
        _finished_chats.add(chat_id)
    # Дальше — единственный поток выполнения для этого чата
    st = get_goal(chat_id)
    if not st:
        _finished_chats.discard(chat_id)
        return

    # v27: победитель выбирается рандомно среди тех, кто написал в пределах
    # 5% от лидера по числу сообщений. Поддерживаем старый формат
    # {uid: "@name"} (в нём нет счётчиков — берём всех как раньше).
    GOAL_WINDOW = 0.95  # >= 95% от лидера → попадает в пул
    parsed: list[tuple[int, str, int]] = []  # (uid, name, msgs)
    for uid, val in st.participants.items():
        if is_ignored(uid, "goal"):
            continue
        if isinstance(val, dict):
            parsed.append((uid, val.get("name") or f"id{uid}", int(val.get("messages", 0))))
        else:
            parsed.append((uid, str(val), 0))
    if not parsed:
        await bot.send_message(
            chat_id,
            "🎯 <b>Цель завершена</b>, но никто не написал — победителей нет."
        )
        try:
            await bot.unpin_chat_message(chat_id, st.pinned_message_id)
        except Exception:
            pass
        drop_goal(chat_id)
        _finished_chats.discard(chat_id)
        return

    leader_msgs = max((m for _, _, m in parsed), default=0)
    if leader_msgs > 0:
        threshold = max(1, int(leader_msgs * GOAL_WINDOW))
        pool = [(u, n) for u, n, m in parsed if m >= threshold]
    else:
        # старый формат — берём всех
        pool = [(u, n) for u, n, _m in parsed]
    n = min(st.winners_count, len(pool))
    winners = random.sample(pool, n)
    prize = st.prize or storage.get().get("prize_url", "")

    head = "🏁 <b>ЦЕЛЬ ДОСТИГНУТА!</b>" if not by_time else "⏱ <b>Время вышло — подводим итоги!</b>"
    lines = [
        head,
        f"💬 Сообщений: <b>{st.current}</b> / {st.target}",
        f"🏆 <b>Победител{'ь' if n == 1 else 'и'}:</b>",
    ]
    for uid, uname in winners:
        lines.append(f"   • {uname}")
        remember_win(uid, uname, prize, "goal")
    # Пушим события на сайт
    try:
        chat = await bot.get_chat(chat_id)
        chat_title = chat.title
    except Exception:
        chat_title = None
    for uid, uname in winners:
        stats_push.push_event(
            chat_id=chat_id, chat_title=chat_title,
            user_id=uid, username=uname.lstrip("@") if uname.startswith("@") else None,
            full_name=uname, avatar_url=None,
            game_type="goal", event_type="won", prize=prize,
            stars_value=0, ton_value=0,
            meta={"target": st.target, "current": st.current, "winners_count": st.winners_count},
        )
    if prize:
        lines.append(f"\n🎁 <b>Приз:</b> {prize}")

    await send_win_photo(bot, chat_id, "goal", caption="\n".join(lines))

    try:
        chat = await bot.get_chat(chat_id)
        title = chat.title or ""
        for uid, uname in winners:
            await notify_win(bot, title, uname, prize, "goal")
    except Exception:
        pass

    try:
        await bot.unpin_chat_message(chat_id, st.pinned_message_id)
    except Exception:
        pass
    drop_goal(chat_id)
    _finished_chats.discard(chat_id)


async def _do_edit(bot: Bot, chat_id: int):
    st = get_goal(chat_id)
    if not st or not st.running or not st.pinned_message_id:
        return
    new_text = _status_text(st)
    try:
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=st.pinned_message_id,
            text=new_text,
            reply_markup=_stop_kb(),
        )
        _last_edit_ts[chat_id] = _t.monotonic()
    except Exception:
        # вероятно "message is not modified" или rate limit — игнор
        pass


async def _delayed_edit(bot: Bot, chat_id: int, delay: float):
    try:
        await asyncio.sleep(delay)
    except asyncio.CancelledError:
        return
    _pending_edit.pop(chat_id, None)
    await _do_edit(bot, chat_id)


def _schedule_edit(bot: Bot, chat_id: int):
    """Дебаунс: правим сразу, если прошло >= EDIT_DEBOUNCE,
    иначе планируем правку через остаток интервала (одну на чат)."""
    now = _t.monotonic()
    last = _last_edit_ts.get(chat_id, 0)
    elapsed = now - last
    if elapsed >= EDIT_DEBOUNCE:
        # правка сразу
        asyncio.create_task(_do_edit(bot, chat_id))
        _last_edit_ts[chat_id] = now
        return
    # уже есть отложенная — ничего не делаем
    pending = _pending_edit.get(chat_id)
    if pending and not pending.done():
        return
    delay = EDIT_DEBOUNCE - elapsed
    _pending_edit[chat_id] = asyncio.create_task(_delayed_edit(bot, chat_id, delay))


@router.message(F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}), HasGoalFilter())
async def on_chat_message(message: Message, bot: Bot):
    if not message.from_user or message.from_user.is_bot:
        return
    if message.text and message.text.startswith("/"):
        return
    st = get_goal(message.chat.id)
    if not st or not st.running:
        return
    # v27: админы чата не учитываются (пишут «бесплатно» и не должны выигрывать).
    try:
        if await is_chat_admin(bot, message.chat.id, message.from_user.id):
            return
    except Exception:
        pass
    if is_ignored(message.from_user.id, "goal"):
        return

    uid = message.from_user.id
    uname = username_of(message)
    remember_username(message)

    # v27: храним {name, messages}. Поддерживаем старый формат на чтение.
    info = st.participants.get(uid)
    if isinstance(info, dict):
        info["name"] = uname
        info["messages"] = int(info.get("messages", 0)) + 1
    else:
        st.participants[uid] = {"name": uname, "messages": 1}
    st.current += 1

    reached = st.current >= st.target
    # редактируем сообщение после КАЖДОГО сообщения (с дебаунсом)
    _schedule_edit(bot, message.chat.id)

    if reached:
        # дать последней правке отрисоваться, потом финиш
        await asyncio.sleep(0.2)
        await _finish(bot, message.chat.id, by_time=False)
