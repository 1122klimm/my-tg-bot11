"""Лотерея: 1 сообщение в чат = 1 билет.
v18: убрали Stars — билет даётся за каждое сообщение участника.
«Стоимость билета» = средняя стоимость сообщения чата (1 билет = 1 сообщение).
В стартовом сообщении показываем активность чата (msg/мин) и обновляем её.
Команда: /lottery <время> [x<призов>] [приз]
"""
import asyncio
import random
import time
from datetime import datetime, timezone, timedelta

from aiogram import Router, F, Bot
from aiogram.enums import ChatType
from aiogram.filters import Command, Filter
from aiogram.types import (
    Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery,
)

from access import is_admin, username_of, remember_username, remember_win, notify_win, is_ignored
from utils import storage, stats_push
from utils import secret_mode
from utils.duration import parse_duration, format_duration
from utils.report import send_post_game_report
from utils.win_photo import send_win_photo, send_start_photo
from game import LotteryState, get_lottery, set_lottery, drop_lottery, drop_all_games, deadline_notifier
from help_texts import NO_ACCESS, EVENT_FOOTER

router = Router(name="lottery")
DURATION_TOKEN = ("s", "m", "h", "d")

# Окно для оценки активности чата (5 минут)
ACTIVITY_WINDOW_SEC = 300


def _stop_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📊 Мои билеты", callback_data="lot:my")],
        [InlineKeyboardButton(text="⛔ Остановить (админ)", callback_data="stop:lottery")],
    ])


def _split_time(tokens: list):
    time_parts = []
    i = 0
    for tok in tokens:
        t = tok.lower()
        if t.isdigit() or (len(t) >= 2 and t[-1] in DURATION_TOKEN and t[:-1].isdigit()):
            time_parts.append(tok); i += 1
        else:
            break
    if not time_parts:
        return 0, tokens
    secs = parse_duration(" ".join(time_parts)) or 0
    return secs, tokens[i:]


def _extract_count(tokens: list):
    count = 1
    rest = []
    for tok in tokens:
        low = tok.lower()
        if low.startswith("x") and low[1:].isdigit():
            count = max(1, int(low[1:]))
        else:
            rest.append(tok)
    return count, rest


def _activity(st: LotteryState) -> tuple:
    """Возвращает (msgs_in_window, msgs_per_min)."""
    now = time.time()
    cutoff = now - ACTIVITY_WINDOW_SEC
    st.message_times = [t for t in st.message_times if t >= cutoff]
    msgs = len(st.message_times)
    per_min = round(msgs / (ACTIVITY_WINDOW_SEC / 60), 1)
    st.ticket_price_stars = 1  # символически: 1 билет = 1 сообщение
    return msgs, per_min


def _status_text(st: LotteryState) -> str:
    msgs, per_min = _activity(st)
    prize_line = f"🎁 <b>Приз:</b> {st.prize}\n" if st.prize else "🎁 <b>Приз:</b> <i>не задан</i>\n"
    deadline_line = f"⏱ <b>Финиш:</b> {st.deadline_msk_str()} по МСК\n" if st.deadline else ""
    return (
        f"🎟 <b>ЛОТЕРЕЯ</b>\n\n"
        f"💬 <b>1 сообщение в чат = 1 билет</b>\n"
        f"📈 <b>Активность чата:</b> {msgs} сообщ. за 5 мин (~{per_min}/мин)\n"
        f"💎 <b>Цена 1 билета:</b> 1 сообщение\n"
        f"🏆 <b>Призов:</b> <b>{st.prizes_count}</b>\n"
        f"{deadline_line}"
        f"{prize_line}"
        f"\n📊 <b>Куплено билетов:</b> <b>{st.total_tickets}</b>\n"
        f"👥 <b>Участников:</b> <b>{len(st.participants)}</b>\n\n"
        f"<i>Просто пиши в чат — каждое сообщение даёт билет. "
        f"Чем больше билетов — тем выше шанс.</i>"
    )


@router.message(Command(commands=["lottery", "лотерея"]))
async def cmd_lottery(message: Message, bot: Bot):
    stats_push.report_start(message, "lottery")
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await message.reply("Запускать лотерею можно только в групповом чате.")
        return
    if not is_admin(message.from_user.id):
        await message.reply(NO_ACCESS)
        return

    parts = (message.text or "").split()
    tokens = parts[1:]
    secs, tokens = _split_time(tokens)
    prizes_count, tokens = _extract_count(tokens)
    prize = " ".join(tokens).strip() or storage.get().get("prize_url", "")

    if not secs:
        await message.reply(
            "Использование: <code>/lottery &lt;время&gt; [x&lt;призов&gt;] [приз]</code>\n\n"
            "• <code>/lottery 30m nft</code>\n"
            "• <code>/lottery 1h x3 nft</code>\n\n"
            "1 сообщение в чат = 1 билет. Победители выбираются случайно среди всех билетов."
        )
        return

    drop_all_games(message.chat.id)
    deadline = datetime.now(timezone.utc) + timedelta(seconds=secs)
    st = LotteryState(
        chat_id=message.chat.id,
        duration=secs,
        deadline=deadline,
        prize=prize,
        prizes_count=prizes_count,
        running=True,
        started_at=datetime.now(timezone.utc),
    )
    set_lottery(st)

    # Картинка старта (отдельным сообщением, чтобы можно было edit_message_text у статуса)
    try:
        await send_start_photo(bot, message.chat.id, "lottery", "🎟 <b>Лотерея стартует!</b>")
    except Exception:
        pass

    msg = await message.answer(
        _status_text(st) + EVENT_FOOTER,
        reply_markup=_stop_kb(),
    )
    st.announce_message_id = msg.message_id

    st.task = asyncio.create_task(_runner(bot, message.chat.id))


async def _runner(bot: Bot, chat_id: int):
    notifier = asyncio.create_task(deadline_notifier(bot, chat_id, get_lottery, "Лотерея"))
    refresher = asyncio.create_task(_refresh_loop(bot, chat_id))
    try:
        st = get_lottery(chat_id)
        if not st or not st.deadline:
            return
        delay = (st.deadline - datetime.now(timezone.utc)).total_seconds()
        if delay > 0:
            try:
                await asyncio.sleep(delay)
            except asyncio.CancelledError:
                return
        st = get_lottery(chat_id)
        if st and st.running:
            await _finish(bot, chat_id)
    finally:
        for t in (notifier, refresher):
            if not t.done():
                t.cancel()


async def _refresh_loop(bot: Bot, chat_id: int):
    """Обновляем активность и счётчики каждые 30 сек."""
    try:
        while True:
            await asyncio.sleep(30)
            st = get_lottery(chat_id)
            if not st or not st.running or not st.announce_message_id:
                return
            try:
                await bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=st.announce_message_id,
                    text=_status_text(st) + EVENT_FOOTER,
                    reply_markup=_stop_kb(),
                )
            except Exception:
                pass
    except asyncio.CancelledError:
        return


async def _finish(bot: Bot, chat_id: int):
    st = get_lottery(chat_id)
    if not st:
        return
    st.running = False
    if st.total_tickets == 0:
        await bot.send_message(chat_id, "🎟 <b>Лотерея завершена</b>, но никто не написал — билетов нет.")
        # v33: даже пустой отчёт — чтобы видеть что ивент был
        try:
            chat = await bot.get_chat(chat_id)
            chat_title = chat.title
        except Exception:
            chat_title = None
        try:
            await send_post_game_report(
                bot,
                chat_id=chat_id,
                chat_title=chat_title,
                game_type="lottery",
                game_label="🎟 Лотерея",
                started_at=st.started_at,
                duration_planned=st.duration,
                participants={},
                messages_total=st.messages_total,
                stars_spent=int(st.stars_spent or 0),
                ton_spent=0.0,
                winners=[],
                prize=st.prize or "",
            )
        except Exception:
            pass
        drop_lottery(chat_id)
        return

    # Плоский пул (uid, ticket_no), победители — уникальные пользователи
    pool = []
    for uid, info in st.participants.items():
        for tn in info["tickets"]:
            pool.append((uid, tn))
    random.shuffle(pool)

    chosen = []
    seen = set()
    # v42: /secret lottery <username> — принудительный победитель
    forced = secret_mode.get_lottery_force(chat_id)
    if forced:
        for uid, info in st.participants.items():
            uname = (info.get("username") or "").lstrip("@").lower()
            if uname == forced:
                tickets = info.get("tickets") or []
                tn = tickets[0] if tickets else 1
                chosen.append((uid, tn))
                seen.add(uid)
                break
        # сбрасываем после использования
        try:
            secret_mode.set_lottery_force(chat_id, None)
        except Exception:
            pass
    for uid, tn in pool:
        if uid in seen:
            continue
        seen.add(uid)
        chosen.append((uid, tn))
        if len(chosen) >= st.prizes_count:
            break

    prize = st.prize or storage.get().get("prize_url", "")
    lines = [
        "🎉 <b>ЛОТЕРЕЯ ЗАВЕРШЕНА!</b>",
        f"🎟 Всего билетов: <b>{st.total_tickets}</b>",
        f"👥 Участников: <b>{len(st.participants)}</b>",
        "",
        f"🏆 <b>Победител{'ь' if len(chosen) == 1 else 'и'}:</b>",
    ]
    for uid, tn in chosen:
        uname = st.participants[uid]["username"]
        lines.append(f"   • {uname} — выигрышный билет <b>№{tn}</b>")
        remember_win(uid, uname, prize, "lottery")
    if prize:
        lines.append(f"\n🎁 <b>Приз:</b> {prize}")
    await send_win_photo(bot, chat_id, "lottery", caption="\n".join(lines))

    try:
        chat = await bot.get_chat(chat_id)
        for uid, _tn in chosen:
            uname = st.participants[uid]["username"]
            await notify_win(bot, chat.title or "", uname, prize, "lottery")
    except Exception:
        pass

    # v33: пост-игровой отчёт админам в ЛС.
    try:
        chat = await bot.get_chat(chat_id)
        chat_title = chat.title
    except Exception:
        chat_title = None
    # Преобразуем участников в формат отчёта (uid -> {name, messages, stars})
    parts_for_report = {}
    for uid, info in st.participants.items():
        parts_for_report[uid] = {
            "name": info.get("username") or "",
            "messages": len(info.get("tickets") or []),
            "stars": 0,
        }
    winners_for_report = []
    for uid, _tn in chosen:
        winners_for_report.append((uid, st.participants[uid]["username"]))
    try:
        await send_post_game_report(
            bot,
            chat_id=chat_id,
            chat_title=chat_title,
            game_type="lottery",
            game_label="🎟 Лотерея",
            started_at=st.started_at,
            duration_planned=st.duration,
            participants=parts_for_report,
            messages_total=st.messages_total or st.total_tickets,
            stars_spent=int(st.stars_spent or 0),
            ton_spent=0.0,
            winners=winners_for_report,
            prize=prize,
        )
    except Exception:
        pass

    drop_lottery(chat_id)


# ============================================================
# «Мои билеты»
# ============================================================
@router.callback_query(F.data == "lot:my")
async def cb_my(cb: CallbackQuery):
    if not cb.message:
        await cb.answer()
        return
    st = get_lottery(cb.message.chat.id)
    if not st:
        await cb.answer("Лотерея не активна.", show_alert=True)
        return
    info = st.participants.get(cb.from_user.id)
    if not info or not info["tickets"]:
        await cb.answer("У вас пока нет билетов. Напишите в чат, чтобы получить билет!", show_alert=True)
        return
    nums = info["tickets"]
    head = nums[:30]
    tail = f", … и ещё {len(nums) - 30}" if len(nums) > 30 else ""
    text = f"У вас {len(nums)} билетов: №№ " + ", ".join(map(str, head)) + tail
    await cb.answer(text[:190], show_alert=True)


# ============================================================
# Учёт сообщений: каждое сообщение = +1 билет участнику + учёт активности
# ============================================================
class HasLotteryFilter(Filter):
    async def __call__(self, message: Message) -> bool:
        return get_lottery(message.chat.id) is not None


@router.message(F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}), HasLotteryFilter())
async def on_chat_msg_track(message: Message, bot: Bot):
    if not message.from_user or message.from_user.is_bot:
        return
    if message.text and message.text.startswith("/"):
        return
    st = get_lottery(message.chat.id)
    if not st or not st.running:
        return

    # v42: админы в игноре полностью исключаются — не считаем их активность
    if is_ignored(message.from_user.id, "lottery"):
        return

    # учёт активности (для отображения «цены»)
    st.message_times.append(time.time())
    # v33: общая статистика за ивент
    st.messages_total += 1
    msg_stars = int(getattr(message, "paid_star_count", 0) or 0)
    if msg_stars:
        st.stars_spent += msg_stars

    remember_username(message)
    uid = message.from_user.id
    info = st.participants.setdefault(uid, {"username": "", "tickets": []})
    if message.from_user.username:
        info["username"] = "@" + message.from_user.username
    else:
        info["username"] = message.from_user.full_name or str(uid)

    info["tickets"].append(st.next_ticket_no)
    st.next_ticket_no += 1
