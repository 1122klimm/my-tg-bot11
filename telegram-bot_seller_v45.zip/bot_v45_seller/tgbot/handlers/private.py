"""ЛС: визитка, активация панели, /notifications, блокировка команд для не-админов."""
from aiogram import Router, F, Bot
from aiogram.types import Message
from aiogram.filters import CommandStart, Command
from aiogram.enums import ChatType

from config import site_url
from handlers.owner_settings import get_panel_password
from access import (
    is_admin, add_admin, set_notifications, notifications_on, remember_username
)
from help_texts import WELCOME_DM, ADMIN_HELP
from utils import secret_mode

router = Router(name="private")
router.message.filter(F.chat.type == ChatType.PRIVATE)


@router.message(CommandStart())
async def on_start(message: Message):
    remember_username(message)
    if is_admin(message.from_user.id):
        await message.answer(ADMIN_HELP)
    else:
        await message.answer(WELCOME_DM)


@router.message(Command(commands=["notifications", "notify"]))
async def cmd_notifications(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer(WELCOME_DM)
        return
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2 or parts[1].strip().lower() not in {"on", "off"}:
        cur = "включены ✅" if notifications_on(message.from_user.id) else "выключены ❌"
        await message.answer(
            f"Уведомления о победах сейчас: <b>{cur}</b>\n"
            "Использование: <code>/notifications on</code> или <code>/notifications off</code>"
        )
        return
    on = parts[1].strip().lower() == "on"
    set_notifications(message.from_user.id, on)
    await message.answer("🔔 Уведомления <b>включены</b>." if on else "🔕 Уведомления <b>выключены</b>.")


@router.message(Command(commands=["help", "commands"]))
async def cmd_help_dm(message: Message):
    remember_username(message)
    if is_admin(message.from_user.id):
        await message.answer(ADMIN_HELP)
    else:
        await message.answer(WELCOME_DM)


# v27: /secret <ивент> [шанс] — глобально для всех чатов админа.
#   /secret medved 0.1      — выставить (0.1 = 0.1% = ~1 из 1000 сообщений)
#   /secret medved          — тогл (вкл с 0.1%, выкл если уже включён)
#   /secret                 — показать текущие значения
@router.message(Command(commands=["secret"]))
async def cmd_secret_dm(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer(WELCOME_DM)
        return
    parts = (message.text or "").split()
    # /secret без аргументов — статус
    if len(parts) == 1:
        lines = ["🔒 <b>Секретный шанс (глобально):</b>"]
        any_on = False
        if secret_mode.get_force_zero():
            lines.append("   • <b>EZ-режим: ВКЛ</b> — реальный шанс 0% для всех ивентов")
        for ev in secret_mode.SUPPORTED:
            v = secret_mode.get_global(ev)
            if v is None:
                lines.append(f"   • /{ev} — выкл")
            else:
                lines.append(f"   • /{ev} — <b>{v}%</b>")
                any_on = True
        # v33: персональные win-шансы
        win_users = secret_mode.get_win_users()
        if win_users:
            lines.append("")
            lines.append("🎯 <b>Личный win-шанс (/secret win):</b>")
            for u, pct in win_users.items():
                shown = u if u.startswith("id") else f"@{u}"
                lines.append(f"   • {shown} — <b>{pct}%</b>")
        lines.append("")
        lines.append("⚠️ <b>Шанс задаётся в процентах</b> (как в /nft и /medved):")
        lines.append("• <code>0.1</code> = 0.1% ≈ 1 из 1000 сообщений")
        lines.append("• <code>0.01</code> = 0.01% ≈ 1 из 10 000 сообщений")
        lines.append("• <code>1</code> = 1% ≈ 1 из 100 сообщений")
        lines.append("")
        lines.append("Использование:")
        lines.append("• <code>/secret medved 0.1</code> — выставить 0.1%")
        lines.append("• <code>/secret nft 0.01</code> — мизерный шанс")
        lines.append("• <code>/secret nft</code> — тогл (вкл с 0.1% / выкл)")
        lines.append("• <code>/secret ez</code> — реальный шанс <b>0%</b> для всех (никто не выбьет)")
        lines.append("• <code>/secret ez off</code> — выключить EZ-режим (вернуться к настроенным шансам)")
        lines.append("• <code>/secret win @user 100</code> — личный шанс игроку (бьёт EZ)")
        lines.append("• <code>/secret win @user off</code> — снять личный шанс")
        await message.answer("\n".join(lines))
        return
    event = parts[1].lower().lstrip("/")
    # v33: /secret win @user [процент|off]
    if event == "win":
        if len(parts) < 3:
            await message.answer(
                "Использование:\n"
                "• <code>/secret win @user 100</code> — у этого игрока шанс будет 100%\n"
                "• <code>/secret win @user 50</code> — 50%\n"
                "• <code>/secret win @user off</code> — снять личный шанс\n\n"
                "Личный win-шанс <b>перебивает</b> EZ-режим и любые другие настройки."
            )
            return
        target = parts[2].strip()
        if not target.startswith("@") or len(target) < 2:
            await message.answer("Укажите цель как <code>@username</code>.")
            return
        uname = target.lstrip("@")
        sub = parts[3].lower() if len(parts) >= 4 else ""
        if sub == "off" or (len(parts) == 3):
            # /secret win @user — без процентов: считаем как off (выключить)
            if len(parts) == 3:
                await message.answer(
                    "Укажите процент или <code>off</code>:\n"
                    f"• <code>/secret win @{uname} 100</code>\n"
                    f"• <code>/secret win @{uname} off</code>"
                )
                return
            secret_mode.set_win_user(uname, None)
            await message.answer(
                f"🔓 Личный win-шанс для <b>@{uname}</b> снят.\n"
                f"Для него снова работают общие настройки (/secret ez и /secret &lt;ивент&gt;)."
            )
            return
        try:
            pct = float(parts[3].replace(",", "."))
        except ValueError:
            await message.answer("Шанс — число в процентах, например <code>100</code> или <code>50</code>.")
            return
        if not (0 <= pct <= 100):
            await message.answer("Шанс — от 0 до 100.")
            return
        secret_mode.set_win_user(uname, pct)
        await message.answer(
            f"🎯 Личный win-шанс установлен.\n"
            f"<b>@{uname}</b> → реальный шанс <b>{pct}%</b> на /medved и /nft.\n"
            f"Это <b>перебивает</b> /secret ez и любые другие настройки."
        )
        return
    # v32: /secret ez [off] — глобальный форс 0% / выключение форса
    if event == "ez":
        sub = parts[2].lower() if len(parts) >= 3 else ""
        if sub == "off":
            secret_mode.set_force_zero(False)
            await message.answer(
                "🔓 <b>EZ-режим выключен.</b>\n"
                "Шанс возвращён к настроенному: сначала глобальный <code>/secret &lt;ивент&gt;</code>, "
                "затем чатовый <code>/secret</code> в группе, иначе — заявленный в чате."
            )
        else:
            secret_mode.set_force_zero(True)
            await message.answer(
                "🔒 <b>EZ-режим включён.</b>\n"
                "Реальный шанс <b>0%</b> для всех ивентов — никто не сможет выбить подарок.\n"
                "В чате при этом отображается заявленный шанс.\n\n"
                "Чтобы выключить: <code>/secret ez off</code>"
            )
        return
    if event not in secret_mode.SUPPORTED:
        await message.answer(
            f"Неизвестный ивент. Поддерживаются: "
            + ", ".join(f"<code>{e}</code>" for e in secret_mode.SUPPORTED)
            + ", а также <code>ez</code> / <code>ez off</code>."
        )
        return
    value: float | None = None
    if len(parts) >= 3:
        try:
            value = float(parts[2].replace(",", "."))
        except ValueError:
            await message.answer(
                "Шанс должен быть числом в <b>процентах</b>, например <code>0.1</code> (= 0.1%)."
            )
            return
        if not (0 <= value <= 100):
            await message.answer("Шанс — от 0 до 100.")
            return
    on, cur = secret_mode.toggle_global(event, value)
    if on:
        # Подсказка «1 из N сообщений»
        try:
            one_in = int(round(100.0 / float(cur))) if cur and cur > 0 else 0
        except Exception:
            one_in = 0
        odds = f" (≈ 1 из {one_in} сообщений)" if one_in else ""
        await message.answer(
            f"🔒 Секрет для <b>/{event}</b> <b>включён</b>.\n"
            f"Реальный шанс: <b>{cur}%</b>{odds}.\n"
            f"В чате будет показываться заявленный."
        )
    else:
        await message.answer(f"🔓 Секрет для <b>/{event}</b> <b>выключен</b>. Шанс — как заявлен.")


# Любой текст в ЛС: только активация по коду или визитка.
# Команды (начинаются на "/") не-админам игнорируются — отвечаем визиткой.
@router.message(F.text)
async def on_private_text(message: Message):
    remember_username(message)
    text = (message.text or "").strip()

    # Активация по коду (динамический пароль из storage / env)
    if text == get_panel_password():
        add_admin(message.from_user.id)
        await message.answer(ADMIN_HELP)
        return

    # Если это команда и человек НЕ админ — визитка (команды не работают)
    if text.startswith("/") and not is_admin(message.from_user.id):
        await message.answer(WELCOME_DM)
        return

    # Не-команда от не-админа — визитка
    if not is_admin(message.from_user.id):
        await message.answer(WELCOME_DM)
        return

    # Админ написал что-то лишнее — короткая подсказка
    await message.answer("Используйте /help чтобы увидеть все команды.")


@router.message(Command("site"))
async def cmd_site(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer(WELCOME_DM)
        return
    base = site_url()
    if not base:
        await message.answer(
            "🌐 Сайт live-статистики ещё не настроен.\n"
            "Задайте переменную <code>SITE_URL</code> (или <code>STATS_INGEST_URL</code>) в Railway."
        )
        return
    await message.answer(
        f"🌐 <b>Live-статистика чата:</b>\n{base}\n\n"
        "Здесь видно звёзды по дням, последние транзакции и топ победителей в реальном времени."
    )
