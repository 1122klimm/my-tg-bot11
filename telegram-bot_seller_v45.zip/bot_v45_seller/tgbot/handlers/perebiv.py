"""«Перебив» — кто последним написал, тот и победил. v19."""
import asyncio
import logging
import time as _t
from datetime import datetime, timezone, timedelta
from html import escape

from aiogram import Router, F, Bot
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
from aiogram.enums import ChatType

from utils import storage
from utils import stats_push
from utils.report import send_post_game_report
from utils import ton_rate
from utils.win_photo import send_win_photo, send_start_photo
from utils.duration import parse_duration, format_duration
from access import is_admin, username_of, remember_username, remember_win, notify_win, is_ignored
from game import PerebivState, get_state, set_state, drop_state, drop_all_games, MSK
from help_texts import NO_ACCESS, EVENT_FOOTER

router = Router(name="perebiv")
DURATION_TOKEN = ("s", "m", "h", "d")
log = logging.getLogger("perebiv")


def _user_handle(message: Message) -> str:
    """Кликабельный «тег» автора: @username или HTML-mention для бесюзернеймных."""
    u = message.from_user
    if not u:
        return "игрок"
    if u.username:
        return "@" + u.username
    return f'<a href="tg://user?id={u.id}">{escape(u.full_name or str(u.id))}</a>'


def _parse_gift(tokens: list[str]) -> tuple[int, float, list[str]]:
    """Извлекает gift=<stars> и ton=<float> из списка токенов."""
    gift_stars = 0
    gift_ton = 0.0
    rest = []
    for tok in tokens:
        low = tok.lower()
        if low.startswith("gift=") and low[5:].replace(".", "", 1).isdigit():
            try:
                gift_stars = int(float(low[5:]))
            except Exception:
                rest.append(tok)
        elif low.startswith("ton="):
            try:
                gift_ton = float(low[4:].replace(",", "."))
            except Exception:
                rest.append(tok)
        else:
            rest.append(tok)
    return gift_stars, gift_ton, rest


def _gift_line(st: PerebivState) -> str:
    if st.gift_stars or st.gift_ton:
        bits = []
        if st.gift_stars:
            bits.append(f"<b>{st.gift_stars}</b> ⭐")
        if st.gift_ton:
            bits.append(f"<b>{st.gift_ton:g}</b> TON")
        return f"\n💰 <b>Цена подарка:</b> " + " / ".join(bits)
    return ""


def _human_dur(secs: int) -> str:
    if secs < 60:
        return f"{secs}с"
    m, s = divmod(secs, 60)
    if m < 60:
        return f"{m}м {s}с" if s else f"{m}м"
    h, m = divmod(m, 60)
    return f"{h}ч {m}м"


def _split_time_and_prize(rest: str):
    rest = (rest or "").strip()
    if not rest:
        return "", ""
    tokens = rest.split()
    time_parts = []
    i = 0
    for tok in tokens:
        t = tok.lower()
        if t.isdigit() or (len(t) >= 2 and t[-1] in DURATION_TOKEN and t[:-1].isdigit()):
            time_parts.append(tok)
            i += 1
        else:
            break
    return " ".join(time_parts), " ".join(tokens[i:]).strip()


def _stop_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="⛔ Остановить игру", callback_data="stop:perebiv")
    ]])


@router.message(Command(commands=["startgame_perebiv", "start_perebiv", "start_перебив"]))
async def cmd_start(message: Message, bot: Bot):
    stats_push.report_start(message, "perebiv")
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await message.reply("Запускать игру можно только в групповом чате.")
        return
    if not is_admin(message.from_user.id):
        await message.reply(NO_ACCESS)
        return

    parts = (message.text or "").split(maxsplit=1)
    rest = parts[1] if len(parts) > 1 else ""
    time_str, prize_part = _split_time_and_prize(rest)
    prize_tokens = prize_part.split() if prize_part else []
    gift_stars, gift_ton, prize_tokens = _parse_gift(prize_tokens)
    prize = " ".join(prize_tokens).strip()

    secs = 0
    if time_str:
        secs = parse_duration(time_str) or 0
        if not secs:
            await message.reply("Не понял время. Примеры: <code>30s</code>, <code>1m 30s</code>, <code>2h</code>")
            return

    if not prize:
        prize = storage.get().get("prize_url", "")

    drop_all_games(message.chat.id)
    deadline = datetime.now(timezone.utc) + timedelta(seconds=secs) if secs else None
    st = PerebivState(
        chat_id=message.chat.id, message_thread_id=getattr(message, "message_thread_id", None),
        duration=secs, prize=prize,
        deadline=deadline, running=True,
        started_at=datetime.now(timezone.utc),
        gift_stars=gift_stars, gift_ton=gift_ton,
    )
    set_state(st)
    if secs:
        _schedule(bot, st)

    prize_line = f"\n🎁 <b>Приз:</b> {prize}" if prize else "\n🎁 <b>Приз:</b> <i>не задан</i>"
    gift_line = _gift_line(st)
    if secs:
        time_line = (
            f"⏱ <b>Длительность:</b> {format_duration(secs)}\n"
            f"🎯 <b>Финиш:</b> {st.deadline_msk_str()} по МСК"
        )
    else:
        time_line = "⏱ <b>Длительность:</b> до <code>/stop</code>"

    sent = await send_start_photo(
        bot, message.chat.id, "perebiv",
        f"🎮 <b>«Перебив» запущен!</b>\n{time_line}{prize_line}{gift_line}\n\n"
        f"Кто последним напишет в чат — тот и победил."
        f"{EVENT_FOOTER}",
        reply_markup=_stop_kb(),
        message_thread_id=st.message_thread_id,
    )
    if not sent:
        await message.answer(
            f"🎮 <b>«Перебив» запущен!</b>\n{time_line}{prize_line}{gift_line}\n\n"
            f"Кто последним напишет в чат — тот и победил."
            f"{EVENT_FOOTER}",
            reply_markup=_stop_kb(),
        )


# Длинные метки + ежесекундный отсчёт последних 14 секунд
LONG_MARKS = (30 * 60, 15 * 60, 5 * 60, 60, 30, 15)
TAGGED_MARKS = {60, 30, 15}  # 1 мин / 30 сек / 15 сек — добавляем тег лидера
LAST_TICKS = tuple(range(14, 0, -1))


async def _countdown_loop(bot: Bot, chat_id: int, deadline_iso: str):
    try:
        while True:
            st = get_state(chat_id)
            if not st or not st.running or not st.deadline:
                return
            if st.deadline.isoformat() != deadline_iso:
                return
            remaining = (st.deadline - datetime.now(timezone.utc)).total_seconds()
            if remaining <= 0:
                return
            r = int(remaining)
            for mark in LONG_MARKS:
                if r == mark and mark not in st.notified_marks:
                    st.notified_marks.add(mark)
                    label = f"{mark // 60} мин" if mark >= 60 else f"{mark} сек"
                    tag = ""
                    if mark in TAGGED_MARKS and st.last_username_handle:
                        tag = f"\n👑 Сейчас лидер: {st.last_username_handle}"
                    try:
                        await bot.send_message(
                            chat_id,
                            f"⏳ <b>До конца перебива осталось {label}!</b>{tag}",
                            message_thread_id=st.message_thread_id,
                        )
                    except Exception:
                        pass
            if r in LAST_TICKS and r not in st.notified_marks:
                st.notified_marks.add(r)
                try:
                    await bot.send_message(chat_id, f"⏱ <b>{r}…</b>", message_thread_id=st.message_thread_id)
                except Exception:
                    pass
            await asyncio.sleep(1)
    except asyncio.CancelledError:
        return
    except Exception:
        return


async def _finish_round(bot: Bot, chat_id: int):
    try:
        st = get_state(chat_id)
        if not st or not st.deadline:
            return
        deadline_iso = st.deadline.isoformat()
        cd = asyncio.create_task(_countdown_loop(bot, chat_id, deadline_iso))
        try:
            await asyncio.sleep(max(0, (st.deadline - datetime.now(timezone.utc)).total_seconds()))
        finally:
            if not cd.done():
                cd.cancel()
        st = get_state(chat_id)
        if not st or not st.running:
            return
        if st.deadline and st.deadline.isoformat() != deadline_iso:
            return

        winner_id = st.last_user_id
        if not winner_id:
            await bot.send_message(chat_id, "🤷 Никто не перебил — победителя нет.", message_thread_id=st.message_thread_id)
            drop_state(chat_id)
            return

        # v21: без 1.5с грейс-окна. Раунд завершается мгновенно.
        winner_id = st.last_user_id
        winner_name = st.last_username
        winner_handle = st.last_username_handle or winner_name
        prize = st.prize or storage.get().get("prize_url", "").strip()
        st.last_user_is_winner_announced = True

        remember_win(winner_id, winner_name, prize, "perebiv")
        try:
            chat = await bot.get_chat(chat_id)
            chat_title = chat.title
        except Exception:
            chat_title = None
        avatar_url = None
        try:
            photos = await bot.get_user_profile_photos(winner_id, limit=1)
            if photos.total_count and photos.photos:
                f = await bot.get_file(photos.photos[0][-1].file_id)
                avatar_url = f"https://api.telegram.org/file/bot<token>/{f.file_path}"
        except Exception:
            pass
        prize_line = f"\n🎁 <b>Приз:</b> {prize}" if prize else ""
        gift_line = _gift_line(st)
        elapsed = 0
        if st.started_at:
            elapsed = int((datetime.now(timezone.utc) - st.started_at).total_seconds())
        stats_push.push_event(
            chat_id=chat_id, chat_title=chat_title,
            user_id=winner_id, username=winner_name.lstrip("@") if winner_name and winner_name.startswith("@") else None,
            full_name=winner_name, avatar_url=None,
            game_type="perebiv", event_type="won", prize=prize,
            stars_value=int(st.stars_spent or 0),
            ton_value=float(st.ton_spent or 0),
            meta={"perebivs_count": st.perebivs_count, "duration_sec": elapsed},
        )
        stats_line = (
            f"\n\n📊 <b>Статистика раунда:</b>\n"
            f"   ⏱ Длительность: <b>{_human_dur(elapsed)}</b>\n"
            f"   🔁 Перебивов: <b>{st.perebivs_count}</b>"
        )
        if st.stars_spent:
            stats_line += f"\n   ⭐ Потрачено звёзд: <b>{int(st.stars_spent)}</b>"
            # v27: правильный эквивалент в TON по курсу
            try:
                ton_eq = await ton_rate.stars_to_ton(int(st.stars_spent))
                if ton_eq:
                    stats_line += f"\n   🪙 ≈ <b>{ton_eq:g}</b> TON"
            except Exception:
                pass
        # v33: строку «Потрачено TON» убрали — она дублировалась через
        # gift_ton × сообщения. Оставляем только TON-эквивалент звёзд.

        await send_win_photo(
            bot, chat_id, "perebiv",
            caption=(
                f"🏆 <b>ПОБЕДИТЕЛЬ ОПРЕДЕЛЁН</b>\n\n"
                f"👑 <b>Победитель:</b> {winner_handle}{prize_line}{gift_line}{stats_line}"
            ),
            message_thread_id=st.message_thread_id,
        )
        try:
            chat = await bot.get_chat(chat_id)
            await notify_win(bot, chat.title or "", winner_name, prize, "perebiv")
        except Exception:
            pass
        # v25: пост-игровой отчёт админам в ЛС
        try:
            await send_post_game_report(
                bot,
                chat_id=chat_id,
                chat_title=chat_title,
                game_type="perebiv",
                game_label="🎮 Перебив",
                started_at=st.started_at,
                duration_planned=st.duration,
                participants=st.participants,
                messages_total=st.perebivs_count,
                stars_spent=int(st.stars_spent or 0),
                ton_spent=float(st.ton_spent or 0),
                winners=[(winner_id, winner_name)],
                prize=prize,
            )
        except Exception:
            pass
        drop_state(chat_id)
    except asyncio.CancelledError:
        return
    except Exception as e:
        try:
            await bot.send_message(chat_id, f"⚠️ Ошибка завершения раунда: {e}", message_thread_id=getattr(get_state(chat_id), "message_thread_id", None))
        except Exception:
            pass


def _schedule(bot: Bot, st: PerebivState):
    if st.task and not st.task.done():
        st.task.cancel()
    st.notified_marks = set()
    st.last_user_is_winner_announced = False
    st.task = asyncio.create_task(_finish_round(bot, st.chat_id))


SERVICE_ATTRS = (
    "boost_added", "new_chat_members", "left_chat_member", "pinned_message",
    "new_chat_title", "new_chat_photo", "delete_chat_photo",
    "group_chat_created", "supergroup_chat_created", "channel_chat_created",
    "message_auto_delete_timer_changed", "video_chat_started", "video_chat_ended",
    "video_chat_participants_invited", "video_chat_scheduled",
    "forum_topic_created", "forum_topic_edited", "forum_topic_closed", "forum_topic_reopened",
    "users_shared", "chat_shared",
    "giveaway", "giveaway_created", "giveaway_winners", "giveaway_completed",
)

# Анти-спам апдейтов перебива
_last_update_ts: dict = {}


@router.message(F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}))
async def on_chat_message(message: Message, bot: Bot):
    if any(getattr(message, a, None) for a in SERVICE_ATTRS):
        return
    if not message.from_user or message.from_user.is_bot:
        return
    if message.text and message.text.startswith("/"):
        return
    remember_username(message)
    # v20: AI-чат — может ответить на упоминание/реплай/триггер.
    st = get_state(message.chat.id)
    if not st or not st.running:
        return
    if st.message_thread_id is not None and getattr(message, "message_thread_id", None) != st.message_thread_id:
        return
    if is_ignored(message.from_user.id, "perebiv"):
        return
    # АТОМАРНАЯ регистрация перебива — лок на чат, чтобы при одновременных
    # сообщениях оба гарантированно попали в счётчик и не сгорели звёзды.
    async with st.lock():
        st2 = get_state(message.chat.id)
        if not st2 or not st2.running:
            return
        prev_handle = st2.last_username_handle
        st2.last_user_id = message.from_user.id
        st2.last_username = username_of(message)
        st2.last_username_handle = _user_handle(message)
        st2.last_message_id = message.message_id
        st2.perebivs_count += 1
        # v26: фактическая цена из самого сообщения. Telegram кладёт её
        # в message.paid_star_count для платных сообщений. Если ручная смена
        # цены в чате (1⭐ → 4⭐) — каждое сообщение посчитается по своей
        # реальной цене. Fallback — gift_stars из state.
        msg_stars = int(getattr(message, "paid_star_count", 0) or 0)
        if not msg_stars and st2.gift_stars:
            msg_stars = int(st2.gift_stars)
        if msg_stars:
            st2.stars_spent += msg_stars
        if st2.gift_ton:
            st2.ton_spent += st2.gift_ton
        # v25: накапливаем участников
        uid = message.from_user.id
        info = st2.participants.setdefault(uid, {"name": st2.last_username, "messages": 0, "stars": 0})
        info["name"] = st2.last_username
        info["messages"] = int(info.get("messages", 0)) + 1
        if msg_stars:
            info["stars"] = int(info.get("stars", 0)) + msg_stars
        if st2.duration:
            st2.deadline = datetime.now(timezone.utc) + timedelta(seconds=st2.duration)
            _schedule(bot, st2)
        fresh = st2

    # Уведомление в чат — вне лока.
    rival_line = f" перебил {prev_handle}!" if prev_handle else " сделал первый перебив!"
    if fresh.duration:
        now = _t.monotonic()
        last = _last_update_ts.get(message.chat.id, 0)
        if now - last < 0.6:
            return
        _last_update_ts[message.chat.id] = now
        text = (
            f"⏳ {fresh.last_username_handle}{rival_line}\n"
            f"Победитель определится в {fresh.deadline_msk_str()} по МСК."
        )
    else:
        text = f"⏳ {fresh.last_username_handle}{rival_line}"

    try:
        msg = await bot.send_message(message.chat.id, text, message_thread_id=fresh.message_thread_id)
        fresh.bot_status_message_id = msg.message_id
    except Exception as e:
        log.warning("perebiv update send failed chat=%s thread=%s: %s", message.chat.id, fresh.message_thread_id, e)
