"""Админ-команды чата: доступы, /say, /stop, /delete, /stats, мут/бан, /setprize, /settime."""
from html import escape
from aiogram import Router, F, Bot
from aiogram.types import Message, ChatPermissions
from aiogram.filters import Command
from aiogram.enums import ChatType

from utils import storage
from utils.duration import parse_duration, format_duration
from config import site_url
from access import (
    is_admin, is_super, add_admin, remove_admin, remember_username, username_of,
    resolve_username, ignore_global, unignore_global, ignore_event, unignore_event,
    ignore_chat_admins, unignore_chat_admins,
)
from utils.storage import EVENT_TYPES
from utils import secret_mode
from game import (
    drop_all_games, drop_state, drop_dice_state, drop_quiz_state, drop_number,
    drop_roulette, get_all_roulettes, drop_goal, drop_lottery,
    get_state, get_dice_state, get_quiz_state, get_number, get_goal, get_lottery,
)
from help_texts import NO_ACCESS, ADMIN_HELP
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton

router = Router(name="admin")


# ---------- /site (работает и в чате, и в ЛС) ----------
@router.message(Command(commands=["site"]))
async def cmd_site_anywhere(message: Message):
    if not await _guard(message):
        return
    base = site_url()
    if not base:
        await message.reply(
            "🌐 Сайт live-статистики ещё не настроен.\n"
            "Задайте <code>SITE_URL</code> (или <code>STATS_INGEST_URL</code>) в Railway."
        )
        return
    await message.reply(
        f"🌐 <b>Live-статистика чата:</b>\n{base}\n\n"
        "Звёзды, победы и транзакции в реальном времени."
    )


# ---------- общий гард: все команды только для админов ----------
async def _guard(message: Message) -> bool:
    remember_username(message)
    if is_admin(message.from_user.id):
        return True
    # Команда есть, но юзер не админ — отвечаем "нет доступа" один раз
    try:
        await message.reply(NO_ACCESS)
    except Exception:
        pass
    return False


# ---------- /help в чате ----------
@router.message(Command(commands=["help", "commands"]))
async def cmd_help(message: Message):
    if not await _guard(message):
        return
    await message.answer(ADMIN_HELP)


# ---------- /giveaccess ----------
@router.message(Command(commands=["giveaccess", "grant"]))
async def cmd_giveaccess(message: Message, bot: Bot):
    if not await _guard(message):
        return
    if not is_super(message.from_user.id):
        await message.reply("Выдавать доступ может только супер-админ.")
        return

    target_id = None
    target_label = None

    # Через reply
    if message.reply_to_message and message.reply_to_message.from_user:
        target_id = message.reply_to_message.from_user.id
        u = message.reply_to_message.from_user
        target_label = "@" + u.username if u.username else (u.full_name or str(u.id))

    # Через @username или числовой id
    parts = (message.text or "").split()
    if len(parts) >= 2 and target_id is None:
        arg = parts[1].strip()
        if arg.isdigit():
            target_id = int(arg)
            target_label = str(target_id)
        elif arg.startswith("@"):
            uname = arg[1:].lower()
            mapping = storage.get().get("admin_usernames", {})
            uid = mapping.get(uname)
            if uid:
                target_id = uid
                target_label = arg
            else:
                await message.reply(
                    f"Не вижу пользователя {arg}. Попроси его написать боту в ЛС "
                    "(хотя бы /start), чтобы я узнал его id, или сделай reply на его сообщение."
                )
                return

    if target_id is None:
        await message.reply(
            "Использование: <code>/giveaccess @ник</code> или reply на сообщение пользователя."
        )
        return

    add_admin(target_id)
    await message.reply(f"✅ Доступ выдан: {target_label}")


@router.message(Command(commands=["revoke"]))
async def cmd_revoke(message: Message):
    if not await _guard(message):
        return
    if not is_super(message.from_user.id):
        await message.reply("Забирать доступ может только супер-админ.")
        return

    target_id = None
    parts = (message.text or "").split()
    if message.reply_to_message and message.reply_to_message.from_user:
        target_id = message.reply_to_message.from_user.id
    elif len(parts) >= 2:
        arg = parts[1].strip()
        if arg.isdigit():
            target_id = int(arg)
        elif arg.startswith("@"):
            mapping = storage.get().get("admin_usernames", {})
            target_id = mapping.get(arg[1:].lower())

    if not target_id:
        await message.reply("Использование: <code>/revoke @ник</code> или <code>/revoke &lt;id&gt;</code>")
        return

    if remove_admin(target_id):
        await message.reply(f"✅ Доступ забран у {target_id}.")
    else:
        await message.reply("Не удалось забрать доступ (нет такого админа или это супер-админ).")


@router.message(Command(commands=["admins"]))
async def cmd_admins(message: Message):
    if not await _guard(message):
        return
    data = storage.get()
    admins = data.get("admins", [])
    super_id = data.get("super_admin")
    if not admins:
        await message.reply("Админов нет.")
        return
    lines = ["🛡 <b>Админы панели:</b>"]
    for uid in admins:
        suffix = " 👑 (супер)" if uid == super_id else ""
        lines.append(f"• <code>{uid}</code>{suffix}")
    await message.reply("\n".join(lines))


# ---------- /setprize, /settime ----------
@router.message(Command(commands=["setprize"]))
async def cmd_setprize(message: Message):
    if not await _guard(message):
        return
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await message.reply("Использование: <code>/setprize https://t.me/nft/...</code>")
        return
    url = parts[1].strip()
    storage.update(lambda d: d.__setitem__("prize_url", url))
    await message.reply(f"✅ Приз по умолчанию: {url}")


@router.message(Command(commands=["settime"]))
async def cmd_settime(message: Message):
    if not await _guard(message):
        return
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await message.reply("Использование: <code>/settime 1m 30s</code>")
        return
    secs = parse_duration(parts[1])
    if not secs:
        await message.reply("Не понял время. Примеры: 10s, 1m 30s, 2h, 1d")
        return
    storage.update(lambda d: d.__setitem__("round_seconds", secs))
    await message.reply(f"✅ Длительность по умолчанию: <b>{format_duration(secs)}</b>")


# ---------- /stats ----------
@router.message(Command(commands=["stats"]))
async def cmd_stats(message: Message):
    if not await _guard(message):
        return
    data = storage.get()
    wins = data.get("wins", {})
    if not wins:
        await message.answer("Побед пока нет.")
        return
    top = sorted(wins.values(), key=lambda x: x.get("count", 0), reverse=True)[:20]
    lines = ["🏆 <b>Топ победителей:</b>"]
    for i, w in enumerate(top, 1):
        lines.append(f"{i}. {w['username']} — <b>{w['count']}</b>")
    last = data.get("last_winner")
    if last:
        lines.append(
            f"\n<b>Последняя победа:</b> {last['username']} — "
            f"{escape(last.get('prize') or '—')} ({last.get('mode') or '—'})"
        )
    await message.answer("\n".join(lines))


# ---------- /stop, /reset ----------
@router.message(Command(commands=["stop", "reset"]))
async def cmd_stop(message: Message):
    if not await _guard(message):
        return
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await message.reply("Команда работает в групповом чате.")
        return
    parts = (message.text or "").split(maxsplit=1)
    arg = parts[1].strip().lower() if len(parts) > 1 else ""
    cid = message.chat.id

    if not arg:
        drop_all_games(cid)
        await message.answer("⏹ <b>Все активные игры остановлены.</b>")
        return

    mapping = {
        "perebiv": lambda: drop_state(cid),
        "kazik": lambda: drop_dice_state(cid),
        "kubik": lambda: drop_dice_state(cid),
        "viktorina": lambda: drop_quiz_state(cid),
        "quiz": lambda: drop_quiz_state(cid),
        "number": lambda: drop_number(cid),
        "medved": lambda: drop_roulette(cid, "medved"),
        "nft": lambda: drop_roulette(cid, "nft"),
        "goal": lambda: drop_goal(cid),
        "цель": lambda: drop_goal(cid),
        "lottery": lambda: drop_lottery(cid),
        "лотерея": lambda: drop_lottery(cid),
    }
    # randommedved
    try:
        from handlers.randommedved import drop_rm
        for _k in ("randommedved", "rmedved", "rm"):
            mapping[_k] = lambda _f=drop_rm: _f(cid)
    except Exception:
        pass
    # Спорт-игры
    from handlers.sports import drop_sport
    for _sk in ("basketball", "basket", "баскет", "football", "soccer", "футбол", "bowling", "боулинг", "darts", "дартс"):
        mapping[_sk] = lambda _k=_sk: drop_sport(cid)
    fn = mapping.get(arg)
    if not fn:
        await message.reply(
            "Неизвестный тип. Доступно: perebiv, kazik, kubik, viktorina, medved, nft, number, goal, lottery, basketball, football, bowling, darts"
        )
        return
    fn()
    await message.answer(f"⏹ Игра <b>{arg}</b> остановлена.")


# ---------- /say ----------
@router.message(Command(commands=["say"]))
async def cmd_say(message: Message, bot: Bot):
    if not await _guard(message):
        return
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await message.answer("В чате: <code>/say текст</code>. В ЛС: <code>/say -100123 текст</code>")
        return
    rest = parts[1]
    if message.chat.type == ChatType.PRIVATE:
        bits = rest.split(maxsplit=1)
        if len(bits) < 2:
            await message.answer("В ЛС: <code>/say -100123456 текст</code>")
            return
        try:
            cid = int(bits[0])
        except ValueError:
            await message.answer("Первый аргумент — chat_id.")
            return
        await bot.send_message(cid, bits[1])
        await message.answer("Отправлено.")
    else:
        await bot.send_message(message.chat.id, rest)
        try:
            await message.delete()
        except Exception:
            pass


# ---------- /delete N|all ----------
@router.message(Command(commands=["delete", "del", "clear"]))
async def cmd_delete(message: Message, bot: Bot):
    if not await _guard(message):
        return
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await message.reply("Команда работает в групповом чате.")
        return

    parts = (message.text or "").split(maxsplit=1)
    arg = parts[1].strip().lower() if len(parts) > 1 else "1"

    cid = message.chat.id
    last_id = message.message_id
    # сначала пробуем удалить саму команду
    try:
        await bot.delete_message(cid, last_id)
    except Exception:
        pass

    if arg == "all":
        count_target = 1000  # «все, что бот видел» — практически большой лимит
    else:
        try:
            count_target = int(arg)
        except ValueError:
            await message.answer(
                "Использование: <code>/delete 50</code> или <code>/delete all</code>"
            )
            return
        count_target = max(1, min(count_target, 1000))

    deleted = 0
    mid = last_id - 1
    misses = 0
    while deleted < count_target and mid > 0 and misses < 50:
        try:
            await bot.delete_message(cid, mid)
            deleted += 1
            misses = 0
        except Exception:
            misses += 1
        mid -= 1

    try:
        info = await bot.send_message(cid, f"🧹 Удалено сообщений: <b>{deleted}</b>")
        # это сообщение само исчезнет через 5 секунд
        import asyncio
        async def _gone():
            await asyncio.sleep(5)
            try:
                await bot.delete_message(cid, info.message_id)
            except Exception:
                pass
        asyncio.create_task(_gone())
    except Exception:
        pass


# ---------- модерация ----------
@router.message(Command(commands=["mute", "unmute", "ban", "unban"]))
async def cmd_mod(message: Message, bot: Bot):
    if not await _guard(message):
        return
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await message.reply("Команда только в чате.")
        return
    if not message.reply_to_message:
        await message.reply("Сделай reply на сообщение пользователя.")
        return
    target = message.reply_to_message.from_user.id
    cmd = message.text.split()[0].lstrip("/").split("@")[0]
    try:
        if cmd == "mute":
            await bot.restrict_chat_member(
                message.chat.id, target,
                permissions=ChatPermissions(can_send_messages=False),
            )
            await message.answer("🔇 Замьючен.")
        elif cmd == "unmute":
            await bot.restrict_chat_member(
                message.chat.id, target,
                permissions=ChatPermissions(
                    can_send_messages=True, can_send_audios=True, can_send_documents=True,
                    can_send_photos=True, can_send_videos=True, can_send_video_notes=True,
                    can_send_voice_notes=True, can_send_polls=True,
                    can_send_other_messages=True, can_add_web_page_previews=True,
                ),
            )
            await message.answer("🔊 Размьючен.")
        elif cmd == "ban":
            await bot.ban_chat_member(message.chat.id, target)
            await message.answer("🚫 Забанен.")
        elif cmd == "unban":
            await bot.unban_chat_member(message.chat.id, target)
            await message.answer("✅ Разбанен.")
    except Exception as e:
        await message.reply(f"Ошибка: {e}")


# ============================================================
# /ignore и /unignore — исключение из ивентов
# ============================================================
def _resolve_target(message: Message) -> tuple[int | None, str | None, str | None]:
    """
    Возвращает (uid, label, error). label — то, как показать пользователя.
    Может быть указан reply, @ник или числовой id (последним аргументом).
    """
    # reply имеет приоритет
    if message.reply_to_message and message.reply_to_message.from_user:
        u = message.reply_to_message.from_user
        label = "@" + u.username if u.username else (u.full_name or str(u.id))
        return u.id, label, None
    parts = (message.text or "").split()
    # ищем @ник или цифровой id среди аргументов
    for arg in parts[1:]:
        if arg.startswith("@"):
            uid = resolve_username(arg)
            if uid:
                return uid, arg, None
            return None, None, (
                f"Не вижу пользователя {arg}. Пусть он хотя бы раз напишет в чат, "
                "или сделай reply на его сообщение."
            )
        if arg.isdigit():
            return int(arg), arg, None
    return None, None, None


def _parse_event_arg(message: Message) -> str | None:
    """Извлекает тип ивента из аргументов (если указан)."""
    parts = (message.text or "").split()
    for arg in parts[1:]:
        low = arg.lower()
        if low in EVENT_TYPES:
            return low
    return None


@router.message(Command(commands=["ignore"]))
async def cmd_ignore(message: Message, bot: Bot):
    if not await _guard(message):
        return
    # Спецкоманда: /ignore admins — заигнорить всех админов чата
    parts = (message.text or "").split()
    if len(parts) >= 2 and parts[1].lower() in {"admins", "админы", "админов"}:
        if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
            await message.reply("Команда работает только в чате.")
            return
        added, labels = await ignore_chat_admins(bot, message.chat.id)
        if not labels:
            await message.reply("Не удалось получить список админов чата.")
            return
        head = f"🚫 Заигнорено админов чата: <b>{added}</b> новых (всего {len(labels)})\n"
        await message.reply(head + "\n".join(f"• {l}" for l in labels[:30]))
        return
    uid, label, err = _resolve_target(message)
    event = _parse_event_arg(message)
    if err:
        await message.reply(err)
        return
    if uid is None:
        # v24: интерактивное меню — список ивентов + список заигноренных
        await _show_ignore_menu(message)
        return
    if event:
        ignore_event(event, uid)
        await message.reply(f"🚫 <b>{label}</b> заигнорен в ивенте <b>{event}</b>.")
    else:
        ignore_global(uid)
        await message.reply(f"🚫 <b>{label}</b> заигнорен во <b>всех ивентах</b>.")


@router.message(Command(commands=["unignore"]))
async def cmd_unignore(message: Message, bot: Bot):
    if not await _guard(message):
        return
    # v24: /unignore admins — снять игнор со всех админов чата
    parts = (message.text or "").split()
    if len(parts) >= 2 and parts[1].lower() in {"admins", "админы", "админов"}:
        if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
            await message.reply("Команда работает только в чате.")
            return
        removed, labels = await unignore_chat_admins(bot, message.chat.id)
        if not labels:
            await message.reply("Не удалось получить список админов чата.")
            return
        head = f"✅ Снят игнор у <b>{len(labels)}</b> админов чата (записей удалено: {removed}).\n"
        await message.reply(head + "\n".join(f"• {l}" for l in labels[:30]))
        return
    uid, label, err = _resolve_target(message)
    event = _parse_event_arg(message)
    if err:
        await message.reply(err)
        return
    if uid is None:
        await message.reply(
            "<b>Использование:</b>\n"
            "• <code>/unignore @ник</code> — снять глобальный игнор\n"
            "• <code>/unignore @ник &lt;ивент&gt;</code> — снять только для этого ивента\n"
            "• <code>/unignore admins</code> — снять игнор со всех админов чата\n"
            "• Reply на сообщение тоже работает"
        )
        return
    if event:
        ok = unignore_event(event, uid)
        await message.reply(
            f"✅ <b>{label}</b> снят из игнора в <b>{event}</b>." if ok
            else f"ℹ️ <b>{label}</b> не был в игноре <b>{event}</b>."
        )
    else:
        ok = unignore_global(uid)
        await message.reply(
            f"✅ <b>{label}</b> снят из <b>глобального</b> игнора." if ok
            else f"ℹ️ <b>{label}</b> не был в глобальном игноре."
        )


@router.message(Command(commands=["ignored", "ignorelist"]))
async def cmd_ignored(message: Message):
    if not await _guard(message):
        return
    data = storage.get()
    glob = data.get("ignored_global", [])
    per = data.get("ignored_event", {})
    lines = ["🚫 <b>Игнор-лист:</b>"]
    if glob:
        lines.append("\n<b>Глобально:</b>")
        for uid in glob:
            lines.append(f"• <code>{uid}</code>")
    else:
        lines.append("\n<b>Глобально:</b> пусто")
    has_event = False
    for ev, lst in per.items():
        if not lst:
            continue
        has_event = True
        lines.append(f"\n<b>{ev}:</b>")
        for uid in lst:
            lines.append(f"• <code>{uid}</code>")
    if not has_event:
        lines.append("\n<b>По ивентам:</b> пусто")
    lines.append(
        "\n<i>Админы автоматически игнорируются во всех ивентах — их в списке нет.</i>"
    )
    await message.answer("\n".join(lines))


# ============================================================
# /status — список активных ивентов в чате
# ============================================================
@router.message(Command(commands=["status", "active"]))
async def cmd_status(message: Message):
    if not await _guard(message):
        return
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await message.reply("Команда работает в групповом чате.")
        return
    cid = message.chat.id

    found = []  # (label, kind, deadline_str)

    s = get_state(cid)
    if s and s.running:
        found.append(("🎮 Перебив", "perebiv",
                      s.deadline_msk_str() if s.deadline else "до /stop"))
    d = get_dice_state(cid)
    if d and d.running:
        kind = d.game_type  # kubik / kazik
        title = "🎲 Кубик" if kind == "kubik" else "🎰 Казино"
        found.append((title, kind,
                      d.deadline_msk_str() if d.deadline else "до /stop"))
    q = get_quiz_state(cid)
    if q and q.running:
        found.append(("🧠 Викторина", "viktorina", f"{q.current_index}/{q.total_questions}"))
    n = get_number(cid)
    if n and n.running:
        found.append(("🔢 Угадай число", "number",
                      n.deadline_msk_str() if n.deadline else "до /stop"))
    g = get_goal(cid)
    if g and g.running:
        found.append((f"🎯 Цель ({g.current}/{g.target})", "goal",
                      g.deadline_msk_str() if g.deadline else "до /stop"))
    lot = get_lottery(cid)
    if lot and lot.running:
        found.append((f"🎟 Лотерея ({lot.total_tickets} билетов)", "lottery",
                      lot.deadline_msk_str() if lot.deadline else "—"))
    for kind, st in get_all_roulettes(cid).items():
        title = "🐻 Медведь" if kind == "medved" else "💎 NFT"
        found.append((title, kind,
                      st.deadline_msk_str() if st.deadline else "до /stop"))
    try:
        from handlers.sports import get_all_sport_states, SPORTS
        for cid2, st in get_all_sport_states().items():
            if cid2 == cid and st.running:
                cfg = SPORTS.get(st.kind, {})
                title = f"{cfg.get('emoji', '')} {cfg.get('title', st.kind)}".strip()
                found.append((title, st.kind, st.deadline_msk_str() if st.deadline else "до /stop"))
    except Exception:
        pass
    # v42: /randommedved
    try:
        from handlers.randommedved import get_rm
        rm = get_rm(cid)
        if rm and rm.running:
            label = f"🎁 Случайные мишки (осталось {rm.prizes_left}/{rm.prizes_total})"
            found.append((label, "randommedved",
                          rm.deadline_msk_str() if rm.deadline else "до /stop"))
    except Exception:
        pass

    if not found:
        await message.answer("📭 В этом чате нет активных ивентов.")
        return

    lines = [f"📊 <b>Активные ивенты в чате:</b>\n"]
    rows = []
    for label, kind, deadline in found:
        lines.append(f"• {label} — финиш: <b>{deadline}</b>")
        rows.append([InlineKeyboardButton(text=f"⛔ Остановить «{label}»",
                                          callback_data=f"stop:{kind}")])
    rows.append([InlineKeyboardButton(text="⛔⛔ Остановить ВСЕ", callback_data="stop:all")])
    kb = InlineKeyboardMarkup(inline_keyboard=rows)
    await message.answer("\n".join(lines), reply_markup=kb)


# ============================================================
# Callback "stop:<kind>" — кнопка под сообщениями ивентов
# ============================================================
@router.callback_query(F.data.startswith("stop:"))
async def cb_stop(cb: CallbackQuery):
    if not cb.from_user or not is_admin(cb.from_user.id):
        await cb.answer("🚫 Только для админов.", show_alert=True)
        return
    if not cb.message or cb.message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await cb.answer("Только в чате.", show_alert=True)
        return
    cid = cb.message.chat.id
    arg = cb.data.split(":", 1)[1]

    if arg == "all":
        drop_all_games(cid)
        await cb.message.answer("⏹ <b>Все игры остановлены.</b>")
        await cb.answer("Остановлено.")
        return

    mapping = {
        "perebiv": lambda: drop_state(cid),
        "kazik": lambda: drop_dice_state(cid),
        "kubik": lambda: drop_dice_state(cid),
        "viktorina": lambda: drop_quiz_state(cid),
        "number": lambda: drop_number(cid),
        "medved": lambda: drop_roulette(cid, "medved"),
        "nft": lambda: drop_roulette(cid, "nft"),
        "goal": lambda: drop_goal(cid),
        "lottery": lambda: drop_lottery(cid),
    }
    try:
        from handlers.randommedved import drop_rm
        mapping["randommedved"] = lambda: drop_rm(cid)
    except Exception:
        pass
    from handlers.sports import drop_sport
    for _sk in ("basketball", "football", "bowling", "darts"):
        mapping[_sk] = lambda _k=_sk: drop_sport(cid)
    fn = mapping.get(arg)
    if not fn:
        await cb.answer("Неизвестная игра.", show_alert=True)
        return
    fn()
    await cb.message.answer(f"⏹ Игра <b>{arg}</b> остановлена.")
    await cb.answer("Остановлено.")


# ============================================================
# v24: Интерактивное меню /ignore
# ============================================================
def _ignore_menu_text(chat_id: int) -> str:
    data = storage.get()
    glob = data.get("ignored_global", [])
    per = data.get("ignored_event", {})
    lines = ["🚫 <b>Меню игнора</b>\n"]
    lines.append(f"🌐 Глобально: <b>{len(glob)}</b>")
    if per:
        for ev, lst in per.items():
            if lst:
                lines.append(f"   • <code>{ev}</code>: {len(lst)}")
    lines.append("")
    lines.append("<b>Как пользоваться:</b>")
    lines.append("• Сделай <i>reply</i> на сообщение игрока и нажми ивент ниже")
    lines.append("• Или используй <code>/ignore @ник [ивент]</code>")
    lines.append("• <code>/ignore admins</code> — заигнорить всех админов")
    lines.append("• <code>/unignore admins</code> — снять со всех админов")
    return "\n".join(lines)


def _ignore_menu_kb() -> InlineKeyboardMarkup:
    rows = []
    events = sorted(EVENT_TYPES)
    # по 2 в ряд
    for i in range(0, len(events), 2):
        row = []
        for ev in events[i:i+2]:
            row.append(InlineKeyboardButton(text=f"🎮 {ev}", callback_data=f"ignmenu:show:{ev}"))
        rows.append(row)
    rows.append([
        InlineKeyboardButton(text="🌐 Все глобально", callback_data="ignmenu:show:_global"),
        InlineKeyboardButton(text="🔄 Обновить", callback_data="ignmenu:refresh"),
    ])
    rows.append([
        InlineKeyboardButton(text="🧹 Очистить ВЕСЬ игнор", callback_data="ignmenu:clearall"),
    ])
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def _show_ignore_menu(message: Message) -> None:
    # Если это reply — добавим кнопки "заигнорить этого юзера в N"
    if message.reply_to_message and message.reply_to_message.from_user and not message.reply_to_message.from_user.is_bot:
        target = message.reply_to_message.from_user
        rows = []
        events = sorted(EVENT_TYPES)
        for i in range(0, len(events), 2):
            row = []
            for ev in events[i:i+2]:
                row.append(InlineKeyboardButton(text=f"🚫 {ev}", callback_data=f"ignuser:{target.id}:{ev}"))
            rows.append(row)
        rows.append([InlineKeyboardButton(text="🚫 Все ивенты (глобально)", callback_data=f"ignuser:{target.id}:_global")])
        rows.append([InlineKeyboardButton(text="✅ Снять глобальный игнор", callback_data=f"unignuser:{target.id}:_global")])
        label = "@" + target.username if target.username else escape(target.full_name or str(target.id))
        await message.reply(
            f"🚫 <b>Игнор для {label}</b>\nВыбери действие:",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
        )
        return
    await message.reply(_ignore_menu_text(message.chat.id), reply_markup=_ignore_menu_kb())


@router.callback_query(F.data.startswith("ignmenu:"))
async def cb_ignmenu(cq: CallbackQuery):
    if not is_admin(cq.from_user.id):
        await cq.answer("Только для админов", show_alert=True)
        return
    parts = (cq.data or "").split(":")
    action = parts[1] if len(parts) > 1 else ""
    if action == "refresh":
        try:
            await cq.message.edit_text(_ignore_menu_text(cq.message.chat.id), reply_markup=_ignore_menu_kb())
        except Exception:
            pass
        await cq.answer("Обновлено")
        return
    if action == "show":
        ev = parts[2] if len(parts) > 2 else "_global"
        data = storage.get()
        if ev == "_global":
            ids = data.get("ignored_global", [])
            title = "🌐 Глобальный игнор"
        else:
            ids = data.get("ignored_event", {}).get(ev, [])
            title = f"🎮 Игнор в <b>{ev}</b>"
        if not ids:
            text = f"{title}\n\n<i>Список пуст.</i>"
            kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="◀️ Назад", callback_data="ignmenu:refresh")]])
        else:
            rows = []
            unames = data.get("user_index", {})
            id_to_name = {v: k for k, v in unames.items()}
            lines = [title, ""]
            for uid in ids[:30]:
                lbl = "@" + id_to_name[uid] if uid in id_to_name else f"id{uid}"
                lines.append(f"• {lbl}")
                rows.append([InlineKeyboardButton(text=f"✅ Снять {lbl}", callback_data=f"unignuser:{uid}:{ev}")])
            rows.append([InlineKeyboardButton(text="◀️ Назад", callback_data="ignmenu:refresh")])
            text = "\n".join(lines)
            kb = InlineKeyboardMarkup(inline_keyboard=rows)
        try:
            await cq.message.edit_text(text, reply_markup=kb)
        except Exception:
            pass
        await cq.answer()
        return
    if action == "clearall":
        def upd(d: dict) -> None:
            d["ignored_global"] = []
            d["ignored_event"] = {}
        storage.update(upd)
        try:
            await cq.message.edit_text(_ignore_menu_text(cq.message.chat.id), reply_markup=_ignore_menu_kb())
        except Exception:
            pass
        await cq.answer("Игнор полностью очищен", show_alert=True)
        return


@router.callback_query(F.data.startswith("ignuser:"))
async def cb_ignuser(cq: CallbackQuery):
    if not is_admin(cq.from_user.id):
        await cq.answer("Только для админов", show_alert=True)
        return
    _, uid_s, ev = (cq.data or "").split(":")
    uid = int(uid_s)
    if ev == "_global":
        ignore_global(uid)
        await cq.answer("Заигнорен глобально", show_alert=True)
    else:
        ignore_event(ev, uid)
        await cq.answer(f"Заигнорен в {ev}", show_alert=True)


@router.callback_query(F.data.startswith("unignuser:"))
async def cb_unignuser(cq: CallbackQuery):
    if not is_admin(cq.from_user.id):
        await cq.answer("Только для админов", show_alert=True)
        return
    _, uid_s, ev = (cq.data or "").split(":")
    uid = int(uid_s)
    if ev == "_global":
        ok = unignore_global(uid)
        await cq.answer("Снят глобальный игнор" if ok else "Не был в игноре", show_alert=True)
    else:
        ok = unignore_event(ev, uid)
        await cq.answer(f"Снят в {ev}" if ok else f"Не был в игноре {ev}", show_alert=True)



# ============================================================
# v27: /secret — в чате тогл скрытого шанса для chance-ивентов.
# Бот удаляет сообщение и шлёт подтверждение в ЛС всем авторизованным.
# ============================================================
@router.message(Command(commands=["secret"]))
async def cmd_secret_chat(message: Message, bot: Bot):
    # Только в группах. В ЛС обработает private.cmd_secret_dm.
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        return
    if not is_admin(message.from_user.id):
        try:
            await message.delete()
        except Exception:
            pass
        return

    parts = (message.text or "").split()
    # /secret                    — тогл всех (вкл с 0.1)
    # /secret 0.01               — тогл всех с указанным шансом
    # /secret nft                — тогл только nft (вкл с 0.1)
    # /secret nft 0.01           — выставить только nft
    # v32: /secret ez            — глобальный форс 0% (никто не выбьет)
    # v32: /secret ez off        — выключить форс
    if len(parts) >= 2 and parts[1].lower().lstrip("/") == "ez":
        sub = parts[2].lower() if len(parts) >= 3 else ""
        turn_on = sub != "off"
        secret_mode.set_force_zero(turn_on)
        try:
            await message.delete()
        except Exception:
            pass
        chat_title = escape(message.chat.title or str(message.chat.id))
        if turn_on:
            text = (
                f"🔒 <b>EZ-режим включён</b> (из чата: {chat_title})\n"
                f"Реальный шанс <b>0%</b> для всех ивентов — никто не выбьет.\n"
                f"В чате отображается заявленный шанс.\n\n"
                f"Выключить: <code>/secret ez off</code>"
            )
        else:
            text = (
                f"🔓 <b>EZ-режим выключен</b> (из чата: {chat_title})\n"
                f"Шанс вернулся к настроенному (глобальный /secret &lt;ивент&gt; → чатовый → заявленный)."
            )
        from utils import storage as _storage
        for admin_id in _storage.get().get("admins", []):
            try:
                await bot.send_message(admin_id, text)
            except Exception:
                pass
        return

    # v42: /secret lottery <username> [off] — принудительный победитель лотереи в этом чате
    if len(parts) >= 2 and parts[1].lower().lstrip("/") == "lottery":
        try:
            await message.delete()
        except Exception:
            pass
        sub = parts[2] if len(parts) >= 3 else ""
        chat_title = escape(message.chat.title or str(message.chat.id))
        if not sub or sub.lower() == "off":
            secret_mode.set_lottery_force(message.chat.id, None)
            text = f"🔓 <b>Принудительный победитель лотереи отключён</b> (чат: {chat_title})"
        else:
            uname = sub.strip().lstrip("@")
            secret_mode.set_lottery_force(message.chat.id, uname)
            text = (
                f"🔒 <b>Секретный победитель лотереи установлен</b> (чат: {chat_title})\n"
                f"При завершении лотереи победителем станет: <b>@{escape(uname)}</b>\n"
                f"Сбросить: <code>/secret lottery off</code>"
            )
        for admin_id in storage.get().get("admins", []):
            try:
                await bot.send_message(admin_id, text)
            except Exception:
                pass
        return

    target_event: str | None = None
    value: float = 0.1
    value_explicit = False

    extra = parts[1:]
    # первый токен может быть ивентом или числом
    if extra:
        first = extra[0].lower().lstrip("/")
        if first in secret_mode.SUPPORTED:
            target_event = first
            extra = extra[1:]
        else:
            # пробуем число
            try:
                value = float(first.replace(",", "."))
                value_explicit = True
                extra = extra[1:]
            except ValueError:
                # неизвестный токен — игнор
                extra = extra[1:]
    if extra:
        try:
            value = float(extra[0].replace(",", "."))
            value_explicit = True
        except ValueError:
            pass

    if not (0 <= value <= 100):
        value = 0.1

    # Применяем
    if target_event:
        # Тогл по одному ивенту в этом чате
        cur = secret_mode.get_chat(message.chat.id, target_event)
        if cur is None or value_explicit:
            secret_mode.set_chat(message.chat.id, target_event, value)
            on = True
        else:
            secret_mode.set_chat(message.chat.id, target_event, None)
            on = False
        snapshot = {target_event: secret_mode.get_chat(message.chat.id, target_event)}
        ev_list = [target_event]
    else:
        # Тогл сразу всех
        on, snapshot = secret_mode.toggle_chat_all(message.chat.id, value=value)
        ev_list = list(secret_mode.SUPPORTED)

    # Удаляем команду из чата
    try:
        await message.delete()
    except Exception:
        pass

    # Шлём подтверждение всем авторизованным админам в ЛС
    chat_title = escape(message.chat.title or str(message.chat.id))
    if on:
        def _odds(p):
            try:
                p = float(p)
                if p > 0:
                    n = int(round(100.0 / p))
                    return f" (≈ 1 из {n} сообщений)"
            except Exception:
                pass
            return ""
        ev_lines = "\n".join(
            f"   • /{ev} → <b>{snapshot.get(ev)}%</b>{_odds(snapshot.get(ev))}"
            for ev in ev_list
        )
        text = (
            f"🔒 <b>Секрет включён в чате:</b> {chat_title}\n"
            f"{ev_lines}\n\n"
            f"В чате отображается заявленный шанс.\n"
            f"<i>Напоминание: шанс — в процентах. 0.1 = 0.1%, не 10%.</i>"
        )
    else:
        evs = ", ".join(f"/{e}" for e in ev_list)
        text = (
            f"🔓 <b>Секрет выключен в чате:</b> {chat_title}\n"
            f"Шанс восстановлен на заявленный ({evs})."
        )

    for uid in storage.get().get("admins", []):
        try:
            await bot.send_message(uid, text)
        except Exception:
            pass
