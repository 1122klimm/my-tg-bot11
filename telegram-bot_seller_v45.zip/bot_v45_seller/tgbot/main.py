"""Telegram-бот. Запуск: python main.py"""
import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import BotCommand, BotCommandScopeAllPrivateChats, BotCommandScopeAllGroupChats

from config import BOT_TOKEN
from handlers import private, admin, games, roulette, perebiv, goal, lottery, edit_event, sports, randommedved, owner_settings, registry_report

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
log = logging.getLogger("bot")


async def main():
    bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()

    # v21 — порядок РОУТЕРОВ ВАЖЕН:
    # 1) ЛС
    # 2) Админ-команды (/site, /help, /stop, /edit и т.д.)
    # 3) edit_event — должен быть РАНЬШЕ catch-all'ов перебива/гола
    # 5) Игровые команды (кубик, казик, викторина)
    # 6) Спорт-игры (баскет/футбол/боулинг/дартс) — обработка dice
    # 7) Рулетки + угадай число
    # 8) Цель / Лотерея — у них catch-all сообщений в чате
    # 9) Перебив (общий перехватчик сообщений в чате) — последний
    dp.include_router(owner_settings.router)
    dp.include_router(private.router)
    dp.include_router(admin.router)
    dp.include_router(registry_report.router)
    dp.include_router(edit_event.router)
    dp.include_router(games.router)
    dp.include_router(sports.router)
    dp.include_router(roulette.router)
    dp.include_router(randommedved.router)
    dp.include_router(goal.router)
    dp.include_router(lottery.router)
    dp.include_router(perebiv.router)

    GROUP_COMMANDS = [
        BotCommand(command="startgame_perebiv", description="🎮 Перебив"),
        BotCommand(command="startgame_kazik", description="🎰 Казино"),
        BotCommand(command="startgame_kubik", description="🎲 Кубик"),
        BotCommand(command="basketball", description="🏀 Баскетбол"),
        BotCommand(command="football", description="⚽ Футбол"),
        BotCommand(command="bowling", description="🎳 Боулинг"),
        BotCommand(command="darts", description="🎯 Дартс"),
        BotCommand(command="startviktorina", description="🧠 Викторина"),
        BotCommand(command="medved", description="🐻 Ивент: выбей медведя"),
        BotCommand(command="randommedved", description="🎁 Случайные мишки активным"),
        BotCommand(command="nft", description="💎 Ивент: выбей NFT"),
        BotCommand(command="number", description="🔢 Угадай число"),
        BotCommand(command="goal", description="🎯 Цель сообщениями"),
        BotCommand(command="lottery", description="🎟 Лотерея с билетами"),
        BotCommand(command="status", description="📊 Активные ивенты"),
        BotCommand(command="stop", description="⏹ Остановить игру"),
        BotCommand(command="edit", description="✏️ Редактировать активный ивент"),
        BotCommand(command="delete", description="🧹 Удалить сообщения"),
        BotCommand(command="setprize", description="Приз по умолчанию"),
        BotCommand(command="settime", description="Время по умолчанию"),
        BotCommand(command="say", description="Сообщение от бота"),
        BotCommand(command="stats", description="Статистика побед"),
        BotCommand(command="site", description="🌐 Сайт live-статистики"),
        BotCommand(command="mute", description="Мут (reply)"),
        BotCommand(command="unmute", description="Размут (reply)"),
        BotCommand(command="ban", description="Бан (reply)"),
        BotCommand(command="unban", description="Разбан (reply)"),
        BotCommand(command="ignore", description="🚫 Игнор пользователя в ивенте"),
        BotCommand(command="unignore", description="✅ Снять игнор"),
        BotCommand(command="ignored", description="📋 Список игнора"),
        BotCommand(command="giveaccess", description="Выдать доступ"),
        BotCommand(command="revoke", description="Забрать доступ"),
        BotCommand(command="admins", description="Список админов"),
        BotCommand(command="help", description="📖 Все команды и примеры"),
    ]
    PRIVATE_COMMANDS = [
        BotCommand(command="help", description="📖 Все команды и примеры"),
        BotCommand(command="notifications", description="🔔 Уведомления о победах"),
        BotCommand(command="site", description="🌐 Сайт live-статистики"),
        BotCommand(command="setpassword", description="🔑 Сменить пароль панели"),
        BotCommand(command="password", description="🔑 Показать пароль"),
        BotCommand(command="images", description="🖼 Список картинок ивентов"),
        BotCommand(command="setimage", description="📷 Заменить картинку ивента"),
        BotCommand(command="resetimage", description="↩️ Вернуть оригинал картинки"),
    ]

    await bot.delete_my_commands()
    await bot.set_my_commands(GROUP_COMMANDS, scope=BotCommandScopeAllGroupChats())
    await bot.set_my_commands(PRIVATE_COMMANDS, scope=BotCommandScopeAllPrivateChats())

    me = await bot.get_me()
    log.info("Bot started: @%s", me.username)
    await bot.delete_webhook(drop_pending_updates=True)
    await registry_report.announce_startup(bot)
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


if __name__ == "__main__":
    asyncio.run(main())
