"""Парсинг длительности вида '10s', '10m', '1h', '1d', '1m 10s', '2h 30m 5s'."""
import re

UNITS = {"s": 1, "m": 60, "h": 3600, "d": 86400}
_PART_RE = re.compile(r"(\d+)\s*([smhd])", re.IGNORECASE)


def parse_duration(text: str) -> int | None:
    """Возвращает количество секунд или None, если строку нельзя распарсить."""
    if not text:
        return None
    text = text.strip().lower().replace(",", " ")
    parts = _PART_RE.findall(text)
    if not parts:
        # Допускаем чистое число — секунды
        if text.isdigit():
            return int(text)
        return None
    # Проверяем, что ничего лишнего нет
    cleaned = _PART_RE.sub(" ", text).strip()
    if cleaned:
        return None
    total = 0
    for value, unit in parts:
        total += int(value) * UNITS[unit]
    return total if total > 0 else None


def format_duration(seconds: int) -> str:
    if seconds <= 0:
        return "0с"
    d, r = divmod(seconds, 86400)
    h, r = divmod(r, 3600)
    m, s = divmod(r, 60)
    out = []
    if d: out.append(f"{d}д")
    if h: out.append(f"{h}ч")
    if m: out.append(f"{m}м")
    if s: out.append(f"{s}с")
    return " ".join(out)
