"""v27: пересчёт ⭐ ↔ TON через CoinGecko + фиксированную цену звезды.

Логика:
  • Цена 1 ⭐ ≈ $0.013 USD (Telegram Stars Fragment retail).
  • Курс TON/USD берём из CoinGecko (без ключа), кэш 10 минут.
  • Если CoinGecko недоступен — fallback к последнему успешному курсу.

Используется только для отображения в отчётах. Реальные траты считаются
в звёздах по факту message.paid_star_count (см. perebiv.py).
"""
from __future__ import annotations
import logging
import time
from typing import Optional

import aiohttp

log = logging.getLogger("ton_rate")

# Цена 1 звезды в USD (Telegram Stars Fragment, retail).
STAR_USD = 0.013

# Кэш курса TON/USD
_cache: dict = {"ton_usd": None, "ts": 0.0}
_CACHE_TTL = 600  # 10 минут
# Fallback на случай длительного отказа API
_FALLBACK_TON_USD = 5.5


async def get_ton_usd() -> float:
    """Курс TON в USD. С кэшем и фолбэком."""
    now = time.time()
    if _cache["ton_usd"] and now - _cache["ts"] < _CACHE_TTL:
        return float(_cache["ton_usd"])
    try:
        url = ("https://api.coingecko.com/api/v3/simple/price"
               "?ids=the-open-network&vs_currencies=usd")
        timeout = aiohttp.ClientTimeout(total=6)
        async with aiohttp.ClientSession(timeout=timeout) as s:
            async with s.get(url) as r:
                if r.status == 200:
                    j = await r.json()
                    val = float(j.get("the-open-network", {}).get("usd") or 0)
                    if val > 0:
                        _cache["ton_usd"] = val
                        _cache["ts"] = now
                        return val
    except Exception as e:
        log.debug("coingecko fail: %s", e)
    return float(_cache["ton_usd"] or _FALLBACK_TON_USD)


async def stars_to_ton(stars: int) -> float:
    """Сколько TON стоит N звёзд."""
    if not stars:
        return 0.0
    ton_usd = await get_ton_usd()
    if ton_usd <= 0:
        return 0.0
    usd = float(stars) * STAR_USD
    return round(usd / ton_usd, 3)


async def ton_to_stars(ton: float) -> int:
    """Сколько звёзд эквивалентно N TON (для сводных отчётов)."""
    if not ton:
        return 0
    ton_usd = await get_ton_usd()
    if ton_usd <= 0:
        return 0
    usd = float(ton) * ton_usd
    return int(round(usd / STAR_USD))
