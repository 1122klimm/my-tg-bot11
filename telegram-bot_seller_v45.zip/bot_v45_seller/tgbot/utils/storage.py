"""Простое JSON-хранилище."""
import json
import os
from threading import Lock
from config import DATA_FILE

_lock = Lock()

DEFAULT = {
    "super_admin": None,        # первый, кто активировал панель — может выдавать доступ другим
    "admins": [],               # авторизованные user_id (включая супер-админа)
    "admin_usernames": {},      # {username_lower: user_id} для команды /giveaccess @ник и /ignore @ник
    "user_index": {},           # {username_lower: user_id} — кэш всех виденных юзеров (для /ignore)
    "notify_admins": [],        # user_id, которые получают уведомления о победах в ЛС
    "ignored_global": [],       # user_id — игнорируются во ВСЕХ ивентах
    "ignored_event": {},        # {event_type: [user_id, ...]} — игнор по конкретному ивенту
    "prize_url": "",
    "round_seconds": 60,
    "wins": {},
    "last_winner": None,
}

# Известные типы ивентов для /ignore <ивент>
EVENT_TYPES = {"perebiv", "kazik", "kubik", "viktorina", "medved", "nft", "number", "goal", "lottery"}


def _load() -> dict:
    if not os.path.exists(DATA_FILE):
        return _normalize(dict(DEFAULT))
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        data = dict(DEFAULT)
    return _normalize(data)


def _normalize(data: dict) -> dict:
    for k, v in DEFAULT.items():
        if k not in data:
            data[k] = v if not isinstance(v, (list, dict)) else (list(v) if isinstance(v, list) else dict(v))
    return data


def _save(data: dict) -> None:
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, DATA_FILE)


def get() -> dict:
    with _lock:
        return _load()


def update(fn) -> dict:
    with _lock:
        data = _load()
        fn(data)
        _save(data)
        return data
