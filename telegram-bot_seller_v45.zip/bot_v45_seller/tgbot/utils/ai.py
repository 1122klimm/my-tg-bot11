"""AI-клиент. v21: ходит через прокси /api/public/ai/chat на сайте,
который сам авторизуется в AI Gateway. На боте никаких api-ключей не нужно —
только AI_PROXY_URL + BOT_INGEST_TOKEN.
"""
import asyncio
import logging
from typing import Optional

import aiohttp

from config import (
    AI_PROXY_URL, BOT_INGEST_TOKEN,
    LOVABLE_API_KEY, LOVABLE_AI_MODEL,
)

log = logging.getLogger("ai")
LEGACY_GATEWAY_URL = "https://ai.gateway.lovable.dev/v1/chat/completions"


async def chat_completion(
    system: str,
    user: str,
    model: Optional[str] = None,
    max_tokens: int = 400,
    temperature: float = 0.85,
    timeout: int = 25,
) -> Optional[str]:
    """Один запрос к AI. Возвращает текст или None при ошибке."""
    payload_messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": user},
    ]

    # Путь 1: прокси на сайте (предпочтительный). Если токен не задан,
    # всё равно пробуем прямой AI Gateway ниже, а не молчим без ответа.
    if AI_PROXY_URL and BOT_INGEST_TOKEN:
        body = {
            "messages": payload_messages,
            "model": model or LOVABLE_AI_MODEL,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        headers = {"Content-Type": "application/json", "X-Bot-Token": BOT_INGEST_TOKEN}
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=timeout)) as s:
                async with s.post(AI_PROXY_URL, json=body, headers=headers) as r:
                    if r.status == 429:
                        log.warning("AI proxy rate limit")
                        return None
                    if r.status == 402:
                        log.warning("AI proxy payment required")
                        return None
                    if r.status >= 400:
                        text = await r.text()
                        log.error("AI proxy %s: %s", r.status, text[:200])
                        return None
                    data = await r.json()
                    return data.get("content")
        except asyncio.TimeoutError:
            log.warning("AI proxy timeout")
            return None
        except Exception as e:
            log.exception("AI proxy error: %s", e)
            return None

    elif AI_PROXY_URL and not BOT_INGEST_TOKEN:
        log.warning("AI proxy skipped: BOT_INGEST_TOKEN is empty")

    # Путь 2 (fallback): прямой вызов AI Gateway, если задан LOVABLE_API_KEY.
    if not LOVABLE_API_KEY:
        log.warning("AI недоступен: ни AI_PROXY_URL, ни LOVABLE_API_KEY не заданы")
        return None
    payload = {
        "model": model or LOVABLE_AI_MODEL,
        "messages": payload_messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    headers = {"Authorization": f"Bearer {LOVABLE_API_KEY}", "Content-Type": "application/json"}
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=timeout)) as s:
            async with s.post(LEGACY_GATEWAY_URL, json=payload, headers=headers) as r:
                if r.status >= 400:
                    text = await r.text()
                    log.error("AI gateway %s: %s", r.status, text[:200])
                    return None
                data = await r.json()
                return (data.get("choices") or [{}])[0].get("message", {}).get("content")
    except asyncio.TimeoutError:
        log.warning("AI timeout")
        return None
    except Exception as e:
        log.exception("AI error: %s", e)
        return None
