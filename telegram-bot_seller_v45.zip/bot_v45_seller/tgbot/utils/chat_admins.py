"""v27: кэш списка админов чата (owner+administrators), чтобы не считать
их сообщения в статистике."""
from __future__ import annotations
import time
from typing import Set

_cache: dict[int, tuple[float, Set[int]]] = {}
_TTL = 300  # 5 минут


async def get_chat_admin_ids(bot, chat_id: int) -> Set[int]:
    now = time.time()
    hit = _cache.get(chat_id)
    if hit and now - hit[0] < _TTL:
        return hit[1]
    ids: Set[int] = set()
    try:
        admins = await bot.get_chat_administrators(chat_id)
        for m in admins:
            u = getattr(m, "user", None)
            if u and not u.is_bot:
                ids.add(u.id)
    except Exception:
        # Если не получилось — отдадим пустое множество, не блокируя логику
        return _cache.get(chat_id, (0, set()))[1]
    _cache[chat_id] = (now, ids)
    return ids


async def is_chat_admin(bot, chat_id: int, user_id: int) -> bool:
    ids = await get_chat_admin_ids(bot, chat_id)
    return user_id in ids


def invalidate(chat_id: int) -> None:
    _cache.pop(chat_id, None)
