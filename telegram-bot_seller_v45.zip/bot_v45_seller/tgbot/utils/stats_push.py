"""Отправка событий бота в сайт live-статистики (Lovable). v20.

Полностью fire-and-forget: если сайт недоступен или токен пустой — молча скип.
"""
import asyncio
import logging
from typing import Optional

import aiohttp

from config import STATS_INGEST_URL, BOT_INGEST_TOKEN

log = logging.getLogger("stats")


async def _post(payload: dict) -> None:
    if not STATS_INGEST_URL or not BOT_INGEST_TOKEN:
        return
    headers = {
        "Content-Type": "application/json",
        "X-Bot-Token": BOT_INGEST_TOKEN,
    }
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=8)) as s:
            async with s.post(STATS_INGEST_URL, json=payload, headers=headers) as r:
                if r.status >= 400:
                    body = await r.text()
                    log.warning("ingest %s: %s", r.status, body[:200])
    except Exception as e:
        log.warning("ingest fail: %s", e)


def push_event(
    *,
    chat_id: int,
    chat_title: Optional[str],
    user_id: Optional[int],
    username: Optional[str],
    full_name: Optional[str],
    avatar_url: Optional[str],
    game_type: str,
    event_type: str,  # "won", "spent", "started", ...
    prize: Optional[str] = None,
    stars_value: int = 0,
    ton_value: float = 0.0,
    meta: Optional[dict] = None,
) -> None:
    """Шлёт событие в фоне — не блокирует игру."""
    payload = {
        "chat_id": chat_id,
        "chat_title": chat_title,
        "user_id": user_id,
        "username": username,
        "full_name": full_name,
        "avatar_url": avatar_url,
        "game_type": game_type,
        "event_type": event_type,
        "prize": prize,
        "stars_value": int(stars_value or 0),
        "ton_value": float(ton_value or 0),
        "meta": meta or {},
    }
    try:
        asyncio.create_task(_post(payload))
    except RuntimeError:
        # Нет работающего event loop — игнорируем
        pass


def report_start(message, game_type: str, prize: str | None = None, meta: dict | None = None) -> None:
    """Удобная обёртка: сообщает, что админ запустил ивент.
    Не накручивает балансы (stars_value=0), просто появляется в ленте событий сайта.
    """
    try:
        u = message.from_user
        push_event(
            chat_id=message.chat.id,
            chat_title=message.chat.title or message.chat.full_name,
            user_id=u.id if u else None,
            username=(u.username if u else None),
            full_name=(u.full_name if u else None),
            avatar_url=None,
            game_type=game_type,
            event_type="started",
            prize=prize,
            stars_value=0,
            ton_value=0,
            meta=meta or {},
        )
    except Exception:
        pass
