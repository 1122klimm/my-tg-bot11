"""v27: скрытый режим шанса для chance-ивентов.

Идея: админ может включить «секрет» так, что РЕАЛЬНЫЙ шанс выпадения
становится 0.1% (или другим), а в чате показывается заявленный.

Хранение: в storage["secret_chance"]:
  {
    "global": {"medved": 0.1, "nft": 0.1},   # глобально на всех чатах админа
    "chat": {"<chat_id>": {"medved": 0.1}}    # переопределение по чату (от тогла в чате)
  }

Поддерживаемые ивенты: medved, nft. В /kazik проценты не настраиваются.
"""
from __future__ import annotations
from utils import storage

# Какие ивенты поддерживают /secret
SUPPORTED = ("medved", "nft")


def _root() -> dict:
    d = storage.get()
    return d.get("secret_chance") or {}


def get_force_zero() -> bool:
    """v32: /secret ez — глобальный форс шанса в 0% (никто не выбьет)."""
    return bool(_root().get("force_zero", False))


def set_force_zero(value: bool) -> None:
    def upd(d: dict) -> None:
        root = d.setdefault("secret_chance", {})
        root["force_zero"] = bool(value)
    storage.update(upd)


# ============================================================
# v33: /secret win @user [процент] — индивидуальный «победный» шанс.
# Хранение: storage["secret_chance"]["win_users"] = {
#     "<key>": <percent_float>   # key = username в lower-case без @, либо "id<numeric>"
# }
# Этот шанс ПЕРЕБИВАЕТ EZ-режим и любые другие настройки.
# ============================================================
def _norm_user_key(user_id: int | None = None, username: str | None = None) -> list[str]:
    keys: list[str] = []
    if username:
        u = username.strip().lstrip("@").lower()
        if u:
            keys.append(u)
    if user_id:
        keys.append(f"id{user_id}")
    return keys


def get_win_users() -> dict:
    return dict(_root().get("win_users", {}) or {})


def get_win_for(user_id: int | None = None, username: str | None = None) -> float | None:
    """Возвращает индивидуальный «win-шанс» в процентах, либо None."""
    bucket = _root().get("win_users", {}) or {}
    for key in _norm_user_key(user_id, username):
        v = bucket.get(key)
        if v is not None:
            try:
                return float(v)
            except Exception:
                pass
    return None


def set_win_user(username: str, value: float | None) -> None:
    """Включить/выключить win-шанс для @username (без @). value=None — выключить."""
    key = (username or "").strip().lstrip("@").lower()
    if not key:
        return

    def upd(d: dict) -> None:
        root = d.setdefault("secret_chance", {})
        bucket = root.setdefault("win_users", {})
        if value is None:
            bucket.pop(key, None)
        else:
            bucket[key] = float(value)
    storage.update(upd)


def get_global(event: str) -> float | None:
    v = _root().get("global", {}).get(event)
    try:
        return float(v) if v is not None else None
    except Exception:
        return None


def set_global(event: str, value: float | None) -> None:
    def upd(d: dict) -> None:
        root = d.setdefault("secret_chance", {})
        g = root.setdefault("global", {})
        if value is None:
            g.pop(event, None)
        else:
            g[event] = float(value)
    storage.update(upd)


def get_chat(chat_id: int, event: str) -> float | None:
    v = _root().get("chat", {}).get(str(chat_id), {}).get(event)
    try:
        return float(v) if v is not None else None
    except Exception:
        return None


def set_chat(chat_id: int, event: str, value: float | None) -> None:
    def upd(d: dict) -> None:
        root = d.setdefault("secret_chance", {})
        per = root.setdefault("chat", {}).setdefault(str(chat_id), {})
        if value is None:
            per.pop(event, None)
        else:
            per[event] = float(value)
    storage.update(upd)


def effective_chance(
    chat_id: int,
    event: str,
    declared: float,
    user_id: int | None = None,
    username: str | None = None,
) -> float:
    """Возвращает реальный шанс с учётом /secret.

    Приоритет:
      1. /secret win @user — индивидуальный шанс конкретного юзера (бьёт всё)
      2. /secret ez       — глобальный форс 0% для всех остальных
      3. /secret в чате   — переопределение по чату
      4. /secret <ивент>  — глобально для админа
      5. declared         — заявленный в чате
    """
    # v33: персональный win-шанс перебивает всё, включая EZ-режим.
    win_v = get_win_for(user_id=user_id, username=username)
    if win_v is not None:
        return float(win_v)
    # v32: EZ — все остальные с шансом 0%.
    if get_force_zero():
        return 0.0
    v = get_chat(chat_id, event)
    if v is None:
        v = get_global(event)
    return float(v) if v is not None else float(declared)


def toggle_chat_all(chat_id: int, value: float = 0.1) -> tuple[bool, dict]:
    """Тогл в чате: если хотя бы один ивент уже с секретом — выключаем все,
    иначе включаем все поддерживаемые с этим значением.
    Возвращает (turned_on, snapshot). snapshot = текущее состояние."""
    d = storage.get()
    per = d.get("secret_chance", {}).get("chat", {}).get(str(chat_id), {})
    any_on = any(per.get(ev) is not None for ev in SUPPORTED)

    def upd(dd: dict) -> None:
        root = dd.setdefault("secret_chance", {})
        bucket = root.setdefault("chat", {}).setdefault(str(chat_id), {})
        if any_on:
            for ev in SUPPORTED:
                bucket.pop(ev, None)
        else:
            for ev in SUPPORTED:
                bucket[ev] = float(value)
    storage.update(upd)
    snapshot = (storage.get().get("secret_chance", {})
                .get("chat", {}).get(str(chat_id), {}))
    return (not any_on), snapshot


def toggle_global(event: str, value: float | None) -> tuple[bool, float | None]:
    """Тогл глобального секрета по событию.
    Если value задано — включаем (или меняем). Если value None — тогл (вкл с 0.1, выкл если уже).
    Возвращает (now_on, current_value)."""
    cur = get_global(event)
    if value is None:
        # тогл
        if cur is None:
            set_global(event, 0.1)
            return True, 0.1
        else:
            set_global(event, None)
            return False, None
    else:
        # явно задаём
        set_global(event, value)
        return True, float(value)


# ============================================================
# /secret lottery <username> — принудительный победитель лотереи в чате.
# Хранение: storage["secret_chance"]["lottery_force"] = {"<chat_id>": "<username_lower>"}
# ============================================================
def get_lottery_force(chat_id: int) -> str | None:
    bucket = _root().get("lottery_force", {}) or {}
    v = bucket.get(str(chat_id))
    return v or None


def set_lottery_force(chat_id: int, username: str | None) -> None:
    def upd(d: dict) -> None:
        root = d.setdefault("secret_chance", {})
        bucket = root.setdefault("lottery_force", {})
        if not username:
            bucket.pop(str(chat_id), None)
        else:
            bucket[str(chat_id)] = username.strip().lstrip("@").lower()
    storage.update(upd)
