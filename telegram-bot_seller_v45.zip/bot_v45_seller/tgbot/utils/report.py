"""v25: пост-игровой отчёт админам в ЛС.

Шлём только админам с включённым /notifications. Содержимое:
  • чат / тип игры / приз
  • длительность
  • участники, сообщения
  • потрачено ⭐ / TON (только если > 0)
  • победители
  • топ-3 активных
"""
from __future__ import annotations
import logging
from datetime import datetime, timezone
from html import escape
from typing import Optional

from aiogram import Bot
from utils import storage
from utils import ton_rate

log = logging.getLogger("report")


def _human_dur(secs: int) -> str:
    if secs is None:
        return "—"
    secs = max(0, int(secs))
    if secs < 60:
        return f"{secs}с"
    m, s = divmod(secs, 60)
    if m < 60:
        return f"{m}м {s}с" if s else f"{m}м"
    h, m = divmod(m, 60)
    return f"{h}ч {m}м"


async def send_post_game_report(
    bot: Bot,
    *,
    chat_id: int,
    chat_title: Optional[str] = None,
    game_type: str,
    game_label: str,
    started_at: Optional[datetime] = None,
    ended_at: Optional[datetime] = None,
    duration_planned: int = 0,
    participants: Optional[dict] = None,   # uid -> {"name": str, "messages": int, "stars": int}
    messages_total: int = 0,
    stars_spent: int = 0,
    ton_spent: float = 0.0,
    winners: Optional[list] = None,        # list[(uid, name)] или list[str]
    prize: str = "",
    extra_lines: Optional[list[str]] = None,
) -> None:
    """Формирует отчёт и шлёт в ЛС всем админам с notifications=on."""
    data = storage.get()
    notify_admins = list(data.get("notify_admins", []))
    if not notify_admins:
        return

    elapsed = 0
    if started_at:
        end = ended_at or datetime.now(timezone.utc)
        try:
            elapsed = int((end - started_at).total_seconds())
        except Exception:
            elapsed = 0
    elif duration_planned:
        elapsed = duration_planned

    lines: list[str] = []
    lines.append("📊 <b>Итоги ивента</b>")
    lines.append(f"💬 <b>Чат:</b> {escape(chat_title or str(chat_id))}")
    lines.append(f"🎮 <b>Игра:</b> {escape(game_label)}")
    if prize:
        lines.append(f"🎁 <b>Приз:</b> {escape(prize)}")
    lines.append(f"⏱ <b>Длительность:</b> {_human_dur(elapsed)}")

    # Участники / сообщения
    parts = participants or {}
    uniq = len(parts)
    if uniq or messages_total:
        msgs = messages_total or sum(int(p.get("messages", 0)) for p in parts.values())
        lines.append(f"👥 <b>Участников:</b> <b>{uniq}</b>")
        if msgs:
            lines.append(f"✉️ <b>Сообщений:</b> <b>{msgs}</b>")

    # Звёзды/TON — только если были
    if stars_spent and stars_spent > 0:
        lines.append(f"⭐ <b>Потрачено звёзд:</b> <b>{int(stars_spent)}</b>")
        # v27: эквивалент в TON через CoinGecko
        try:
            ton_eq = await ton_rate.stars_to_ton(int(stars_spent))
            if ton_eq:
                lines.append(f"   ≈ <b>{ton_eq:g}</b> TON")
        except Exception:
            pass
    # v33: строку «Потрачено TON» убрали — оставляем только TON-эквивалент звёзд.

    # Победители
    if winners:
        lines.append("")
        lines.append("🏆 <b>Победители:</b>")
        for w in winners[:10]:
            if isinstance(w, tuple):
                _uid, name = w
                lines.append(f"   • {escape(str(name))}")
            else:
                lines.append(f"   • {escape(str(w))}")

    # Топ активных — по сообщениям/звёздам
    if parts:
        # v33: фильтруем системные/анонимные имена («Telegram» и т. п.) —
        # это не реальные участники, а пересланные/анонимные сообщения.
        SYSTEM_NAMES = {"telegram", "channel", "group"}
        def _is_real(item):
            uid, info = item
            name = str(info.get("name") or "").strip().lstrip("@").lower()
            if not name:
                return False
            if name in SYSTEM_NAMES:
                return False
            # uid каналов/анонимных Telegram-сервисов: 777000, 1087968824 и т.п.
            try:
                if int(uid) in (777000, 1087968824):
                    return False
            except Exception:
                pass
            return True
        ranked = sorted(
            (kv for kv in parts.items() if _is_real(kv)),
            key=lambda kv: (
                int(kv[1].get("stars", 0)),
                int(kv[1].get("messages", 0)),
            ),
            reverse=True,
        )[:3]
        if ranked and ranked[0][1].get("messages", 0):
            lines.append("")
            lines.append("🔥 <b>Топ активных:</b>")
            for i, (uid, info) in enumerate(ranked, 1):
                name = info.get("name") or f"id{uid}"
                msgs = int(info.get("messages", 0))
                stars = int(info.get("stars", 0))
                tail = f" — {msgs} сообщ."
                if stars:
                    tail += f" / {stars}⭐"
                lines.append(f"   {i}. {escape(str(name))}{tail}")

    if extra_lines:
        lines.append("")
        lines.extend(extra_lines)

    text = "\n".join(lines)

    for uid in notify_admins:
        try:
            await bot.send_message(uid, text, disable_web_page_preview=True)
        except Exception as e:
            log.debug("post-game report send fail to %s: %s", uid, e)
