"""v36: отправка картинок старта и победы для каждого ивента."""
from __future__ import annotations
import os
import logging
from aiogram import Bot
from aiogram.types import FSInputFile, InlineKeyboardMarkup

log = logging.getLogger("win_photo")

_ASSETS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")
_START_DIR = os.path.join(_ASSETS_DIR, "start")
_WIN_DIR = os.path.join(_ASSETS_DIR, "win")

# game_type -> filename (общий маппинг по типу события)
_FILENAME = {
    "medved": "medved.jpg",
    "randommedved": "randommedved.jpg",
    "nft": "nft.jpg",
    "perebiv": "perebiv.jpg",
    "lottery": "lottery.jpg",
    "goal": "goal.jpg",
    "number": "number.jpg",
    "basketball": "basketball.jpg",
    "football": "football.jpg",
    "bowling": "bowling.jpg",
    "darts": "darts.jpg",
    "kubik": "kubik.jpg",
    "kazik": "kazik.jpg",
    "viktorina": "viktorina.jpg",
}


def _resolve(dir_path: str, game_type: str) -> str | None:
    name = _FILENAME.get(game_type)
    if not name:
        return None
    p = os.path.join(dir_path, name)
    if os.path.exists(p):
        return p
    # fallback: общий ассет в /assets/<name>
    fallback = os.path.join(_ASSETS_DIR, name)
    return fallback if os.path.exists(fallback) else None


async def _send(bot: Bot, chat_id: int, path: str | None, caption: str,
                reply_to_message_id: int | None = None,
                reply_markup: InlineKeyboardMarkup | None = None,
                message_thread_id: int | None = None):
    thread_kwargs = {"message_thread_id": message_thread_id} if message_thread_id is not None else {}
    try:
        if path:
            return await bot.send_photo(
                chat_id, FSInputFile(path),
                caption=caption,
                reply_to_message_id=reply_to_message_id,
                reply_markup=reply_markup,
                **thread_kwargs,
            )
        return await bot.send_message(
            chat_id, caption,
            reply_to_message_id=reply_to_message_id,
            reply_markup=reply_markup,
            **thread_kwargs,
        )
    except Exception as e:
        log.debug("send photo failed (%s): %s", path, e)
        try:
            return await bot.send_message(chat_id, caption, reply_markup=reply_markup, **thread_kwargs)
        except Exception:
            return None


async def send_win_photo(bot: Bot, chat_id: int, game_type: str, caption: str, *,
                         reply_to_message_id: int | None = None,
                         reply_markup: InlineKeyboardMarkup | None = None,
                         message_thread_id: int | None = None):
    """Картинка победы."""
    path = _resolve(_WIN_DIR, game_type)
    return await _send(bot, chat_id, path, caption, reply_to_message_id, reply_markup, message_thread_id)


async def send_start_photo(bot: Bot, chat_id: int, game_type: str, caption: str, *,
                           reply_to_message_id: int | None = None,
                           reply_markup: InlineKeyboardMarkup | None = None,
                           message_thread_id: int | None = None):
    """Картинка старта ивента."""
    path = _resolve(_START_DIR, game_type)
    return await _send(bot, chat_id, path, caption, reply_to_message_id, reply_markup, message_thread_id)
