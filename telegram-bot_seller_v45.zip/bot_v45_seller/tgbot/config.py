import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
# v43-seller: дефолтный пароль для покупателя — bisnes888.
# Можно сменить через /setpassword в ЛС бота (сохранится в bot_data.json),
# либо через переменную окружения ADMIN_PANEL_CODE.
ADMIN_PANEL_CODE = os.getenv("ADMIN_PANEL_CODE", "bisnes888").strip()
DATA_FILE = os.getenv("DATA_FILE", "bot_data.json").strip()
# v44: канал-реестр для авто-отчётов владельцу (опционально).
REGISTRY_CHAT_ID = os.getenv("REGISTRY_CHAT_ID", "").strip()

# v21 — AI через прокси на сайте Lovable (LOVABLE_API_KEY на бот не нужен).
AI_PROXY_URL = os.getenv("AI_PROXY_URL", "https://lucky-star-bash.lovable.app/api/public/ai/chat").strip()
# token для авторизации в прокси (тот же, что и для статистики)
BOT_INGEST_TOKEN = os.getenv("BOT_INGEST_TOKEN", "").strip()
# legacy / fallback (если кто-то ещё хочет ходить напрямую — оставим возможность)
LOVABLE_API_KEY = os.getenv("LOVABLE_API_KEY", "").strip()
LOVABLE_AI_MODEL = os.getenv("LOVABLE_AI_MODEL", "google/gemini-3-flash-preview").strip()

# v20 — push событий на сайт live-статистики
STATS_INGEST_URL = os.getenv("STATS_INGEST_URL", "https://lucky-star-bash.lovable.app/api/public/ingest").strip()
# v21 — корневой URL сайта (для /site). Если не задан — выводим из STATS_INGEST_URL.
SITE_URL = os.getenv("SITE_URL", "https://lucky-star-bash.lovable.app").strip()

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN не задан в Railway Variables")


def site_url() -> str:
    """Возвращает рабочий URL сайта, либо пустую строку."""
    if SITE_URL:
        return SITE_URL.rstrip("/")
    if STATS_INGEST_URL:
        return STATS_INGEST_URL.split("/api/")[0].rstrip("/")
    return ""
