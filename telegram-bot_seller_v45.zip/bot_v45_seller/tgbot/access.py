"""Доступы и уведомления."""
from html import escape
from datetime import datetime, timezone
from aiogram import Bot
from aiogram.types import Message
from utils import storage


def is_admin(uid: int) -> bool:
    return uid in storage.get().get("admins", [])


def is_super(uid: int) -> bool:
    return storage.get().get("super_admin") == uid


def remember_username(message: Message) -> None:
    """Сохраняем username -> user_id, чтобы /giveaccess @ник работал."""
    u = message.from_user
    if not u or not u.username:
        return
    uname = u.username.lower()
    uid = u.id

    def upd(d: dict) -> None:
        d.setdefault("admin_usernames", {})
        d["admin_usernames"][uname] = uid
        d.setdefault("user_index", {})
        d["user_index"][uname] = uid
    storage.update(upd)


def add_admin(uid: int) -> None:
    def upd(d: dict) -> None:
        if uid not in d["admins"]:
            d["admins"].append(uid)
        if d.get("super_admin") is None:
            d["super_admin"] = uid
    storage.update(upd)


def remove_admin(uid: int) -> bool:
    removed = {"flag": False}

    def upd(d: dict) -> None:
        if uid == d.get("super_admin"):
            return  # супер-админа нельзя убрать
        if uid in d["admins"]:
            d["admins"].remove(uid)
            removed["flag"] = True
        if uid in d.get("notify_admins", []):
            d["notify_admins"].remove(uid)
    storage.update(upd)
    return removed["flag"]


def set_notifications(uid: int, on: bool) -> None:
    def upd(d: dict) -> None:
        lst = d.setdefault("notify_admins", [])
        if on and uid not in lst:
            lst.append(uid)
        if not on and uid in lst:
            lst.remove(uid)
    storage.update(upd)


def notifications_on(uid: int) -> bool:
    return uid in storage.get().get("notify_admins", [])


async def notify_win(bot: Bot, chat_title: str, winner_name: str, prize: str, mode: str) -> None:
    """Шлём уведомление всем админам, у которых включён /notifications."""
    text = (
        f"🏆 <b>Победа!</b>\n"
        f"💬 <b>Чат:</b> {escape(chat_title or '—')}\n"
        f"🎮 <b>Игра:</b> {escape(mode)}\n"
        f"👤 <b>Победитель:</b> {winner_name}\n"
        f"🎁 <b>Приз:</b> {escape(prize) if prize else '<i>не задан</i>'}\n"
        f"🕒 {datetime.now(timezone.utc).astimezone().strftime('%H:%M:%S')}"
    )
    for uid in list(storage.get().get("notify_admins", [])):
        try:
            await bot.send_message(uid, text)
        except Exception:
            pass


def remember_win(user_id: int, username: str, prize: str, mode: str) -> None:
    def upd(d: dict) -> None:
        wins = d["wins"].setdefault(str(user_id), {"username": username, "count": 0})
        wins["username"] = username
        wins["count"] += 1
        d["last_winner"] = {
            "user_id": user_id,
            "username": username,
            "prize": prize,
            "mode": mode,
            "ts": datetime.now(timezone.utc).isoformat(),
        }
    storage.update(upd)


def username_of(message: Message) -> str:
    u = message.from_user
    if u and u.username:
        return "@" + u.username
    if u:
        return escape(u.full_name or str(u.id))
    return "игрок"


# ============================================================
# /ignore — пользователи, которые НЕ участвуют в ивентах
# ============================================================
def resolve_username(uname: str) -> int | None:
    """@ник -> user_id, если бот когда-либо видел этого пользователя."""
    uname = uname.lstrip("@").lower()
    data = storage.get()
    return (data.get("user_index", {}).get(uname)
            or data.get("admin_usernames", {}).get(uname))


def ignore_global(uid: int) -> None:
    def upd(d: dict) -> None:
        lst = d.setdefault("ignored_global", [])
        if uid not in lst:
            lst.append(uid)
    storage.update(upd)


def unignore_global(uid: int) -> bool:
    flag = {"v": False}
    def upd(d: dict) -> None:
        lst = d.setdefault("ignored_global", [])
        if uid in lst:
            lst.remove(uid)
            flag["v"] = True
    storage.update(upd)
    return flag["v"]


def ignore_event(event: str, uid: int) -> None:
    def upd(d: dict) -> None:
        m = d.setdefault("ignored_event", {})
        lst = m.setdefault(event, [])
        if uid not in lst:
            lst.append(uid)
    storage.update(upd)


def unignore_event(event: str, uid: int) -> bool:
    flag = {"v": False}
    def upd(d: dict) -> None:
        m = d.setdefault("ignored_event", {})
        lst = m.setdefault(event, [])
        if uid in lst:
            lst.remove(uid)
            flag["v"] = True
    storage.update(upd)
    return flag["v"]


def is_ignored(uid: int, event: str | None = None) -> bool:
    """v24: игноримся ТОЛЬКО если явно добавлены в ignored_global или ignored_event.
    Админы участвуют в ивентах как все, кроме случаев когда сам админ заигнорен."""
    data = storage.get()
    if uid in data.get("ignored_global", []):
        return True
    if event and uid in data.get("ignored_event", {}).get(event, []):
        return True
    return False


# ============================================================
# /ignore admins — игнорировать всех админов чата
# ============================================================
async def ignore_chat_admins(bot, chat_id: int) -> tuple[int, list[str]]:
    """Подтягивает всех админов чата (через getChatAdministrators) и
    добавляет их в глобальный игнор. Возвращает (кол-во добавленных, список меток)."""
    added = 0
    labels: list[str] = []
    try:
        admins = await bot.get_chat_administrators(chat_id)
    except Exception:
        return 0, []
    for member in admins:
        u = member.user
        if not u or u.is_bot:
            continue
        # запоминаем юзернейм
        if u.username:
            uname = u.username.lower()
            def upd(d, _un=uname, _uid=u.id):
                d.setdefault("admin_usernames", {})[_un] = _uid
                d.setdefault("user_index", {})[_un] = _uid
            storage.update(upd)
        before = u.id in storage.get().get("ignored_global", [])
        if not before:
            ignore_global(u.id)
            added += 1
        labels.append("@" + u.username if u.username else (u.full_name or str(u.id)))
    return added, labels


async def unignore_chat_admins(bot, chat_id: int) -> tuple[int, list[str]]:
    """v24: убирает всех админов чата из глобального игнора и из всех per-event игноров."""
    removed = 0
    labels: list[str] = []
    try:
        admins = await bot.get_chat_administrators(chat_id)
    except Exception:
        return 0, []
    admin_ids = []
    for member in admins:
        u = member.user
        if not u or u.is_bot:
            continue
        admin_ids.append(u.id)
        labels.append("@" + u.username if u.username else (u.full_name or str(u.id)))

    def upd(d: dict) -> None:
        nonlocal_removed = 0
        glob = d.setdefault("ignored_global", [])
        for aid in admin_ids:
            if aid in glob:
                glob.remove(aid)
                nonlocal_removed += 1
        per = d.setdefault("ignored_event", {})
        for ev_name, lst in list(per.items()):
            for aid in admin_ids:
                if aid in lst:
                    lst.remove(aid)
                    nonlocal_removed += 1
        d["_unignore_count"] = nonlocal_removed
    storage.update(upd)
    removed = storage.get().get("_unignore_count", 0)
    # очистим временное поле
    def cleanup(d: dict) -> None:
        d.pop("_unignore_count", None)
    storage.update(cleanup)
    return removed, labels
