# Инструкция по запуску бота

## Что нужно
1. Аккаунт в Telegram.
2. Аккаунт на [Railway](https://railway.app).
3. ~5–10 минут.

## Шаг 1. Создай бота в Telegram
1. Открой **@BotFather** → `/newbot` → задай имя и юзернейм.
2. Сохрани **TOKEN** (вида `123456:ABC...`).
3. У того же BotFather: `/setprivacy` → выбери своего бота → **Disable** (чтобы видел сообщения в группах).

## Шаг 2. Залей на Railway
1. New Project → загрузи **содержимое** этой папки (не саму папку!) — должны быть видны `Procfile`, `requirements.txt`, `railpack.json`, `nixpacks.toml`, папка `tgbot/`.
2. В разделе **Variables** добавь переменные:

```
BOT_TOKEN         = <токен от BotFather>
SITE_URL          = https://lucky-star-bash.lovable.app
BOT_INGEST_TOKEN  = bPueCYWKxoh6gDDVixF9Q6qZcOPrPJbS1-T33EhYcVhroQ1F7xjE0GnjO4mWUGsY
```

(необязательно) `ADMIN_PANEL_CODE` = свой пароль админ-панели. По умолчанию `bisnes888`.

3. Railway сам поставит зависимости и запустит бота.

## Шаг 3. Активируй админ-панель
1. Найди своего бота в Telegram → **Start**.
2. Отправь ему пароль (по умолчанию **`bisnes888`**).
3. Бот ответит «🛡 Админ-панель активирована».

## Шаг 4. Смени пароль (рекомендуется)
В ЛС бота:
```
/setpassword мой_новый_пароль
```
Посмотреть: `/password`.

## Шаг 5. Замени картинки ивентов (по желанию)
```
/images                       — список ивентов
/setimage perebiv start       — потом пришли фото
/setimage perebiv win         — фото для победы
/resetimage perebiv start     — вернуть оригинал
```

Ивенты: `perebiv, kazik, kubik, viktorina, medved, randommedved, nft, number, goal, lottery, basketball, football, bowling, darts`.

## Шаг 6. Добавь бота в чат
1. Добавь в группу.
2. Сделай **админом** (отправка + удаление сообщений).
3. Запусти ивент: `/startgame_perebiv 1m nft`.

## Полезные команды (в ЛС)
- `/help` — все команды
- `/password` / `/setpassword <новый>`
- `/images` / `/setimage <event> <start|win>`
- `/notifications on|off` — уведомления о победах в ЛС

## Возможные проблемы
- **Bot conflict / terminated by other getUpdates** — где-то ещё запущена копия бота с тем же токеном. Останови старый деплой.
- **Бот молчит в группе** — не выключена приватность у BotFather (`/setprivacy → Disable`) или бот не админ.
- **Команды не работают в ЛС** — не активирована панель, отправь пароль (`bisnes888`).
